import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { TradeSpotlight } from './components/TradeSpotlight';
import { GallerySection } from './components/GallerySection';
import { ArticlesSection } from './components/ArticlesSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { GeminiChatWidget } from './components/GeminiChatWidget';
import { ConsultationModal } from './components/ConsultationModal';
import { AdminCMS } from './components/AdminCMS';
import { api } from './services/api';
import { AppData, ServiceItem, Article } from './types';
import { defaultData } from './data/defaultData';
import { getFirestoreProfile } from './services/firebase';

export default function App() {
  const [appData, setAppData] = useState<AppData>(defaultData);
  const [loading, setLoading] = useState(true);
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSelectedService, setActiveSelectedService] = useState<ServiceItem | null>(null);
  const [activeSelectedArticle, setActiveSelectedArticle] = useState<Article | null>(null);

  // Modals state
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [adminDefaultTab, setAdminDefaultTab] = useState<'overview' | 'articles' | 'gallery' | 'inquiries' | 'profile' | 'drive'>('overview');
  const [resetOobCode, setResetOobCode] = useState<string | null>(null);
  const [initialAuthMode, setInitialAuthMode] = useState<'login' | 'resetRequest' | 'confirmReset'>('login');
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [consultationService, setConsultationService] = useState('General Consultation');
  const [prefilledContactService, setPrefilledContactService] = useState('');

  // Detect and process Firebase Auth action parameters (oobCode, mode=resetPassword) on boot
  useEffect(() => {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const hashParams = new URLSearchParams(window.location.hash.replace(/^#/, ''));
      
      const mode = urlParams.get('mode') || hashParams.get('mode') || urlParams.get('action') || hashParams.get('action');
      const oobCode = urlParams.get('oobCode') || hashParams.get('oobCode') || urlParams.get('code') || hashParams.get('code');
      const adminParam = urlParams.get('admin') || hashParams.get('admin');

      if (mode === 'resetPassword' || oobCode) {
        if (oobCode) {
          setResetOobCode(oobCode);
          setInitialAuthMode('confirmReset');
        } else {
          setInitialAuthMode('resetRequest');
        }
        setIsAdminOpen(true);
      } else if (adminParam === 'true' || adminParam === 'login') {
        setIsAdminOpen(true);
      }
    } catch (e) {
      console.warn('URL params parse notice:', e);
    }
  }, []);

  const handleClearResetParams = () => {
    try {
      if (typeof window !== 'undefined' && window.history && window.history.replaceState) {
        const cleanUrl = window.location.pathname;
        window.history.replaceState({}, document.title, cleanUrl);
      }
      setResetOobCode(null);
      setInitialAuthMode('login');
    } catch (e) {
      console.warn('URL cleanup notice:', e);
    }
  };

  // Initial load from API/LocalStorage/Firestore
  useEffect(() => {
    async function loadData() {
      try {
        const data = await api.getData();
        if (data) {
          // Check Firestore profile for any latest updates
          try {
            const fsProfile = await getFirestoreProfile();
            if (fsProfile && fsProfile.avatarUrl) {
              data.profile = { ...data.profile, ...fsProfile };
            }
          } catch (fsErr) {
            console.warn('Firestore profile sync note:', fsErr);
          }
          setAppData(data);
        }
      } catch (e) {
        console.error('Failed to load portfolio data', e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const handleOpenConsultation = (serviceName: string = 'General Consultation') => {
    setConsultationService(serviceName);
    setIsConsultationOpen(true);
  };

  const handleServiceSelectForConsultation = (serviceTitle: string) => {
    setPrefilledContactService(serviceTitle);
    // Scroll smoothly to contact form or open modal
    const contactElem = document.getElementById('contact');
    if (contactElem) {
      contactElem.scrollIntoView({ behavior: 'smooth' });
    } else {
      handleOpenConsultation(serviceTitle);
    }
  };

  const handleSelectServiceFromSearch = (service: ServiceItem) => {
    setActiveSelectedService(service);
    const elem = document.getElementById(`service-card-${service.id}`) || document.getElementById('services');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectArticleFromSearch = (article: Article) => {
    setActiveSelectedArticle(article);
    const elem = document.getElementById(`article-card-${article.id}`) || document.getElementById('articles');
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenAdminWithTab = (tab: 'overview' | 'articles' | 'gallery' | 'inquiries' | 'profile' | 'drive' = 'overview') => {
    setAdminDefaultTab(tab);
    setIsAdminOpen(true);
  };

  const handleDataUpdated = (newData: AppData) => {
    setAppData(newData);
  };

  const unreadInquiriesCount = appData.inquiries.filter(i => i.status === 'new').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-emerald-500 selection:text-slate-950 font-sans antialiased">
      
      {/* Top Navbar with Real-time Keyword Search */}
      <Navbar
        profile={appData.profile}
        services={appData.services}
        articles={appData.articles}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSelectService={handleSelectServiceFromSearch}
        onSelectArticle={handleSelectArticleFromSearch}
        onOpenAdmin={() => handleOpenAdminWithTab('overview')}
        onOpenConsultation={() => handleOpenConsultation('General Consultation')}
        unreadInquiriesCount={unreadInquiriesCount}
      />

      {/* Main Content View */}
      <main className="relative">
        {/* 1. Unified Executive Profile & Overview */}
        <Hero
          profile={appData.profile}
          onOpenConsultation={() => handleOpenConsultation('General Consultation')}
        />

        {/* 2. Core Services Grid (Filtered by keyword) */}
        <ServicesSection
          services={appData.services}
          searchFilter={searchQuery}
          onClearSearch={() => setSearchQuery('')}
          activeSelectedService={activeSelectedService}
          onCloseSelectedService={() => setActiveSelectedService(null)}
          onSelectServiceForConsultation={handleServiceSelectForConsultation}
        />

        {/* 4. Global Trade & Chaikosh Agrielectro Spotlight */}
        <TradeSpotlight
          profile={appData.profile}
          onOpenConsultation={() => handleOpenConsultation('Global Trade & Export')}
        />

        {/* 5. Dynamic Media Gallery */}
        <GallerySection
          gallery={appData.gallery}
          onOpenAdminUpload={() => handleOpenAdminWithTab('gallery')}
        />

        {/* 7. Dynamic Articles / Blog Section (Filtered by keyword) */}
        <ArticlesSection
          articles={appData.articles}
          profile={appData.profile}
          searchFilter={searchQuery}
          onSearchChange={setSearchQuery}
          activeSelectedArticle={activeSelectedArticle}
          onCloseSelectedArticle={() => setActiveSelectedArticle(null)}
          onOpenAdminArticle={() => handleOpenAdminWithTab('articles')}
        />

        {/* 8. Contact & Socials Section with Interactive Form */}
        <ContactSection
          profile={appData.profile}
          services={appData.services}
          prefilledService={prefilledContactService}
          onInquirySubmitted={async () => {
            const fresh = await api.getData();
            setAppData(fresh);
          }}
        />
      </main>

      {/* Footer */}
      <Footer
        profile={appData.profile}
        onOpenAdmin={() => handleOpenAdminWithTab('overview')}
      />

      {/* Floating WhatsApp Quick Connect Button */}
      <FloatingWhatsApp profile={appData.profile} />

      {/* Gemini AI Assistant & Live Agent Chat Widget */}
      <GeminiChatWidget />

      {/* Consultation Booking Modal */}
      <ConsultationModal
        isOpen={isConsultationOpen}
        onClose={() => setIsConsultationOpen(false)}
        profile={appData.profile}
        preselectedService={consultationService}
        onSuccess={async () => {
          const fresh = await api.getData();
          setAppData(fresh);
        }}
      />

      {/* Full-Featured Admin Panel / CMS Portal */}
      <AdminCMS
        isOpen={isAdminOpen}
        onClose={() => {
          setIsAdminOpen(false);
          handleClearResetParams();
        }}
        appData={appData}
        onDataUpdated={handleDataUpdated}
        defaultTab={adminDefaultTab}
        initialOobCode={resetOobCode}
        initialAuthMode={initialAuthMode}
        onClearResetParams={handleClearResetParams}
      />

    </div>
  );
}
