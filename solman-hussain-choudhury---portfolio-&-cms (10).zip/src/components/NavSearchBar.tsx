import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Ship, FileCheck, Code, ShieldCheck, BookOpen, ChevronRight, Sparkles, ArrowRight, CornerDownLeft } from 'lucide-react';
import { ServiceItem, Article } from '../types';

interface NavSearchBarProps {
  services: ServiceItem[];
  articles: Article[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectService: (service: ServiceItem) => void;
  onSelectArticle: (article: Article) => void;
  isMobile?: boolean;
}

export const NavSearchBar: React.FC<NavSearchBarProps> = ({
  services,
  articles,
  searchQuery,
  onSearchChange,
  onSelectService,
  onSelectArticle,
  isMobile = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const cleanQuery = searchQuery.trim().toLowerCase();

  // Filter Services
  const matchingServices = cleanQuery
    ? services.filter(service => {
        return (
          service.title.toLowerCase().includes(cleanQuery) ||
          service.shortDesc.toLowerCase().includes(cleanQuery) ||
          service.badge.toLowerCase().includes(cleanQuery) ||
          service.organization.toLowerCase().includes(cleanQuery) ||
          service.role.toLowerCase().includes(cleanQuery) ||
          service.features.some(f => f.toLowerCase().includes(cleanQuery))
        );
      })
    : [];

  // Filter Published Articles
  const matchingArticles = cleanQuery
    ? articles.filter(article => {
        if (!article.isPublished) return false;
        return (
          article.title.toLowerCase().includes(cleanQuery) ||
          article.category.toLowerCase().includes(cleanQuery) ||
          article.excerpt.toLowerCase().includes(cleanQuery) ||
          (article.tags && article.tags.some(t => t.toLowerCase().includes(cleanQuery)))
        );
      })
    : [];

  const totalResults = matchingServices.length + matchingArticles.length;
  const flatResults = [
    ...matchingServices.map(s => ({ type: 'service' as const, data: s })),
    ...matchingArticles.map(a => ({ type: 'article' as const, data: a }))
  ];

  // Global keyboard shortcut: '/' or 'Cmd/Ctrl + K'
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.key === 'k' && (e.metaKey || e.ctrlKey)) || (e.key === '/' && document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA')) {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      } else if (e.key === 'Escape') {
        setIsOpen(false);
        setSelectedIndex(-1);
        inputRef.current?.blur();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Handle arrow key navigation in results
  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen || flatResults.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev < flatResults.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev > 0 ? prev - 1 : flatResults.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (selectedIndex >= 0 && selectedIndex < flatResults.length) {
        const item = flatResults[selectedIndex];
        if (item.type === 'service') {
          handleSelectService(item.data);
        } else {
          handleSelectArticle(item.data);
        }
      } else if (cleanQuery) {
        // Scroll to services or articles section
        const targetSection = matchingServices.length > 0 ? 'services' : 'articles';
        const el = document.getElementById(targetSection);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
        setIsOpen(false);
      }
    }
  };

  const handleSelectService = (service: ServiceItem) => {
    onSelectService(service);
    setIsOpen(false);
    const el = document.getElementById(`service-card-${service.id}`) || document.getElementById('services');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSelectArticle = (article: Article) => {
    onSelectArticle(article);
    setIsOpen(false);
  };

  const clearSearch = () => {
    onSearchChange('');
    setSelectedIndex(-1);
    inputRef.current?.focus();
  };

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Ship':
        return <Ship className="w-3.5 h-3.5 text-emerald-400" />;
      case 'FileCheck':
        return <FileCheck className="w-3.5 h-3.5 text-teal-400" />;
      case 'Code':
        return <Code className="w-3.5 h-3.5 text-blue-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />;
      default:
        return <FileCheck className="w-3.5 h-3.5 text-emerald-400" />;
    }
  };

  // Helper to highlight matching text
  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <span key={i} className="bg-emerald-500/30 text-emerald-200 font-bold px-0.5 rounded">
          {part}
        </span>
      ) : (
        part
      )
    );
  };

  return (
    <div
      ref={containerRef}
      role="search"
      aria-label="Search services and blog articles by keyword"
      className={`relative ${isMobile ? 'w-full' : 'w-48 sm:w-60 md:w-72 lg:w-80'}`}
    >
      {/* Input Box */}
      <div className="relative flex items-center">
        <Search
          className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none transition-colors group-focus-within:text-emerald-400"
          aria-hidden="true"
        />
        <input
          ref={inputRef}
          type="text"
          id={isMobile ? 'nav-search-mobile' : 'nav-search-desktop'}
          value={searchQuery}
          onChange={(e) => {
            onSearchChange(e.target.value);
            setIsOpen(true);
            setSelectedIndex(-1);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleInputKeyDown}
          placeholder="Search services & articles..."
          aria-expanded={isOpen}
          aria-autocomplete="list"
          aria-controls="nav-search-results"
          aria-describedby="nav-search-instructions"
          className="w-full pl-9 pr-14 py-1.5 text-xs bg-slate-900/90 hover:bg-slate-900 focus:bg-slate-950 text-slate-100 placeholder-slate-400 rounded-full border border-slate-700/80 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all shadow-inner"
        />

        {/* Clear Button or Keyboard Shortcut Hint */}
        <div className="absolute right-2.5 flex items-center gap-1">
          {searchQuery ? (
            <button
              type="button"
              onClick={clearSearch}
              aria-label="Clear search query"
              className="p-1 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
            >
              <X className="w-3 h-3" />
            </button>
          ) : (
            <kbd
              aria-hidden="true"
              className="hidden sm:inline-block px-1.5 py-0.5 text-[9px] font-mono text-slate-400 bg-slate-800 rounded border border-slate-700 pointer-events-none select-none"
            >
              ⌘K
            </kbd>
          )}
        </div>
      </div>

      {/* Hidden screen-reader instructions */}
      <span id="nav-search-instructions" className="sr-only">
        Type keywords to instantly filter services and blog articles. Use Up and Down arrow keys to browse results, and Enter to select.
      </span>

      {/* Live Results Dropdown */}
      {isOpen && (
        <div
          id="nav-search-results"
          role="listbox"
          className="absolute top-full left-0 right-0 mt-2 bg-slate-950/95 backdrop-blur-xl border border-slate-800 rounded-2xl shadow-2xl overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150 max-h-[80vh] flex flex-col"
        >
          {cleanQuery ? (
            <>
              {/* Header Stats */}
              <div className="px-3.5 py-2 bg-slate-900/80 border-b border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className="text-slate-400">
                  Found <strong className="text-emerald-400">{totalResults}</strong> result{totalResults === 1 ? '' : 's'}
                </span>
                <span className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                  <span>Press</span>
                  <kbd className="px-1 py-0.2 bg-slate-800 rounded text-slate-300 border border-slate-700 text-[9px]">ESC</kbd>
                  <span>to close</span>
                </span>
              </div>

              <div className="overflow-y-auto p-2 space-y-3">
                {/* 1. Services Results */}
                {matchingServices.length > 0 && (
                  <div>
                    <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3 h-3 text-emerald-400" />
                      <span>Services ({matchingServices.length})</span>
                    </div>
                    <div className="space-y-1 mt-1">
                      {matchingServices.map((service, idx) => {
                        const isSelected = selectedIndex === idx;
                        return (
                          <button
                            key={service.id}
                            type="button"
                            role="option"
                            aria-selected={isSelected}
                            onClick={() => handleSelectService(service)}
                            onMouseEnter={() => setSelectedIndex(idx)}
                            className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start gap-2.5 group ${
                              isSelected
                                ? 'bg-emerald-950/60 border border-emerald-800/80 text-white'
                                : 'hover:bg-slate-900/90 text-slate-200 border border-transparent'
                            }`}
                          >
                            <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 shrink-0 mt-0.5">
                              {getServiceIcon(service.icon)}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-xs font-semibold text-white truncate group-hover:text-emerald-300">
                                  {highlightMatch(service.title, cleanQuery)}
                                </span>
                                <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 shrink-0">
                                  {service.badge}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                                {highlightMatch(service.shortDesc, cleanQuery)}
                              </p>
                              <div className="text-[10px] text-emerald-400/80 mt-1 flex items-center gap-1">
                                <span>{service.role}</span>
                                <span>•</span>
                                <span>{service.organization}</span>
                              </div>
                            </div>
                            <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 shrink-0 self-center transition-transform group-hover:translate-x-0.5" />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* 2. Blog Articles Results */}
                {matchingArticles.length > 0 && (
                  <div>
                    <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <BookOpen className="w-3 h-3 text-teal-400" />
                      <span>Blog Articles ({matchingArticles.length})</span>
                    </div>
                    <div className="space-y-1 mt-1">
                      {matchingArticles.map((article, aIdx) => {
                        const globalIdx = matchingServices.length + aIdx;
                        const isSelected = selectedIndex === globalIdx;
                        return (
                          <button
                            key={article.id}
                            type="button"
                            role="option"
                            aria-selected={isSelected}
                            onClick={() => handleSelectArticle(article)}
                            onMouseEnter={() => setSelectedIndex(globalIdx)}
                            className={`w-full text-left p-2.5 rounded-xl transition-all flex items-start gap-2.5 group ${
                              isSelected
                                ? 'bg-teal-950/60 border border-teal-800/80 text-white'
                                : 'hover:bg-slate-900/90 text-slate-200 border border-transparent'
                            }`}
                          >
                            <img
                              src={article.coverImage}
                              alt=""
                              referrerPolicy="no-referrer"
                              className="w-12 h-10 rounded-lg object-cover bg-slate-900 shrink-0 mt-0.5 border border-slate-800"
                            />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-xs font-semibold text-white truncate group-hover:text-teal-300">
                                  {highlightMatch(article.title, cleanQuery)}
                                </span>
                                <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-900 text-teal-400 border border-slate-800 shrink-0">
                                  {article.category}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                                {highlightMatch(article.excerpt, cleanQuery)}
                              </p>
                              <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-1.5">
                                <span>{article.publishedDate}</span>
                                <span>•</span>
                                <span>{article.readTime}</span>
                              </div>
                            </div>
                            <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-teal-400 shrink-0 self-center transition-transform group-hover:translate-x-0.5" />
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Zero Results State */}
                {totalResults === 0 && (
                  <div className="p-6 text-center space-y-2">
                    <Search className="w-6 h-6 text-slate-600 mx-auto" />
                    <p className="text-xs font-semibold text-slate-300">
                      No matching services or articles found for &ldquo;{searchQuery}&rdquo;
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Try searching with broader terms like <button onClick={() => onSearchChange('export')} className="text-emerald-400 underline">export</button>, <button onClick={() => onSearchChange('tax')} className="text-emerald-400 underline">tax</button>, <button onClick={() => onSearchChange('tea')} className="text-emerald-400 underline">tea</button>, or <button onClick={() => onSearchChange('insurance')} className="text-emerald-400 underline">insurance</button>.
                    </p>
                  </div>
                )}
              </div>

              {/* Bottom Quick Jump Action */}
              {totalResults > 0 && (
                <div className="p-2 bg-slate-900/90 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-[11px] text-slate-400">
                    Showing instant filter previews
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const el = matchingServices.length > 0 ? document.getElementById('services') : document.getElementById('articles');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                      setIsOpen(false);
                    }}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 text-[11px] font-semibold border border-emerald-500/30 transition-all"
                  >
                    <span>View in Page</span>
                    <CornerDownLeft className="w-3 h-3" />
                  </button>
                </div>
              )}
            </>
          ) : (
            /* Empty Query - Suggestions / Shortcuts */
            <div className="p-4 space-y-3">
              <div className="text-[11px] font-semibold text-slate-400 flex items-center justify-between">
                <span>Popular Search Keywords</span>
                <span className="text-[10px] text-slate-500">Instant Filter</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Export Trade', 
                  'Tax Compliance', 
                  'Chaikosh Tea', 
                  'Vehicle Advisory', 
                  'Life Insurance', 
                  'Assam Northeast', 
                  'Web Architecture'
                ].map((term) => (
                  <button
                    key={term}
                    type="button"
                    onClick={() => {
                      onSearchChange(term);
                      inputRef.current?.focus();
                    }}
                    className="px-2.5 py-1 text-[11px] bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-emerald-300 rounded-lg border border-slate-800 hover:border-emerald-800/60 transition-all flex items-center gap-1"
                  >
                    <Search className="w-2.5 h-2.5 text-slate-500" />
                    <span>{term}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
