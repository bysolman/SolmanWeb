import React, { useState, useEffect } from 'react';
import { 
  Menu, X, Lock, PhoneCall, Globe2, Briefcase, 
  BookOpen, Image as ImageIcon, Mail, ArrowUpRight, CheckCircle2, Search 
} from 'lucide-react';
import { ProfileData, ServiceItem, Article } from '../types';
import { NavSearchBar } from './NavSearchBar';

interface NavbarProps {
  profile: ProfileData;
  services: ServiceItem[];
  articles: Article[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectService: (service: ServiceItem) => void;
  onSelectArticle: (article: Article) => void;
  onOpenAdmin: () => void;
  onOpenConsultation: () => void;
  unreadInquiriesCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  profile, 
  services,
  articles,
  searchQuery,
  onSearchChange,
  onSelectService,
  onSelectArticle,
  onOpenAdmin, 
  onOpenConsultation,
  unreadInquiriesCount = 0 
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Services', href: '#services' },
    { label: 'Global Trade', href: '#global-trade' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Articles', href: '#articles' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header 
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled 
          ? 'bg-slate-900/95 backdrop-blur-md border-b border-emerald-900/40 shadow-lg py-3' 
          : 'bg-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-3">
          
          {/* Brand Logo & Name */}
          <a href="#" className="flex items-center gap-3 group shrink-0">
            <div className="w-10 h-10 rounded-xl overflow-hidden bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-white font-bold text-lg shadow-md group-hover:scale-105 transition-transform border border-emerald-400/40 relative shrink-0">
              <img 
                key={profile.avatarUrl || 'nav-avatar'}
                src={profile.avatarUrl || "/images/solman_choudhury.jpg"} 
                alt={profile.name} 
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "/images/solman_choudhury.jpg";
                }}
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-base sm:text-lg font-bold text-slate-100 group-hover:text-emerald-400 transition-colors tracking-tight">
                {profile.name}
              </span>
              <span className="text-xs text-emerald-400/90 font-medium tracking-wide flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Managing Partner • Consultant • Exporter
              </span>
            </div>
          </a>

          {/* Desktop Search Bar */}
          <div className="hidden md:flex items-center flex-1 max-w-xs lg:max-w-sm mx-2">
            <NavSearchBar
              services={services}
              articles={articles}
              searchQuery={searchQuery}
              onSearchChange={onSearchChange}
              onSelectService={onSelectService}
              onSelectArticle={onSelectArticle}
            />
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center space-x-1 bg-slate-800/60 p-1.5 rounded-full border border-slate-700/60 backdrop-blur-md">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-700/60 rounded-full transition-all"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center gap-2 shrink-0">
            <button
              id="nav-consultation-btn"
              onClick={onOpenConsultation}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-gradient-to-r from-emerald-400 to-teal-300 rounded-lg hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md shadow-emerald-500/10 active:scale-95"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Book Call</span>
            </button>

            <button
              id="nav-admin-cms-btn"
              onClick={onOpenAdmin}
              className="relative inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/80 hover:bg-slate-700 hover:text-white rounded-lg border border-slate-700 transition-all active:scale-95"
              title="Admin Panel / CMS Login"
            >
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>CMS Portal</span>
              {unreadInquiriesCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping absolute -top-1 -right-1" />
              )}
            </button>
          </div>

          {/* Mobile Quick Action Buttons */}
          <div className="flex items-center gap-1.5 md:hidden">
            <button
              onClick={() => setMobileSearchOpen(!mobileSearchOpen)}
              className={`p-2 rounded-lg border transition-all ${
                mobileSearchOpen || searchQuery
                  ? 'bg-emerald-950 text-emerald-400 border-emerald-700'
                  : 'text-slate-300 hover:text-white bg-slate-800/70 border-slate-700'
              }`}
              aria-label="Toggle mobile search"
            >
              <Search className="w-4 h-4" />
            </button>

            <button
              id="mobile-admin-quick-btn"
              onClick={onOpenAdmin}
              className="p-2 text-slate-300 hover:text-emerald-400 bg-slate-800/70 rounded-lg border border-slate-700"
              title="Admin CMS"
            >
              <Lock className="w-4 h-4" />
            </button>

            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white bg-slate-800/70 rounded-lg border border-slate-700 focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Mobile Search Dropdown Bar */}
        {mobileSearchOpen && (
          <div className="md:hidden mt-3 pt-3 border-t border-slate-800 animate-in fade-in slide-in-from-top-2 duration-150">
            <NavSearchBar
              services={services}
              articles={articles}
              searchQuery={searchQuery}
              onSearchChange={onSearchChange}
              onSelectService={(s) => {
                onSelectService(s);
                setMobileSearchOpen(false);
              }}
              onSelectArticle={(a) => {
                onSelectArticle(a);
                setMobileSearchOpen(false);
              }}
              isMobile={true}
            />
          </div>
        )}
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900/95 border-b border-slate-800 px-4 pt-3 pb-6 space-y-3 mt-2 backdrop-blur-xl shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
          {/* Search bar inside drawer */}
          <div className="pb-2">
            <NavSearchBar
              services={services}
              articles={articles}
              searchQuery={searchQuery}
              onSearchChange={onSearchChange}
              onSelectService={(s) => {
                onSelectService(s);
                setMobileMenuOpen(false);
              }}
              onSelectArticle={(a) => {
                onSelectArticle(a);
                setMobileMenuOpen(false);
              }}
              isMobile={true}
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2.5 rounded-lg text-sm font-medium text-slate-200 hover:bg-slate-800 hover:text-emerald-400 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-800 space-y-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenConsultation();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-emerald-950 bg-gradient-to-r from-emerald-400 to-teal-300 rounded-lg shadow-md"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Book Direct Consultation</span>
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-300 bg-slate-800 rounded-lg border border-slate-700 hover:text-emerald-400"
            >
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>Admin CMS Portal</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
