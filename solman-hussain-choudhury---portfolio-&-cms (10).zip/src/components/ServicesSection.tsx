import React, { useState } from 'react';
import { 
  Ship, FileCheck, Code, ShieldCheck, ArrowRight, 
  CheckCircle2, Sparkles, X, ChevronRight, PhoneCall, Search, RotateCcw,
  Briefcase, Calendar, MessageSquare, Car, FileText
} from 'lucide-react';
import { ServiceItem } from '../types';
import { useDynamicSEO } from '../utils/seo';

interface ServicesSectionProps {
  services: ServiceItem[];
  onSelectServiceForConsultation: (serviceTitle: string) => void;
  searchFilter?: string;
  onClearSearch?: () => void;
  activeSelectedService?: ServiceItem | null;
  onCloseSelectedService?: () => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ 
  services, 
  onSelectServiceForConsultation,
  searchFilter = '',
  onClearSearch,
  activeSelectedService = null,
  onCloseSelectedService
}) => {
  const [internalSelectedService, setInternalSelectedService] = useState<ServiceItem | null>(null);

  const selectedService = activeSelectedService || internalSelectedService;

  useDynamicSEO({
    title: selectedService ? selectedService.title : "Professional Services | Assam Consultant & Export Trading",
    description: selectedService ? selectedService.shortDesc : "Professional consulting services including Tax, GST, Company & NGO Registration, and Export Trading by Solman Hussain Choudhury.",
    keywords: selectedService ? [selectedService.badge, selectedService.organization, 'Assam Consultant', 'Export Trading'] : ['Assam Consultant', 'Export Trading']
  });

  const setSelectedService = (service: ServiceItem | null) => {
    if (!service && onCloseSelectedService) {
      onCloseSelectedService();
    }
    setInternalSelectedService(service);
  };

  const cleanFilter = searchFilter.trim().toLowerCase();

  // Filter services by searchFilter
  const filteredServices = cleanFilter
    ? services.filter(service => {
        return (
          service.title.toLowerCase().includes(cleanFilter) ||
          service.shortDesc.toLowerCase().includes(cleanFilter) ||
          service.badge.toLowerCase().includes(cleanFilter) ||
          service.organization.toLowerCase().includes(cleanFilter) ||
          service.role.toLowerCase().includes(cleanFilter) ||
          service.features.some(f => f.toLowerCase().includes(cleanFilter)) ||
          service.fullDesc.toLowerCase().includes(cleanFilter)
        );
      })
    : services;

  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <span key={i} className="bg-emerald-500/30 text-emerald-200 font-semibold px-0.5 rounded">
          {part}
        </span>
      ) : (
        part
      )
    );
  };

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Ship':
        return <Ship className="w-6 h-6 text-emerald-400" />;
      case 'FileCheck':
        return <FileCheck className="w-6 h-6 text-teal-400" />;
      case 'Code':
        return <Code className="w-6 h-6 text-blue-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-amber-400" />;
      case 'Car':
        return <Car className="w-6 h-6 text-amber-400" />;
      default:
        return <FileCheck className="w-6 h-6 text-emerald-400" />;
    }
  };

  const getAccentColor = (iconName: string) => {
    switch (iconName) {
      case 'Ship':
        return 'border-emerald-500/30 hover:border-emerald-500/60 bg-emerald-950/20';
      case 'FileCheck':
        return 'border-teal-500/30 hover:border-teal-500/60 bg-teal-950/20';
      case 'Code':
        return 'border-blue-500/30 hover:border-blue-500/60 bg-blue-950/20';
      case 'ShieldCheck':
      case 'Car':
        return 'border-amber-500/30 hover:border-amber-500/60 bg-amber-950/20';
      default:
        return 'border-emerald-500/30 hover:border-emerald-500/60 bg-emerald-950/20';
    }
  };

  return (
    <section id="core-business" className="py-24 bg-slate-950 text-white relative scroll-mt-12">
      {/* Anchor for backward compatibility */}
      <span id="services" className="absolute -top-24 opacity-0 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-emerald-950 text-emerald-400 border border-emerald-800/80 shadow-inner">
            <Briefcase className="w-3.5 h-3.5" />
            <span>Professional Portfolio & Capabilities</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight">
            Core Business & <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-300">
              Advisory Practice
            </span>
          </h2>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            A comprehensive breakdown of international merchant exports, statutory tax filings, complete vehicle insurance, DPR loan reports, and corporate digital advisory.
          </p>
        </div>

        {/* Active Search Filter Banner */}
        {cleanFilter && (
          <div className="mb-8 p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-2.5 text-xs text-slate-200">
              <Search className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                Showing <strong className="text-emerald-300 font-bold">{filteredServices.length}</strong> of {services.length} services matching keyword &ldquo;<strong className="text-white font-mono">{searchFilter}</strong>&rdquo;
              </span>
            </div>
            {onClearSearch && (
              <button
                type="button"
                onClick={onClearSearch}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5 text-emerald-400" />
                <span>Clear Filter</span>
              </button>
            )}
          </div>
        )}

        {/* No Results Fallback */}
        {filteredServices.length === 0 ? (
          <div className="text-center py-16 px-4 bg-slate-900/60 rounded-3xl border border-slate-800 space-y-4 max-w-xl mx-auto">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto border border-slate-700">
              <Search className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">No services match &ldquo;{searchFilter}&rdquo;</h3>
            <p className="text-xs text-slate-400">
              Try searching with a different term such as &ldquo;export&rdquo;, &ldquo;compliance&rdquo;, &ldquo;tax&rdquo;, or &ldquo;tea&rdquo;.
            </p>
            {onClearSearch && (
              <button
                onClick={onClearSearch}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition-all shadow cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Show All Services</span>
              </button>
            )}
          </div>
        ) : (
          /* Grid of Services */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredServices.map((service) => (
              <div
                key={service.id}
                id={`service-card-${service.id}`}
                className={`rounded-2xl p-7 sm:p-8 border transition-all duration-300 flex flex-col justify-between group backdrop-blur-sm shadow-xl ${getAccentColor(service.icon)}`}
              >
                <div>
                  {/* Top Badge & Icon */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-700 shadow-md group-hover:scale-110 transition-transform">
                      {getServiceIcon(service.icon)}
                    </div>
                    <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-900 text-emerald-300 border border-slate-700">
                      {service.badge}
                    </span>
                  </div>

                  {/* Title & Organization Subhead */}
                  <h3 className="text-xl font-bold text-white group-hover:text-emerald-300 transition-colors">
                    {highlightMatch(service.title, cleanFilter)}
                  </h3>
                  <div className="text-xs font-medium text-emerald-400 mt-1 mb-4 flex items-center gap-1.5">
                    <span>{highlightMatch(service.role, cleanFilter)}</span>
                    <span>•</span>
                    <span>{highlightMatch(service.organization, cleanFilter)}</span>
                  </div>

                  <p className="text-sm text-slate-300 leading-relaxed mb-6">
                    {highlightMatch(service.shortDesc, cleanFilter)}
                  </p>

                  {/* Key Capabilities List */}
                  <div className="space-y-2.5 mb-6">
                    {service.features.slice(0, 4).map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{highlightMatch(feature, cleanFilter)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between gap-3">
                  <button
                    onClick={() => setSelectedService(service)}
                    className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <span>View Full Scope</span>
                    <ChevronRight className="w-4 h-4 text-emerald-400" />
                  </button>

                  <button
                    onClick={() => onSelectServiceForConsultation(service.title)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-emerald-950 bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md active:scale-95 cursor-pointer"
                  >
                    <PhoneCall className="w-3.5 h-3.5" />
                    <span>Book Advisory Session</span>
                  </button>
                </div>

              </div>
            ))}
          </div>
        )}

        {/* Dedicated Advisory Session Prompt Banner */}
        <div className="mt-16 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-emerald-950/40 border border-emerald-700/50 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
              <Calendar className="w-3.5 h-3.5" />
              <span>Direct 1-on-1 Consultation</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white">
              Need Strategic Advice on Trade, Tax, Insurance, or DPR?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Schedule a focused advisory session with Solman Hussain Choudhury to review export documents, statutory filing requirements, or enterprise development plans.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
            <button
              onClick={() => onSelectServiceForConsultation('General Advisory & Consultation')}
              className="px-5 py-3 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-lg active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Schedule Session</span>
            </button>
            <a
              href="https://wa.me/916001565255?text=Hello%20Solman%20Choudhury,%20I%20would%20like%20to%20schedule%20a%20business%20advisory%20session."
              target="_blank"
              rel="noreferrer"
              className="px-4 py-3 rounded-xl text-xs font-semibold text-emerald-300 bg-slate-950 hover:bg-slate-800 border border-emerald-800/80 transition-all flex items-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp Connect</span>
            </a>
          </div>
        </div>

      </div>

      {/* Service Detail Modal */}
      {selectedService && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedService(null);
          }}
        >
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setSelectedService(null)}
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-3.5 rounded-2xl bg-slate-800 border border-slate-700">
                {getServiceIcon(selectedService.icon)}
              </div>
              <div>
                <span className="text-xs font-bold text-emerald-400">{selectedService.badge}</span>
                <h3 className="text-2xl font-bold text-white">{selectedService.title}</h3>
              </div>
            </div>

            <div className="text-xs text-slate-400 font-medium pb-4 border-b border-slate-800">
              Role: <span className="text-slate-200 font-semibold">{selectedService.role}</span> | Organization: <span className="text-slate-200 font-semibold">{selectedService.organization}</span>
            </div>

            <div className="py-4 space-y-4 text-sm text-slate-300 leading-relaxed">
              <p>{selectedService.fullDesc}</p>
              
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                Full Scope of Capabilities & Deliverables:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {selectedService.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs text-slate-200">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-5 border-t border-slate-800 flex items-center justify-end gap-3">
              <button
                onClick={() => setSelectedService(null)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const title = selectedService.title;
                  setSelectedService(null);
                  onSelectServiceForConsultation(title);
                }}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md cursor-pointer"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Book Advisory for {selectedService.title}</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};

