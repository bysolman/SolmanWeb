import React, { useState, useEffect, useRef } from 'react';
import { 
  Folder, FileText, Image as ImageIcon, FileSpreadsheet, 
  File, Upload, Plus, Trash2, ExternalLink, RefreshCw, 
  Search, ArrowLeft, HardDrive, Check, AlertCircle, 
  FolderPlus, FilePlus, Download, X, Lock, ShieldCheck,
  LayoutGrid, List, ChevronRight, UserCheck, LogOut
} from 'lucide-react';
import { googleSignIn, logout, initAuth, getAccessToken } from '../services/googleAuth';
import { googleDriveService, DriveFile, DriveAboutInfo } from '../services/googleDrive';
import { User } from 'firebase/auth';

interface GoogleDriveManagerProps {
  onClose?: () => void;
  isModal?: boolean;
  onSelectFile?: (file: DriveFile) => void;
  selectMode?: boolean;
}

export const GoogleDriveManager: React.FC<GoogleDriveManagerProps> = ({
  onClose,
  isModal = false,
  onSelectFile,
  selectMode = false
}) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [files, setFiles] = useState<DriveFile[]>([]);
  const [aboutInfo, setAboutInfo] = useState<DriveAboutInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Folder navigation history
  const [currentFolder, setCurrentFolder] = useState<{ id: string; name: string } | null>(null);
  const [folderHistory, setFolderHistory] = useState<Array<{ id: string; name: string }>>([]);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [mimeFilter, setMimeFilter] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Modals inside Drive
  const [showNewFolderModal, setShowNewFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [showNewDocModal, setShowNewDocModal] = useState(false);
  const [newDocTitle, setNewDocTitle] = useState('');
  const [newDocContent, setNewDocContent] = useState('');
  
  // Explicit Delete Confirmation Dialog state
  const [fileToDelete, setFileToDelete] = useState<DriveFile | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Drag & drop upload
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      async (user, _token, isAuthorized) => {
        setCurrentUser(user);
        const userEmail = (user.email || '').trim().toLowerCase();
        const isMatch = userEmail === 'solmanchoudhury66@gmail.com';
        
        if (isMatch || isAuthorized) {
          setIsAuthenticated(true);
          setAuthLoading(false);
          loadFilesAndInfo();
        } else {
          setIsAuthenticated(false);
          setAuthLoading(false);
          setError(`Access Denied: You are not authorized for administrator access.`);
        }
      },
      () => {
        setCurrentUser(null);
        setIsAuthenticated(false);
        setAuthLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    try {
      setError(null);
      setAuthLoading(true);
      const res = await googleSignIn();
      if (res) {
        setCurrentUser(res.user);
        const userEmail = (res.user.email || '').trim().toLowerCase();
        const isMatch = userEmail === 'solmanchoudhury66@gmail.com';
        
        if (isMatch || res.isAuthorized) {
          setIsAuthenticated(true);
          await loadFilesAndInfo();
        } else {
          setIsAuthenticated(false);
          setError(`Access Restricted: You are not authorized for administrator access.`);
        }
      }
    } catch (err: any) {
      console.error('Sign in failed:', err);
      setError(err.message || 'Failed to sign in with Google');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await logout();
      setCurrentUser(null);
      setIsAuthenticated(false);
      setFiles([]);
      setAboutInfo(null);
      setFolderHistory([]);
      setCurrentFolder(null);
    } catch (err: any) {
      console.error('Logout failed:', err);
    }
  };

  const loadFilesAndInfo = async (folderId?: string) => {
    try {
      setLoading(true);
      setError(null);

      const targetFolder = folderId !== undefined ? folderId : currentFolder?.id;

      const [fileList, about] = await Promise.all([
        googleDriveService.listFiles({
          folderId: targetFolder,
          searchQuery: searchQuery,
          mimeTypeFilter: mimeFilter
        }),
        googleDriveService.getAboutInfo().catch(() => null)
      ]);

      setFiles(fileList);
      if (about) setAboutInfo(about);
    } catch (err: any) {
      console.error('Failed to load drive files:', err);
      setError(err.message || 'Error communicating with Google Drive');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadFilesAndInfo(currentFolder?.id);
    }
  }, [currentFolder, mimeFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAuthenticated) {
      loadFilesAndInfo();
    }
  };

  const enterFolder = (folder: DriveFile) => {
    if (currentFolder) {
      setFolderHistory(prev => [...prev, currentFolder]);
    }
    setCurrentFolder({ id: folder.id, name: folder.name });
    setSearchQuery('');
  };

  const navigateToHistory = (index: number) => {
    if (index === -1) {
      // Go to Root
      setCurrentFolder(null);
      setFolderHistory([]);
    } else {
      const target = folderHistory[index];
      const newHistory = folderHistory.slice(0, index);
      setFolderHistory(newHistory);
      setCurrentFolder(target);
    }
  };

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;

    try {
      setLoading(true);
      await googleDriveService.createFolder(newFolderName.trim(), currentFolder?.id);
      setNewFolderName('');
      setShowNewFolderModal(false);
      setSuccessMsg(`Folder "${newFolderName}" created successfully.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      await loadFilesAndInfo();
    } catch (err: any) {
      setError(err.message || 'Failed to create folder');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateDoc = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDocTitle.trim()) return;

    try {
      setLoading(true);
      await googleDriveService.createDocument(newDocTitle.trim(), newDocContent, currentFolder?.id);
      setNewDocTitle('');
      setNewDocContent('');
      setShowNewDocModal(false);
      setSuccessMsg(`Document "${newDocTitle}" created in Google Drive.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      await loadFilesAndInfo();
    } catch (err: any) {
      setError(err.message || 'Failed to create document');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (filesToUpload: FileList | null) => {
    if (!filesToUpload || filesToUpload.length === 0) return;

    try {
      setLoading(true);
      setError(null);
      for (let i = 0; i < filesToUpload.length; i++) {
        await googleDriveService.uploadFile(filesToUpload[i], currentFolder?.id);
      }
      setSuccessMsg(`Uploaded ${filesToUpload.length} file(s) successfully.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      await loadFilesAndInfo();
    } catch (err: any) {
      setError(err.message || 'Failed to upload file(s)');
    } finally {
      setLoading(false);
    }
  };

  const confirmDeleteFile = async () => {
    if (!fileToDelete) return;
    try {
      setIsDeleting(true);
      await googleDriveService.deleteFile(fileToDelete.id);
      setSuccessMsg(`Permanently removed "${fileToDelete.name}" from Google Drive.`);
      setTimeout(() => setSuccessMsg(null), 3000);
      setFileToDelete(null);
      await loadFilesAndInfo();
    } catch (err: any) {
      setError(err.message || 'Failed to delete file');
    } finally {
      setIsDeleting(false);
    }
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType === 'application/vnd.google-apps.folder') {
      return <Folder className="w-6 h-6 text-amber-400 fill-amber-400/20" />;
    }
    if (mimeType.includes('image/')) {
      return <ImageIcon className="w-6 h-6 text-purple-400" />;
    }
    if (mimeType.includes('spreadsheet') || mimeType.includes('sheet') || mimeType.includes('csv')) {
      return <FileSpreadsheet className="w-6 h-6 text-emerald-400" />;
    }
    if (mimeType.includes('document') || mimeType.includes('pdf') || mimeType.includes('text')) {
      return <FileText className="w-6 h-6 text-blue-400" />;
    }
    return <File className="w-6 h-6 text-slate-400" />;
  };

  const formatFileSize = (bytes?: string) => {
    if (!bytes) return '--';
    const num = parseInt(bytes, 10);
    if (isNaN(num)) return '--';
    if (num < 1024) return `${num} B`;
    if (num < 1024 * 1024) return `${(num / 1024).toFixed(1)} KB`;
    return `${(num / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatQuota = (quota?: { limit?: string; usage?: string }) => {
    if (!quota || !quota.limit || !quota.usage) return null;
    const usedGB = (parseInt(quota.usage, 10) / (1024 ** 3)).toFixed(2);
    const totalGB = (parseInt(quota.limit, 10) / (1024 ** 3)).toFixed(1);
    const pct = Math.min(100, Math.round((parseInt(quota.usage, 10) / parseInt(quota.limit, 10)) * 100));
    return { usedGB, totalGB, pct };
  };

  const quota = formatQuota(aboutInfo?.storageQuota);

  return (
    <div className={`bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl text-slate-100 flex flex-col ${isModal ? 'max-h-[90vh] w-full max-w-5xl' : 'w-full'}`}>
      
      {/* Top Header Bar */}
      <div className="p-4 sm:p-5 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-emerald-500 to-amber-400 flex items-center justify-center p-0.5 shadow-md">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <HardDrive className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">Google Drive Cloud Storage</h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/60">
                Live Integration
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Manage export trade contracts, GST reports, client files & documents in Google Drive
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          {isAuthenticated && currentUser && (
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs">
              <img 
                src={currentUser.photoURL || aboutInfo?.user?.photoLink || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80"} 
                alt="Google user"
                className="w-5 h-5 rounded-full object-cover"
                referrerPolicy="no-referrer"
              />
              <span className="font-medium text-slate-200 truncate max-w-[140px]">
                {currentUser.displayName || currentUser.email}
              </span>
              <button 
                onClick={handleSignOut}
                className="text-slate-400 hover:text-rose-400 ml-1 p-0.5"
                title="Disconnect Google Account"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {isModal && onClose && (
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Body */}
      {!isAuthenticated ? (
        <div className="p-8 sm:p-12 text-center max-w-lg mx-auto space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-400 flex items-center justify-center mx-auto shadow-xl">
            <HardDrive className="w-8 h-8" />
          </div>

          <div className="space-y-2">
            <h3 className="text-xl font-bold text-white">Connect Your Google Drive</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Sign in with your Google account to access, upload, browse, and link export contracts, tax certificates, invoices, and trade portfolios directly.
            </p>
          </div>

          {error && (
            <div className="p-3.5 rounded-xl bg-rose-950/50 border border-rose-800/60 text-rose-300 text-xs flex items-center gap-2 text-left">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="pt-2">
            <button
              id="google-drive-signin-btn"
              onClick={handleSignIn}
              disabled={authLoading}
              className="inline-flex items-center gap-3 px-6 py-3.5 rounded-xl font-semibold text-sm text-slate-900 bg-white hover:bg-slate-100 transition-all shadow-lg active:scale-95 disabled:opacity-50"
            >
              {/* Google G Logo SVG */}
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{authLoading ? 'Connecting...' : 'Sign in with Google'}</span>
            </button>
          </div>

          <div className="pt-4 flex items-center justify-center gap-4 text-[11px] text-slate-500">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> Secure OAuth 2.0
            </span>
            <span>•</span>
            <span>Direct Google API Connection</span>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col min-h-0">
          
          {/* Navigation & Controls Bar */}
          <div className="p-3 sm:p-4 border-b border-slate-800/80 bg-slate-900/60 flex flex-wrap items-center justify-between gap-3">
            
            {/* Breadcrumb path */}
            <div className="flex items-center gap-1.5 text-xs text-slate-400 overflow-x-auto py-1 max-w-full">
              <button
                onClick={() => navigateToHistory(-1)}
                className={`hover:text-white flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-800 transition-colors ${!currentFolder ? 'text-emerald-400 font-bold' : ''}`}
              >
                <HardDrive className="w-3.5 h-3.5" />
                <span>My Drive</span>
              </button>

              {folderHistory.map((folder, idx) => (
                <React.Fragment key={folder.id}>
                  <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />
                  <button
                    onClick={() => navigateToHistory(idx)}
                    className="hover:text-white px-2 py-1 rounded hover:bg-slate-800 transition-colors truncate max-w-[120px]"
                  >
                    {folder.name}
                  </button>
                </React.Fragment>
              ))}

              {currentFolder && (
                <>
                  <ChevronRight className="w-3 h-3 text-slate-600 shrink-0" />
                  <span className="text-emerald-400 font-bold px-2 py-1 bg-slate-800/80 rounded truncate max-w-[150px]">
                    {currentFolder.name}
                  </span>
                </>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              
              <button
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition-colors shadow-sm"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload</span>
              </button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={(e) => handleFileUpload(e.target.files)}
                multiple
                className="hidden"
              />

              <button
                onClick={() => setShowNewFolderModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white border border-slate-700 transition-colors"
              >
                <FolderPlus className="w-3.5 h-3.5 text-amber-400" />
                <span>New Folder</span>
              </button>

              <button
                onClick={() => setShowNewDocModal(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white border border-slate-700 transition-colors"
              >
                <FilePlus className="w-3.5 h-3.5 text-blue-400" />
                <span>New Note/Doc</span>
              </button>

              <button
                onClick={() => loadFilesAndInfo()}
                className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                title="Refresh files"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              </button>

              <div className="flex items-center bg-slate-800/80 rounded-lg p-0.5 border border-slate-700">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-1.5 rounded ${viewMode === 'grid' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                  title="Grid View"
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-1.5 rounded ${viewMode === 'list' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                  title="List View"
                >
                  <List className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>

          {/* Search and Filters Bar */}
          <div className="px-4 py-2.5 bg-slate-950/40 border-b border-slate-800/60 flex flex-wrap items-center justify-between gap-3 text-xs">
            <form onSubmit={handleSearchSubmit} className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search files in Google Drive..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
              />
            </form>

            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="text-slate-500 font-medium">Type:</span>
              {[
                { id: 'all', label: 'All' },
                { id: 'folder', label: 'Folders' },
                { id: 'document', label: 'Docs/PDF' },
                { id: 'spreadsheet', label: 'Sheets' },
                { id: 'image', label: 'Images' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setMimeFilter(f.id)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors ${
                    mimeFilter === f.id
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/80'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {/* Notifications */}
          {error && (
            <div className="mx-4 mt-3 p-3 rounded-lg bg-rose-950/50 border border-rose-800/60 text-rose-300 text-xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
              <button onClick={() => setError(null)} className="text-rose-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {successMsg && (
            <div className="mx-4 mt-3 p-3 rounded-lg bg-emerald-950/50 border border-emerald-800/60 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{successMsg}</span>
              </div>
              <button onClick={() => setSuccessMsg(null)} className="text-emerald-400 hover:text-white">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Drag and Drop Zone / File List Area */}
          <div 
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              handleFileUpload(e.dataTransfer.files);
            }}
            className={`p-4 sm:p-5 flex-1 overflow-y-auto max-h-[460px] relative transition-colors ${
              isDragging ? 'bg-emerald-950/20 border-2 border-dashed border-emerald-500' : ''
            }`}
          >
            {isDragging && (
              <div className="absolute inset-0 bg-slate-900/90 flex flex-col items-center justify-center gap-2 z-20 pointer-events-none">
                <Upload className="w-10 h-10 text-emerald-400 animate-bounce" />
                <div className="text-sm font-bold text-white">Drop files to upload to this folder</div>
              </div>
            )}

            {loading && files.length === 0 ? (
              <div className="py-16 text-center text-slate-400 space-y-3">
                <RefreshCw className="w-8 h-8 mx-auto animate-spin text-emerald-400" />
                <p className="text-xs">Loading files from Google Drive...</p>
              </div>
            ) : files.length === 0 ? (
              <div className="py-16 text-center text-slate-400 space-y-3">
                <Folder className="w-12 h-12 mx-auto text-slate-600" />
                <div className="text-sm font-medium text-slate-300">No files found</div>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Drag and drop files here, or use the "Upload" / "New Folder" buttons to organize documents.
                </p>
              </div>
            ) : viewMode === 'grid' ? (
              /* GRID VIEW */
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
                {files.map((file) => {
                  const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
                  return (
                    <div
                      key={file.id}
                      className="group relative bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 hover:border-emerald-600/50 rounded-xl p-3.5 flex flex-col justify-between transition-all cursor-pointer shadow-sm hover:shadow-md"
                      onClick={() => {
                        if (isFolder) {
                          enterFolder(file);
                        } else if (selectMode && onSelectFile) {
                          onSelectFile(file);
                        }
                      }}
                    >
                      <div className="space-y-2.5">
                        <div className="flex items-start justify-between">
                          <div className="p-2 rounded-lg bg-slate-900/80 border border-slate-800">
                            {getFileIcon(file.mimeType)}
                          </div>
                          
                          {/* File Actions Dropdown/Menu */}
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity" onClick={(e) => e.stopPropagation()}>
                            {file.webViewLink && (
                              <a
                                href={file.webViewLink}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1 rounded text-slate-400 hover:text-emerald-400 hover:bg-slate-700"
                                title="Open in Google Drive"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            )}
                            <button
                              onClick={() => setFileToDelete(file)}
                              className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-700"
                              title="Delete file"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div>
                          <div className="text-xs font-semibold text-slate-200 group-hover:text-white truncate" title={file.name}>
                            {file.name}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                            <span>{isFolder ? 'Folder' : formatFileSize(file.size)}</span>
                            <span>{file.modifiedTime ? new Date(file.modifiedTime).toLocaleDateString() : ''}</span>
                          </div>
                        </div>
                      </div>

                      {selectMode && !isFolder && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onSelectFile) onSelectFile(file);
                          }}
                          className="mt-2 w-full py-1 text-[11px] font-semibold text-emerald-300 bg-emerald-950/60 hover:bg-emerald-900/60 rounded border border-emerald-800/80"
                        >
                          Select File
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              /* LIST VIEW */
              <div className="divide-y divide-slate-800 border border-slate-800 rounded-xl overflow-hidden bg-slate-900/50">
                {files.map((file) => {
                  const isFolder = file.mimeType === 'application/vnd.google-apps.folder';
                  return (
                    <div
                      key={file.id}
                      className="group flex items-center justify-between p-3 hover:bg-slate-800/70 transition-colors cursor-pointer text-xs"
                      onClick={() => {
                        if (isFolder) {
                          enterFolder(file);
                        } else if (selectMode && onSelectFile) {
                          onSelectFile(file);
                        }
                      }}
                    >
                      <div className="flex items-center gap-3 min-w-0 flex-1">
                        <div className="shrink-0">{getFileIcon(file.mimeType)}</div>
                        <div className="min-w-0 flex-1 pr-4">
                          <div className="font-semibold text-slate-200 group-hover:text-emerald-400 truncate">
                            {file.name}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {isFolder ? 'Google Drive Folder' : file.mimeType}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-6 text-slate-400 shrink-0">
                        <span className="w-16 text-right">{formatFileSize(file.size)}</span>
                        <span className="w-24 text-right hidden sm:inline">
                          {file.modifiedTime ? new Date(file.modifiedTime).toLocaleDateString() : ''}
                        </span>

                        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                          {file.webViewLink && (
                            <a
                              href={file.webViewLink}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 rounded text-slate-400 hover:text-emerald-400 hover:bg-slate-700"
                              title="Open in Drive"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <button
                            onClick={() => setFileToDelete(file)}
                            className="p-1.5 rounded text-slate-400 hover:text-rose-400 hover:bg-slate-700"
                            title="Delete file"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer Storage Quota Bar */}
          <div className="p-3 bg-slate-950/90 border-t border-slate-800 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <HardDrive className="w-4 h-4 text-emerald-400" />
              {quota ? (
                <div className="flex items-center gap-2">
                  <span>Storage: {quota.usedGB} GB of {quota.totalGB} GB used</span>
                  <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full" 
                      style={{ width: `${quota.pct}%` }} 
                    />
                  </div>
                </div>
              ) : (
                <span>Connected to Google Drive API</span>
              )}
            </div>

            <div className="text-[11px] text-slate-500">
              {files.length} items in current view
            </div>
          </div>

        </div>
      )}

      {/* NEW FOLDER MODAL */}
      {showNewFolderModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form onSubmit={handleCreateFolder} className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-sm shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <FolderPlus className="w-4 h-4 text-amber-400" />
                <span>Create New Folder</span>
              </h4>
              <button type="button" onClick={() => setShowNewFolderModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Folder Name</label>
              <input
                type="text"
                required
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="e.g. Export Trade Invoices 2025"
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-emerald-500"
                autoFocus
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowNewFolderModal(false)}
                className="px-3.5 py-1.5 rounded-lg text-xs text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300"
              >
                Create Folder
              </button>
            </div>
          </form>
        </div>
      )}

      {/* NEW NOTE / DOCUMENT MODAL */}
      {showNewDocModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form onSubmit={handleCreateDoc} className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <FilePlus className="w-4 h-4 text-blue-400" />
                <span>Create Drive Note / Text Document</span>
              </h4>
              <button type="button" onClick={() => setShowNewDocModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Document Title</label>
                <input
                  type="text"
                  required
                  value={newDocTitle}
                  onChange={(e) => setNewDocTitle(e.target.value)}
                  placeholder="e.g. Chaikosh_Export_MoU_Notes"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-emerald-500"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Document Content</label>
                <textarea
                  rows={5}
                  value={newDocContent}
                  onChange={(e) => setNewDocContent(e.target.value)}
                  placeholder="Type notes, client requirements, or trade summary..."
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowNewDocModal(false)}
                className="px-3.5 py-1.5 rounded-lg text-xs text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300"
              >
                Save to Drive
              </button>
            </div>
          </form>
        </div>
      )}

      {/* EXPLICIT CONFIRMATION DIALOG FOR DELETE (MANDATORY WORKSPACE INTEGRATION RULE) */}
      {fileToDelete && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-800/80 rounded-xl p-6 w-full max-w-md shadow-2xl space-y-4">
            <div className="w-10 h-10 rounded-full bg-rose-950 text-rose-400 flex items-center justify-center border border-rose-800">
              <Trash2 className="w-5 h-5" />
            </div>

            <div className="space-y-2">
              <h4 className="text-base font-bold text-white">Delete "{fileToDelete.name}"?</h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Are you sure you want to permanently delete this item from Google Drive? This action cannot be undone.
              </p>
            </div>

            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-400">
              <div className="font-semibold text-slate-200 truncate">{fileToDelete.name}</div>
              <div>Type: {fileToDelete.mimeType}</div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setFileToDelete(null)}
                className="px-4 py-2 rounded-lg text-xs text-slate-300 hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={confirmDeleteFile}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 transition-colors disabled:opacity-50"
              >
                {isDeleting ? 'Deleting...' : 'Yes, Delete from Drive'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
