import React, { useState } from 'react';
import { 
  Phone, Mail, MapPin, Send, CheckCircle2, 
  MessageSquare, Copy, ExternalLink, Instagram, Facebook, 
  PhoneCall, ShieldCheck, Sparkles 
} from 'lucide-react';
import { ProfileData, ServiceItem } from '../types';
import { api } from '../services/api';

interface ContactSectionProps {
  profile: ProfileData;
  services: ServiceItem[];
  prefilledService?: string;
  onInquirySubmitted?: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ 
  profile, 
  services,
  prefilledService = '',
  onInquirySubmitted
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: prefilledService || 'General Inquiry',
    message: ''
  });

  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [copiedType, setCopiedType] = useState<string | null>(null);

  // Sync if prefilledService changes
  React.useEffect(() => {
    if (prefilledService) {
      setFormData(prev => ({ ...prev, service: prefilledService }));
    }
  }, [prefilledService]);

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) return;

    setSubmitting(true);
    try {
      await api.submitInquiry(formData);
      setSubmitted(true);
      if (onInquirySubmitted) onInquirySubmitted();
      setFormData({
        name: '',
        email: '',
        phone: '',
        service: 'General Inquiry',
        message: ''
      });
    } catch (err) {
      console.error('Error submitting inquiry', err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 bg-slate-950 text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800/60">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Connect & Consult</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Let’s Discuss Your Next <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
              Venture, Tax or Export Goal
            </span>
          </h2>
          <p className="text-sm text-slate-400">
            Direct access for personal consultations, business registrations, or international trade inquiries.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Contact Details & Cards */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Direct Phone Numbers Card */}
            <div className="bg-slate-900/80 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>Direct Phone & WhatsApp Channels</span>
              </h3>

              {/* Personal Number */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    Personal & Consultancy Line
                  </span>
                  <button
                    onClick={() => handleCopy('+916001565255', 'personalPhone')}
                    className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedType === 'personalPhone' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <div className="text-base sm:text-lg font-bold text-white tracking-wide">
                  {profile.personalPhone}
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <a
                    href="tel:+916001565255"
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center gap-1"
                  >
                    <PhoneCall className="w-3 h-3 text-emerald-400" />
                    <span>Call Now</span>
                  </a>
                  <a
                    href="https://wa.me/916001565255?text=Hello%20Solman%20Choudhury,%20I%20would%20like%20to%20consult%20with%20you."
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800/60 hover:bg-emerald-900/60 flex items-center gap-1"
                  >
                    <MessageSquare className="w-3 h-3 text-emerald-400" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>

              {/* Business Number (Chaikosh) */}
              <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-teal-400 uppercase tracking-wider">
                    {profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"} (Business Line)
                  </span>
                  <button
                    onClick={() => handleCopy('+916003348068', 'businessPhone')}
                    className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copiedType === 'businessPhone' ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <div className="text-base sm:text-lg font-bold text-white tracking-wide">
                  {profile.businessPhone}
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <a
                    href="tel:+916003348068"
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center gap-1"
                  >
                    <PhoneCall className="w-3 h-3 text-teal-400" />
                    <span>Call Business</span>
                  </a>
                  <a
                    href="https://wa.me/916003348068?text=Hello%20M/S.%20CHAIKOSH%20AGRIELECTRO%20INDUSTRIES,%20I%20have%20a%20business%20inquiry."
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-teal-950 text-teal-300 border border-teal-800/60 hover:bg-teal-900/60 flex items-center gap-1"
                  >
                    <MessageSquare className="w-3 h-3 text-teal-400" />
                    <span>WhatsApp</span>
                  </a>
                </div>
              </div>

            </div>

            {/* Email & Location Card */}
            <div className="bg-slate-900/80 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-4">
              {/* Email Channels Categorized */}
              <div className="space-y-4">
                {/* Personal & Tax Consultancy */}
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800/50">
                        <Mail className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                        Personal & Tax Consultancy
                      </span>
                    </div>
                    <button
                      onClick={() => handleCopy("contact@solmanchoudhury.in", 'email-personal')}
                      className="text-[11px] text-slate-400 hover:text-emerald-400 flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedType === 'email-personal' ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <a
                    href="mailto:contact@solmanchoudhury.in"
                    className="text-xs sm:text-sm font-bold text-white hover:text-emerald-300 transition-colors block break-all font-mono pl-1"
                  >
                    contact@solmanchoudhury.in
                  </a>
                </div>

                {/* Import/Export & International Business */}
                <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 rounded-lg bg-cyan-950 text-cyan-400 border border-cyan-800/50">
                        <Mail className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
                        Import/Export & International Trade
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 pl-1">
                    <div className="flex items-center justify-between">
                      <a
                        href="mailto:admin@chaikosh.in"
                        className="text-xs sm:text-sm font-semibold text-slate-200 hover:text-cyan-300 transition-colors break-all font-mono"
                      >
                        admin@chaikosh.in
                      </a>
                      <button
                        onClick={() => handleCopy("admin@chaikosh.in", 'email-export-1')}
                        className="text-[10px] text-slate-400 hover:text-cyan-400 flex items-center gap-1 shrink-0 ml-2"
                      >
                        <Copy className="w-3 h-3" />
                        <span>{copiedType === 'email-export-1' ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-slate-800/60">
                      <a
                        href="mailto:chaikoshagrielectroindustries@gmail.com"
                        className="text-xs font-medium text-slate-300 hover:text-teal-300 transition-colors break-all font-mono"
                      >
                        chaikoshagrielectroindustries@gmail.com
                      </a>
                      <button
                        onClick={() => handleCopy("chaikoshagrielectroindustries@gmail.com", 'email-export-2')}
                        className="text-[10px] text-slate-400 hover:text-teal-400 flex items-center gap-1 shrink-0 ml-2"
                      >
                        <Copy className="w-3 h-3" />
                        <span>{copiedType === 'email-export-2' ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Real Official Address */}
              <div className="flex items-start gap-3.5 pt-4 border-t border-slate-800/70">
                <div className="p-2.5 rounded-xl bg-slate-950 text-teal-400 border border-slate-800 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400 font-medium">Real Address & Headquarters</span>
                    <button
                      onClick={() => handleCopy("Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam, PIN 788804", 'contact-address')}
                      className="text-[11px] text-emerald-400 hover:underline flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedType === 'contact-address' ? 'Copied!' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="text-sm font-semibold text-white leading-snug">
                    Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam 788804
                  </div>
                  <div className="text-xs text-slate-400">
                    Barak Valley Region • Assam, India
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive Contact / Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900/90 rounded-2xl p-6 sm:p-8 border border-slate-800 shadow-2xl relative">
              
              <h3 className="text-xl font-bold text-white mb-2">
                Send a Direct Message / Advisory Request
              </h3>
              <p className="text-xs text-slate-400 mb-6">
                Fill out the form below. Solman will review your request and reply promptly via phone, WhatsApp, or email.
              </p>

              {submitted ? (
                <div className="p-6 rounded-2xl bg-emerald-950/60 border border-emerald-800/80 text-center space-y-3 animate-in fade-in">
                  <div className="w-12 h-12 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-white">Thank You for Reaching Out!</h4>
                  <p className="text-xs text-slate-300 max-w-md mx-auto">
                    Your inquiry has been successfully sent to Solman Hussain Choudhury's desk. You will receive a response shortly.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="mt-2 text-xs font-semibold text-emerald-400 hover:underline"
                  >
                    Send another inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Your Full Name <span className="text-emerald-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Rahul Sharma"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Phone / WhatsApp Number <span className="text-emerald-400">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="e.g. +91 9876543210"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Email Address (Optional)
                      </label>
                      <input
                        type="email"
                        placeholder="e.g. rahul@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-300 mb-1.5">
                        Service Area / Topic
                      </label>
                      <select
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                      >
                        <option value="General Inquiry">General Inquiry / Consultation</option>
                        <option value="Global Trade & Export">Global Trade & Export (Chaikosh Agrielectro)</option>
                        <option value="Vehicle Insurance (New & Old Vehicles)">Vehicle Insurance (New, Old & Commercial)</option>
                        <option value="Tax & Business Consultancy">Tax, GST, Entity Registration & Loan Advisory</option>
                        <option value="Certified Insurance Planning">Life & General Insurance Planning</option>
                        <option value="Digital Solutions">Digital Solutions & Web Development</option>
                        <option value="Northeast Travel & Heritage Guidance">Northeast Travel & Expeditions Guidance</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1.5">
                      Your Message / Requirement Details
                    </label>
                    <textarea
                      rows={4}
                      placeholder="Briefly describe your requirements, questions, or business details..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 resize-none"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500">
                      ⚡ Quick Response Guarantee
                    </span>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 via-teal-300 to-emerald-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md shadow-emerald-500/20 disabled:opacity-50"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{submitting ? 'Submitting...' : 'Submit Inquiry'}</span>
                    </button>
                  </div>
                </form>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
