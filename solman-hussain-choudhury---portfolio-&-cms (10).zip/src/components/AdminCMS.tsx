import React, { useState, useRef } from 'react';
import { 
  Lock, Unlock, LayoutDashboard, FileText, Image as ImageIcon, 
  MessageSquare, User, Plus, Trash2, Edit3, Check, X, 
  Eye, RefreshCw, Upload, Link, ExternalLink, Calendar, 
  ShieldCheck, AlertCircle, CheckCircle2, Phone, Mail, HardDrive,
  LogOut, KeyRound, Send, ArrowLeft, Camera, UploadCloud, Sparkles,
  FileSpreadsheet
} from 'lucide-react';
import { AppData, Article, GalleryItem, Inquiry, ProfileData } from '../types';
import { api } from '../services/api';
import { GoogleDriveManager } from './GoogleDriveManager';
import { GoogleSheetsManager } from './GoogleSheetsManager';
import { googleSignIn, logout } from '../services/googleAuth';
import { parseImageUrl } from '../utils/imageParser';
import { 
  AUTHORIZED_ADMIN_EMAIL, 
  isAuthorizedAdmin, 
  sendFirebasePasswordReset,
  verifyResetCode,
  confirmNewPassword 
} from '../services/firebase';

interface AdminCMSProps {
  isOpen: boolean;
  onClose: () => void;
  appData: AppData;
  onDataUpdated: (newData: AppData) => void;
  defaultTab?: 'overview' | 'articles' | 'gallery' | 'inquiries' | 'profile' | 'drive' | 'sheets';
  initialOobCode?: string | null;
  initialAuthMode?: 'login' | 'resetRequest' | 'confirmReset';
  onClearResetParams?: () => void;
}

export const AdminCMS: React.FC<AdminCMSProps> = ({
  isOpen,
  onClose,
  appData,
  onDataUpdated,
  defaultTab = 'overview',
  initialOobCode = null,
  initialAuthMode = 'login',
  onClearResetParams
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  
  // Password Reset state
  const [isResetMode, setIsResetMode] = useState(initialAuthMode !== 'login');
  const [resetStep, setResetStep] = useState<'request' | 'confirm'>(initialAuthMode === 'confirmReset' || !!initialOobCode ? 'confirm' : 'request');
  const [resetMsg, setResetMsg] = useState('');
  const [resetErrorMsg, setResetErrorMsg] = useState('');
  const [isResetLoading, setIsResetLoading] = useState(false);

  // oobCode Verification & New Password Setting States
  const [oobCode, setOobCode] = useState<string>(initialOobCode || '');
  const [isVerifyingCode, setIsVerifyingCode] = useState(false);
  const [verifiedEmail, setVerifiedEmail] = useState<string | null>(null);
  const [codeVerifyError, setCodeVerifyError] = useState<string>('');
  const [newPasswordValue, setNewPasswordValue] = useState('');
  const [confirmPasswordValue, setConfirmPasswordValue] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [isSubmittingNewPassword, setIsSubmittingNewPassword] = useState(false);
  const [passwordResetSuccess, setPasswordResetSuccess] = useState(false);

  const [activeTab, setActiveTab] = useState<'overview' | 'articles' | 'gallery' | 'inquiries' | 'profile' | 'drive' | 'sheets'>(defaultTab);

  // Settings credentials form state
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [currentAdminPassword, setCurrentAdminPassword] = useState('');
  const [credSaveMsg, setCredSaveMsg] = useState('');
  const [credErrorMsg, setCredErrorMsg] = useState('');

  // Article Form State
  const [editingArticle, setEditingArticle] = useState<Partial<Article> | null>(null);
  const [articleForm, setArticleForm] = useState({
    title: '',
    category: 'Global Trade',
    tags: 'Export, Business',
    coverImage: '',
    excerpt: '',
    readTime: '5 min read',
    publishedDate: new Date().toISOString().split('T')[0],
    isPublished: true,
    content: ''
  });

  // Gallery Form State
  const [editingGalleryItem, setEditingGalleryItem] = useState<Partial<GalleryItem> | null>(null);
  const [galleryForm, setGalleryForm] = useState({
    title: '',
    category: 'Northeast Expeditions' as const,
    mediaType: 'image' as 'image' | 'video',
    url: '',
    caption: '',
    date: new Date().toISOString().split('T')[0]
  });

  // Profile Form State
  const [profileForm, setProfileForm] = useState<ProfileData>(appData.profile);
  const [savingStatus, setSavingStatus] = useState<string | null>(null);

  // Executive Photo Upload Studio States
  const [isPhotoUploading, setIsPhotoUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [photoUploadMsg, setPhotoUploadMsg] = useState<{ type: 'success' | 'error'; text: string; storageType?: string } | null>(null);
  const [isDraggingPhoto, setIsDraggingPhoto] = useState(false);
  const [directPhotoUrlInput, setDirectPhotoUrlInput] = useState('');
  const photoFileInputRef = useRef<HTMLInputElement>(null);

  // Reset or initialize on open
  React.useEffect(() => {
    setProfileForm(appData.profile);
  }, [appData.profile]);

  // Logout handler
  const handleLogout = async () => {
    setIsLoggingIn(true);
    try {
      await logout();
    } catch (err) {
      console.warn('Logout warning:', err);
    } finally {
      setIsAuthenticated(false);
      setPassword('');
      setAuthSuccess('');
      setAuthError('You have successfully signed out. CMS session is locked.');
      setIsLoggingIn(false);
      setActiveTab('overview');
      setEditingArticle(null);
      setEditingGalleryItem(null);
    }
  };

  const handleGoogleLogin = async () => {
    setAuthError('');
    setAuthSuccess('');
    setIsLoggingIn(true);
    try {
      const res = await googleSignIn();
      if (res && res.user) {
        const userEmail = (res.user.email || '').trim().toLowerCase();
        if (userEmail === AUTHORIZED_ADMIN_EMAIL.toLowerCase() || res.isAuthorized) {
          setIsAuthenticated(true);
          setAdminEmail(AUTHORIZED_ADMIN_EMAIL);
          setAuthSuccess(`Welcome Solman! Authenticated as ${res.user.email}. Access granted to editing pages.`);
        } else {
          setIsAuthenticated(false);
          setAuthError(`Access Denied: You are not authorized for administrator access.`);
        }
      }
    } catch (err: any) {
      setAuthError(err.message || 'Google authentication failed.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setIsLoggingIn(true);

    try {
      const cleanEmail = adminEmail.trim().toLowerCase();
      if (cleanEmail !== AUTHORIZED_ADMIN_EMAIL.toLowerCase()) {
        setAuthError(`Wrong user ID and password. Access denied.`);
        setIsLoggingIn(false);
        return;
      }

      const res = await api.login(adminEmail.trim(), password);
      if (res.success) {
        setIsAuthenticated(true);
        setAuthSuccess('Authenticated successfully! Access granted.');
      } else {
        setAuthError(res.error || 'Authentication failed. Please check your credentials.');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Login request error');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Auto verify oobCode when available
  const verifyCode = async (codeToVerify: string) => {
    if (!codeToVerify.trim()) return;
    setIsVerifyingCode(true);
    setCodeVerifyError('');
    try {
      const email = await verifyResetCode(codeToVerify.trim());
      setVerifiedEmail(email || AUTHORIZED_ADMIN_EMAIL);
      setIsResetMode(true);
      setResetStep('confirm');
    } catch (err: any) {
      console.error('oobCode verification error:', err);
      setCodeVerifyError(err.message || 'The password reset link or code is invalid or has expired. Please request a fresh reset link.');
      setResetStep('confirm');
    } finally {
      setIsVerifyingCode(false);
    }
  };

  React.useEffect(() => {
    if (initialOobCode) {
      setOobCode(initialOobCode);
      setIsResetMode(true);
      setResetStep('confirm');
      verifyCode(initialOobCode);
    }
  }, [initialOobCode]);

  // Handle manual code verification submit
  const handleVerifyManualCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!oobCode.trim()) {
      setCodeVerifyError('Please enter or paste the verification code (oobCode).');
      return;
    }
    await verifyCode(oobCode);
  };

  // Direct Password reset via secure email link
  const handleSendPasswordReset = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setResetMsg('');
    setResetErrorMsg('');
    setIsResetLoading(true);
    try {
      const targetEmail = adminEmail.trim() || AUTHORIZED_ADMIN_EMAIL;
      const res = await sendFirebasePasswordReset(targetEmail);
      setResetMsg(res.message);
    } catch (err: any) {
      setResetErrorMsg(err.message || 'Failed to send password reset email.');
    } finally {
      setIsResetLoading(false);
    }
  };

  // Confirm and set new password with oobCode
  const handleConfirmNewPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetErrorMsg('');
    if (!newPasswordValue || newPasswordValue.length < 6) {
      setResetErrorMsg('New password must be at least 6 characters.');
      return;
    }
    if (newPasswordValue !== confirmPasswordValue) {
      setResetErrorMsg('Passwords do not match. Please ensure both fields are identical.');
      return;
    }
    if (!oobCode.trim()) {
      setResetErrorMsg('Action code (oobCode) is missing. Please request a new password reset link.');
      return;
    }

    setIsSubmittingNewPassword(true);
    try {
      // 1. Commit with Firebase Auth
      await confirmNewPassword(oobCode.trim(), newPasswordValue);

      // 2. Synchronize with backend authentication store
      const targetEmail = verifiedEmail || AUTHORIZED_ADMIN_EMAIL;
      await api.syncPassword(targetEmail, newPasswordValue);

      setPasswordResetSuccess(true);
      setResetMsg(`Password has been successfully updated for ${targetEmail}! You can now sign in with your new password.`);
      
      // Prefill login email and password
      setAdminEmail(targetEmail);
      setPassword(newPasswordValue);

      if (onClearResetParams) {
        onClearResetParams();
      }
    } catch (err: any) {
      console.error('Password reset confirmation failed:', err);
      setResetErrorMsg(err.message || 'Failed to update password. The link or code may have expired.');
    } finally {
      setIsSubmittingNewPassword(false);
    }
  };

  const handleSaveCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setCredSaveMsg('');
    setCredErrorMsg('');

    if (!newAdminPassword.trim()) {
      setCredErrorMsg('Please provide a new password.');
      return;
    }

    try {
      const res = await api.changeCredentials(currentAdminPassword.trim(), newAdminPassword.trim(), true);
      if (res.success) {
        setCredSaveMsg('Admin password updated successfully! You can now log in with your new password.');
        setCurrentAdminPassword('');
        setNewAdminPassword('');
        setTimeout(() => setCredSaveMsg(''), 5000);
      } else {
        setCredErrorMsg(res.error || 'Failed to update credentials.');
      }
    } catch (err: any) {
      setCredErrorMsg(err.message || 'Error updating credentials');
    }
  };

  // Article handlers
  const handleOpenArticleEditor = (article?: Article) => {
    if (article) {
      setEditingArticle(article);
      setArticleForm({
        title: article.title,
        category: article.category,
        tags: article.tags?.join(', ') || '',
        coverImage: article.coverImage,
        excerpt: article.excerpt,
        readTime: article.readTime,
        publishedDate: article.publishedDate,
        isPublished: article.isPublished,
        content: article.content
      });
    } else {
      setEditingArticle({ id: `art-${Date.now()}` });
      setArticleForm({
        title: '',
        category: 'Global Trade',
        tags: 'Export, Trade, Assam',
        coverImage: 'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=1200&q=80',
        excerpt: '',
        readTime: '4 min read',
        publishedDate: new Date().toISOString().split('T')[0],
        isPublished: true,
        content: ''
      });
    }
  };

  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!articleForm.title.trim()) return;

    setSavingStatus('Saving article...');
    try {
      const tagsArray = articleForm.tags
        .split(',')
        .map(t => t.trim())
        .filter(Boolean);

      const saved = await api.saveArticle({
        id: editingArticle?.id,
        title: articleForm.title,
        category: articleForm.category,
        tags: tagsArray,
        coverImage: articleForm.coverImage || 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1200&q=80',
        excerpt: articleForm.excerpt,
        readTime: articleForm.readTime,
        publishedDate: articleForm.publishedDate,
        isPublished: articleForm.isPublished,
        content: articleForm.content
      });

      const updated = await api.getData();
      onDataUpdated(updated);
      setEditingArticle(null);
      setSavingStatus('Article published successfully!');
      setTimeout(() => setSavingStatus(null), 2500);
    } catch (err) {
      console.error(err);
      setSavingStatus('Error saving article');
    }
  };

  const handleDeleteArticle = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this article?')) return;
    await api.deleteArticle(id);
    const updated = await api.getData();
    onDataUpdated(updated);
  };

  // Gallery handlers
  const handleOpenGalleryEditor = (item?: GalleryItem) => {
    if (item) {
      setEditingGalleryItem(item);
      setGalleryForm({
        title: item.title,
        category: item.category as any,
        mediaType: item.mediaType,
        url: item.url,
        caption: item.caption,
        date: item.date
      });
    } else {
      setEditingGalleryItem({ id: `gal-${Date.now()}` });
      setGalleryForm({
        title: '',
        category: 'Northeast Expeditions',
        mediaType: 'image',
        url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
        caption: '',
        date: new Date().toISOString().split('T')[0]
      });
    }
  };

  const handleSaveGalleryItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!galleryForm.title.trim() || !galleryForm.url.trim()) return;

    setSavingStatus('Saving media item...');
    try {
      await api.saveGalleryItem({
        id: editingGalleryItem?.id,
        title: galleryForm.title,
        category: galleryForm.category,
        mediaType: galleryForm.mediaType,
        url: galleryForm.url,
        caption: galleryForm.caption,
        date: galleryForm.date
      });

      const updated = await api.getData();
      onDataUpdated(updated);
      setEditingGalleryItem(null);
      setSavingStatus('Media uploaded to gallery!');
      setTimeout(() => setSavingStatus(null), 2500);
    } catch (err) {
      console.error(err);
      setSavingStatus('Error saving media item');
    }
  };

  const handleDeleteGalleryItem = async (id: string) => {
    if (!window.confirm('Delete this gallery item?')) return;
    await api.deleteGalleryItem(id);
    const updated = await api.getData();
    onDataUpdated(updated);
  };

  // Inquiry handlers
  const handleUpdateInquiryStatus = async (id: string, status: 'new' | 'replied' | 'archived') => {
    await api.updateInquiryStatus(id, status);
    const updated = await api.getData();
    onDataUpdated(updated);
  };

  const handleDeleteInquiry = async (id: string) => {
    if (!window.confirm('Delete this message?')) return;
    await api.deleteInquiry(id);
    const updated = await api.getData();
    onDataUpdated(updated);
  };

  // Profile Save handler
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingStatus('Updating profile...');
    try {
      await api.updateProfile(profileForm);
      const updated = await api.getData();
      onDataUpdated(updated);
      setSavingStatus('Profile details updated!');
      setTimeout(() => setSavingStatus(null), 2500);
    } catch (err) {
      console.error(err);
      setSavingStatus('Error updating profile');
    }
  };

  // Reset to default seed
  const handleResetData = async () => {
    if (!window.confirm('Reset all CMS content to default portfolio template data?')) return;
    const data = await api.resetData();
    onDataUpdated(data);
    setProfileForm(data.profile);
    setSavingStatus('Data reset to default!');
    setTimeout(() => setSavingStatus(null), 2500);
  };

  // Handler for uploading Official Executive Photo with Cloud Storage & Database Sync
  const handleExecutivePhotoFileSelect = async (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setPhotoUploadMsg({ type: 'error', text: 'Please choose a valid image file (JPG, PNG, WebP, etc.).' });
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      setPhotoUploadMsg({ type: 'error', text: 'Image file size exceeds 25MB limit. Please choose a smaller photo.' });
      return;
    }

    setIsPhotoUploading(true);
    setUploadProgress(15);
    setPhotoUploadMsg(null);

    try {
      const res = await api.uploadExecutivePhoto(file, (pct) => {
        setUploadProgress(pct);
      });

      setProfileForm(prev => ({ ...prev, avatarUrl: res.url }));
      const updated = await api.getData();
      onDataUpdated(updated);

      setPhotoUploadMsg({
        type: 'success',
        text: `Official Executive Photo uploaded successfully and synchronized with Cloud Storage (${res.storageType === 'firebase-storage' ? 'Firebase Cloud Storage' : 'Cloud Server'}) & Firestore Database!`,
        storageType: res.storageType
      });
      setSavingStatus('Official Executive Photo updated on public website!');
      setTimeout(() => setSavingStatus(null), 3500);
    } catch (err: any) {
      console.error('Executive Photo upload error:', err);
      setPhotoUploadMsg({
        type: 'error',
        text: err.message || 'Failed to upload photo. Please check your network connection.'
      });
    } finally {
      setIsPhotoUploading(false);
    }
  };

  const handleApplyDirectPhotoUrl = async () => {
    if (!directPhotoUrlInput.trim()) return;
    setIsPhotoUploading(true);
    setPhotoUploadMsg(null);
    try {
      const newUrl = parseImageUrl(directPhotoUrlInput.trim());
      setProfileForm(prev => ({ ...prev, avatarUrl: newUrl }));
      await api.updateProfile({ avatarUrl: newUrl });
      const updated = await api.getData();
      onDataUpdated(updated);
      setPhotoUploadMsg({
        type: 'success',
        text: 'Official Executive Photo URL applied & saved to database!'
      });
      setDirectPhotoUrlInput('');
      setSavingStatus('Official Executive Photo updated on public website!');
      setTimeout(() => setSavingStatus(null), 3500);
    } catch (err: any) {
      setPhotoUploadMsg({
        type: 'error',
        text: 'Failed to update photo URL.'
      });
    } finally {
      setIsPhotoUploading(false);
    }
  };

  const handleResetToDefaultPhoto = async () => {
    if (!window.confirm('Reset the Official Executive Photo to default portrait?')) return;
    setIsPhotoUploading(true);
    try {
      const defaultPhoto = '/images/solman_choudhury.jpg';
      setProfileForm(prev => ({ ...prev, avatarUrl: defaultPhoto }));
      await api.updateProfile({ avatarUrl: defaultPhoto });
      const updated = await api.getData();
      onDataUpdated(updated);
      setPhotoUploadMsg({
        type: 'success',
        text: 'Official Executive Photo reset to standard default portrait.'
      });
      setSavingStatus('Photo reset to default!');
      setTimeout(() => setSavingStatus(null), 3500);
    } catch (err: any) {
      setPhotoUploadMsg({
        type: 'error',
        text: 'Failed to reset photo.'
      });
    } finally {
      setIsPhotoUploading(false);
    }
  };

  // File Upload Helper to convert local image to data URL for articles/gallery
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'article' | 'gallery' | 'avatar') => {
    const file = e.target.files?.[0];
    if (file) {
      if (target === 'avatar') {
        handleExecutivePhotoFileSelect(file);
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        if (target === 'article') {
          setArticleForm(prev => ({ ...prev, coverImage: base64 }));
        } else if (target === 'gallery') {
          setGalleryForm(prev => ({ ...prev, url: base64 }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // If CMS modal is closed, render nothing
  if (!isOpen) return null;

  // If Not Authenticated: Render focused, high-contrast Admin Login / Password Recovery Dialog
  if (!isAuthenticated) {
    return (
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200"
        onClick={(e) => {
          if (e.target === e.currentTarget) onClose();
        }}
      >
        <div className="w-full max-w-md bg-slate-900 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 my-auto text-slate-200 max-h-[92vh] overflow-y-auto animate-in zoom-in-95 duration-200">
          
          {/* Header with Close Button */}
          <div className="flex items-start justify-between pb-2 border-b border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-950 text-emerald-400 flex items-center justify-center border border-emerald-800 shadow-inner shrink-0">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
                  <span>{isResetMode ? 'Password Recovery' : 'Admin CMS Portal'}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/80">
                    v2.0
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  {isResetMode ? 'Verify credentials & set new password' : 'Executive management login'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors shrink-0"
              title="Close and return to website"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {!isResetMode ? (
            /* Primary Email + Password Login Form */
            <form onSubmit={handleLogin} className="space-y-4">
              {/* Email Field */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Admin Account Email</span>
                </label>
                <input
                  type="email"
                  required
                  placeholder="Enter authorized administrator email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500 placeholder-slate-500 font-mono"
                  autoFocus
                />
              </div>

              {/* Password Field with View Toggle */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Admin Secret Password</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[11px] text-slate-400 hover:text-emerald-400 flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3 h-3" />
                    <span>{showPassword ? 'Hide' : 'Show'}</span>
                  </button>
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Enter your confidential admin password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500 placeholder-slate-500 font-mono"
                />
              </div>

              {authError && (
                <div className="text-xs text-amber-400 bg-amber-950/40 p-3 rounded-xl border border-amber-800/60 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{authError}</span>
                </div>
              )}

              {authSuccess && (
                <div className="text-xs text-emerald-400 bg-emerald-950/40 p-3 rounded-xl border border-emerald-800/60 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{authSuccess}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoggingIn}
                className="w-full py-3 px-4 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Unlock className="w-4 h-4" />
                <span>{isLoggingIn ? 'Verifying Secure Token...' : 'Authenticate & Unlock CMS'}</span>
              </button>

              <div className="relative my-3 flex items-center justify-center">
                <div className="border-t border-slate-800 w-full"></div>
                <span className="bg-slate-900 px-2 text-[10px] text-slate-500 uppercase tracking-wider">or sign in with</span>
                <div className="border-t border-slate-800 w-full"></div>
              </div>

              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={isLoggingIn}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-white bg-slate-950 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500 transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50 cursor-pointer"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Sign In with Authorized Google Account</span>
              </button>

              <div className="pt-2 text-right text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setIsResetMode(true);
                    setResetMsg('');
                  }}
                  className="text-emerald-400 hover:text-emerald-300 underline font-medium inline-flex items-center gap-1 cursor-pointer"
                >
                  <KeyRound className="w-3 h-3" />
                  <span>Forgot password? Reset</span>
                </button>
              </div>

              <div className="pt-2 text-center border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={onClose}
                  className="text-xs text-slate-400 hover:text-white inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Cancel & Return to Website</span>
                </button>
              </div>
            </form>
          ) : (
            /* Password Reset / Recovery Flow */
            <div className="space-y-4">
              {/* Step Selector Tabs inside Recovery */}
              <div className="flex items-center p-1 bg-slate-950 rounded-xl border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => { setResetStep('request'); setResetErrorMsg(''); setResetMsg(''); }}
                  className={`flex-1 py-1.5 px-2 rounded-lg font-medium transition-all ${
                    resetStep === 'request'
                      ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  1. Request Email Link
                </button>
                <button
                  type="button"
                  onClick={() => { setResetStep('confirm'); setResetErrorMsg(''); setResetMsg(''); }}
                  className={`flex-1 py-1.5 px-2 rounded-lg font-medium transition-all ${
                    resetStep === 'confirm'
                      ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  2. Set New Password
                </button>
              </div>

              {resetStep === 'request' ? (
                /* Step 1: Request Reset Email */
                <form onSubmit={handleSendPasswordReset} className="space-y-4">
                  <div className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800">
                    <div className="flex items-center gap-2 mb-1.5 text-xs font-semibold text-emerald-400">
                      <Mail className="w-4 h-4" />
                      <span>Dispatch Password Reset Link</span>
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      A direct Firebase password reset link configured with custom in-app redirect will be sent to your registered inbox.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Authorized Administrator Email
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="Enter authorized admin email"
                      value={adminEmail}
                      onChange={(e) => setAdminEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  {resetMsg && (
                    <div className="text-xs text-emerald-300 bg-emerald-950/70 p-3 rounded-xl border border-emerald-800 flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                      <div className="space-y-1">
                        <p className="font-semibold">{resetMsg}</p>
                        <p className="text-[11px] text-emerald-400/80">
                          When you click the link in your email, it will automatically open the password setup screen below.
                        </p>
                      </div>
                    </div>
                  )}

                  {resetErrorMsg && (
                    <div className="text-xs text-rose-300 bg-rose-950/70 p-3 rounded-xl border border-rose-800 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                      <span>{resetErrorMsg}</span>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={isResetLoading}
                    className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 flex items-center justify-center gap-2 shadow disabled:opacity-50 transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isResetLoading ? 'Dispatching Reset Link...' : 'Send Password Reset Email'}</span>
                  </button>

                  <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                    <span>Already have a reset code (oobCode)?</span>
                    <button
                      type="button"
                      onClick={() => setResetStep('confirm')}
                      className="text-emerald-400 hover:text-emerald-300 underline font-medium cursor-pointer"
                    >
                      Enter Code
                    </button>
                  </div>
                </form>
              ) : (
                /* Step 2: Confirm New Password with oobCode */
                <div className="space-y-4">
                  {isVerifyingCode && (
                    <div className="p-4 rounded-xl bg-slate-950 border border-emerald-800/80 flex items-center justify-center gap-3 text-xs text-emerald-300">
                      <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                      <span>Verifying secure action token with Firebase Auth...</span>
                    </div>
                  )}

                  {codeVerifyError && (
                    <div className="p-3.5 rounded-xl bg-rose-950/70 border border-rose-800 text-xs text-rose-300 space-y-2">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                        <div>
                          <p className="font-semibold">Verification Notice</p>
                          <p className="text-[11px] text-rose-300/80">{codeVerifyError}</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => { setResetStep('request'); setCodeVerifyError(''); }}
                        className="text-[11px] text-emerald-400 hover:text-emerald-300 underline font-medium block cursor-pointer"
                      >
                        ← Click here to request a fresh password reset email
                      </button>
                    </div>
                  )}

                  {/* Verified Badge */}
                  {verifiedEmail && (
                    <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-700/80 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span className="font-medium text-emerald-200">Verified Account:</span>
                      </div>
                      <span className="font-mono font-bold text-emerald-300">{verifiedEmail}</span>
                    </div>
                  )}

                  {passwordResetSuccess ? (
                    <div className="p-4 rounded-xl bg-emerald-950/90 border border-emerald-600 text-center space-y-3">
                      <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40">
                        <Check className="w-5 h-5" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-sm font-bold text-white">Password Updated Successfully!</h4>
                        <p className="text-xs text-emerald-300">
                          Your new administrator credentials have been saved in Firebase and the secure database.
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setIsResetMode(false);
                          setResetStep('request');
                          setPasswordResetSuccess(false);
                        }}
                        className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition-all shadow cursor-pointer"
                      >
                        Proceed to Sign In
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handleConfirmNewPassword} className="space-y-3.5">
                      {/* oobCode Input (Editable or Auto-filled) */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                            <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
                            <span>Firebase Action Code (oobCode)</span>
                          </label>
                          {oobCode && (
                            <button
                              type="button"
                              onClick={() => verifyCode(oobCode)}
                              className="text-[10px] text-emerald-400 hover:underline font-mono cursor-pointer"
                            >
                              Re-verify
                            </button>
                          )}
                        </div>
                        <input
                          type="text"
                          required
                          placeholder="Paste the oobCode from your email link if not auto-filled"
                          value={oobCode}
                          onChange={(e) => {
                            setOobCode(e.target.value);
                            setCodeVerifyError('');
                          }}
                          className="w-full px-3.5 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-emerald-500 focus:outline-none"
                        />
                        <p className="text-[10px] text-slate-500 mt-0.5">
                          Auto-captured from the reset link URL parameter.
                        </p>
                      </div>

                      {/* New Password */}
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5 text-emerald-400" />
                            <span>New Confidential Password</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => setShowNewPassword(!showNewPassword)}
                            className="text-[10px] text-slate-400 hover:text-emerald-400 flex items-center gap-1 cursor-pointer"
                          >
                            <Eye className="w-3 h-3" />
                            <span>{showNewPassword ? 'Hide' : 'Show'}</span>
                          </button>
                        </div>
                        <input
                          type={showNewPassword ? 'text' : 'password'}
                          required
                          placeholder="Enter your new secure password (min 6 chars)"
                          value={newPasswordValue}
                          onChange={(e) => setNewPasswordValue(e.target.value)}
                          className="w-full px-3.5 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-emerald-500 focus:outline-none"
                        />
                      </div>

                      {/* Confirm New Password */}
                      <div>
                        <label className="block text-xs font-semibold text-slate-300 mb-1">
                          Confirm New Password
                        </label>
                        <input
                          type={showNewPassword ? 'text' : 'password'}
                          required
                          placeholder="Repeat new password exactly"
                          value={confirmPasswordValue}
                          onChange={(e) => setConfirmPasswordValue(e.target.value)}
                          className="w-full px-3.5 py-2 text-xs bg-slate-950 border border-slate-700 rounded-xl text-white font-mono focus:border-emerald-500 focus:outline-none"
                        />
                      </div>

                      {resetErrorMsg && (
                        <div className="text-xs text-rose-300 bg-rose-950/70 p-3 rounded-xl border border-rose-800 flex items-start gap-2">
                          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
                          <span>{resetErrorMsg}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={isSubmittingNewPassword || isVerifyingCode}
                        className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                        <span>{isSubmittingNewPassword ? 'Committing New Password...' : 'Save & Set New Admin Password'}</span>
                      </button>
                    </form>
                  )}
                </div>
              )}

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setIsResetMode(false);
                    setResetMsg('');
                    setResetErrorMsg('');
                  }}
                  className="text-xs text-slate-400 hover:text-white underline inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sign In</span>
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    );
  }

  // Authenticated State: Full-Featured Admin Panel / CMS Portal
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-6xl h-[94vh] flex flex-col shadow-2xl overflow-hidden text-slate-200">
        
        {/* Top Title Bar */}
        <div className="bg-slate-950 p-4 px-6 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-slate-950 font-black text-sm">
              <Lock className="w-4 h-4 text-slate-950" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>Solman Hussain Choudhury</span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  CMS v2.0
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">Content Management & Administration Dashboard</p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {savingStatus && (
              <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800 animate-pulse">
                {savingStatus}
              </span>
            )}
            
            {/* Prominent Header Logout Button */}
            <button
              type="button"
              onClick={handleLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-300 bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800/80 transition-all hover:scale-105 active:scale-95 shadow-sm cursor-pointer"
              title="Sign out of Admin CMS"
            >
              <LogOut className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">Logout</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
              title="Close CMS modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Main Authenticated CMS Workspace */}
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            
            {/* Sidebar Navigation */}
            <div className="w-full md:w-56 bg-slate-950 p-3 border-r border-slate-800 flex md:flex-col gap-1 overflow-x-auto shrink-0">
              <button
                onClick={() => { setActiveTab('overview'); setEditingArticle(null); setEditingGalleryItem(null); }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                  activeTab === 'overview' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <LayoutDashboard className="w-4 h-4 shrink-0" />
                <span>Dashboard</span>
              </button>

              <button
                onClick={() => { setActiveTab('articles'); setEditingArticle(null); }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                  activeTab === 'articles' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FileText className="w-4 h-4 shrink-0" />
                  <span>Articles / Blog</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">
                  {appData.articles.length}
                </span>
              </button>

              <button
                onClick={() => { setActiveTab('gallery'); setEditingGalleryItem(null); }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                  activeTab === 'gallery' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ImageIcon className="w-4 h-4 shrink-0" />
                  <span>Media Gallery</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300">
                  {appData.gallery.length}
                </span>
              </button>

              <button
                onClick={() => { setActiveTab('inquiries'); setEditingArticle(null); setEditingGalleryItem(null); }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                  activeTab === 'inquiries' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <MessageSquare className="w-4 h-4 shrink-0" />
                  <span>Client Inquiries</span>
                </div>
                {appData.inquiries.filter(i => i.status === 'new').length > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 font-bold animate-pulse">
                    {appData.inquiries.filter(i => i.status === 'new').length}
                  </span>
                )}
              </button>

              <button
                onClick={() => { setActiveTab('profile'); setEditingArticle(null); setEditingGalleryItem(null); }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                  activeTab === 'profile' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <User className="w-4 h-4 shrink-0" />
                <span>Profile & Settings</span>
              </button>

              <button
                onClick={() => { setActiveTab('drive'); setEditingArticle(null); setEditingGalleryItem(null); }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                  activeTab === 'drive' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <HardDrive className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Google Drive Storage</span>
              </button>

              <button
                onClick={() => { setActiveTab('sheets'); setEditingArticle(null); setEditingGalleryItem(null); }}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-medium transition-all text-left ${
                  activeTab === 'sheets' ? 'bg-emerald-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-900'
                }`}
              >
                <FileSpreadsheet className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>Google Sheets CRM</span>
              </button>

              <div className="mt-auto hidden md:block pt-4 border-t border-slate-800/80 space-y-2">
                <button
                  onClick={handleResetData}
                  className="w-full text-left px-3 py-2 rounded-lg text-[11px] text-slate-400 hover:text-amber-400 hover:bg-slate-900 flex items-center gap-2"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Seed Data</span>
                </button>
                
                {/* Prominent Sidebar Logout Button */}
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-3 py-2 rounded-lg text-[11px] text-rose-400 hover:text-rose-300 hover:bg-rose-950/60 border border-rose-900/40 flex items-center gap-2 transition-all font-medium"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-400" />
                  <span>Sign Out (Logout)</span>
                </button>
              </div>
            </div>

            {/* Tab Workspace Content */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-900">
              
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-white">Dashboard Overview</h3>
                      <p className="text-xs text-slate-400">Welcome to your portfolio administration control room.</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleLogout}
                        className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-rose-300 bg-rose-950/60 hover:bg-rose-900 border border-rose-800/80 transition-all flex items-center gap-1.5 shadow-sm"
                      >
                        <LogOut className="w-3.5 h-3.5 text-rose-400" />
                        <span>Logout Session</span>
                      </button>
                    </div>
                  </div>

                  {/* Authenticated Admin Session Banner */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border border-emerald-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800/80 flex items-center justify-center font-bold">
                        <ShieldCheck className="w-5 h-5 text-emerald-400" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">Authorized Admin Session Active</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
                            VERIFIED
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 font-mono">
                          Authorized Executive Account
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <button
                        onClick={() => setActiveTab('profile')}
                        className="flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 flex items-center justify-center gap-1.5 border border-slate-700"
                      >
                        <KeyRound className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Security & Password</span>
                      </button>
                      <button
                        onClick={handleLogout}
                        className="flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-xs font-bold text-rose-400 hover:text-white bg-rose-950/80 hover:bg-rose-900 border border-rose-800 flex items-center justify-center gap-1.5 transition-all"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Logout</span>
                      </button>
                    </div>
                  </div>

                  {/* Metrics Bento Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-xs text-slate-400">Total Articles</div>
                      <div className="text-2xl font-bold text-white mt-1">{appData.articles.length}</div>
                      <div className="text-[11px] text-emerald-400 mt-1">
                        {appData.articles.filter(a => a.isPublished).length} Published
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-xs text-slate-400">Gallery Media</div>
                      <div className="text-2xl font-bold text-white mt-1">{appData.gallery.length}</div>
                      <div className="text-[11px] text-teal-400 mt-1">Photos & Videos</div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-xs text-slate-400">Client Inquiries</div>
                      <div className="text-2xl font-bold text-white mt-1">{appData.inquiries.length}</div>
                      <div className="text-[11px] text-amber-400 mt-1">
                        {appData.inquiries.filter(i => i.status === 'new').length} New Unread
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-xs text-slate-400">Export Venture</div>
                      <div className="text-xs font-bold text-white mt-1 truncate">Chaikosh Agrielectro</div>
                      <div className="text-[11px] text-emerald-400 mt-1">Active Exporter</div>
                    </div>
                  </div>

                  {/* Quick Action Buttons */}
                  <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">Quick Actions</h4>
                    <div className="flex flex-wrap gap-3">
                      <button
                        onClick={() => { setActiveTab('profile'); }}
                        className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 hover:from-emerald-400 hover:to-teal-300 flex items-center gap-1.5 shadow-md active:scale-95 transition-all"
                      >
                        <Camera className="w-3.5 h-3.5" />
                        <span>Update Official Executive Photo</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('articles'); handleOpenArticleEditor(); }}
                        className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-500 text-slate-950 hover:bg-emerald-400 flex items-center gap-1.5"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Publish New Article</span>
                      </button>

                      <button
                        onClick={() => { setActiveTab('gallery'); handleOpenGalleryEditor(); }}
                        className="px-4 py-2 rounded-xl text-xs font-semibold bg-teal-500 text-slate-950 hover:bg-teal-400 flex items-center gap-1.5"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Photo / Video</span>
                      </button>

                      <button
                        onClick={() => setActiveTab('inquiries')}
                        className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 flex items-center gap-1.5"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Check Inquiries</span>
                      </button>
                    </div>
                  </div>

                  {/* Executive Hero & Official Photo Status Card */}
                  <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-2xl overflow-hidden bg-slate-900 border-2 border-emerald-500/50 relative shadow-lg shrink-0">
                        <img
                          src={profileForm.avatarUrl || "/images/solman_choudhury.jpg"}
                          alt="Executive portrait preview"
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover object-top"
                        />
                        <div className="absolute bottom-0 inset-x-0 bg-emerald-950/80 text-[8px] font-bold text-center text-emerald-300 py-0.5 border-t border-emerald-700/50">
                          LIVE
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-white">Official Executive Photo</h4>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                            Cloud Synced
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          Currently featured on Homepage Hero & Official Portfolios.
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setActiveTab('profile')}
                      className="px-4 py-2 rounded-xl text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 transition-all flex items-center gap-1.5 shrink-0 shadow-sm"
                    >
                      <UploadCloud className="w-3.5 h-3.5" />
                      <span>Change Photo in Studio</span>
                    </button>
                  </div>

                  {/* Recent Inquiries Preview */}
                  <div className="bg-slate-950 rounded-xl p-5 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                        Recent Client Inquiries
                      </h4>
                      <button
                        onClick={() => setActiveTab('inquiries')}
                        className="text-xs text-emerald-400 hover:underline"
                      >
                        View All
                      </button>
                    </div>

                    <div className="divide-y divide-slate-800/80">
                      {appData.inquiries.slice(0, 3).map((inq) => (
                        <div key={inq.id} className="py-3 flex items-start justify-between gap-4">
                          <div>
                            <div className="text-xs font-bold text-white flex items-center gap-2">
                              <span>{inq.name}</span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                                {inq.service}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400 mt-1 line-clamp-1">{inq.message}</div>
                          </div>
                          <a
                            href={`https://wa.me/${inq.phone.replace(/[^0-9]/g, '')}`}
                            target="_blank"
                            rel="noreferrer"
                            className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 text-[11px] font-semibold hover:bg-emerald-900 shrink-0"
                          >
                            Reply WhatsApp
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              )}

              {/* TAB 2: ARTICLES / BLOG */}
              {activeTab === 'articles' && (
                <div className="space-y-6">
                  {!editingArticle ? (
                    <>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-xl font-bold text-white">Articles & Insights CMS</h3>
                          <p className="text-xs text-slate-400">Write, edit, and publish blog articles on your website.</p>
                        </div>
                        <button
                          onClick={() => handleOpenArticleEditor()}
                          className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 flex items-center gap-1.5 shadow-md"
                        >
                          <Plus className="w-4 h-4" />
                          <span>New Article</span>
                        </button>
                      </div>

                      <div className="divide-y divide-slate-800 bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden">
                        {appData.articles.map((art) => (
                          <div key={art.id} className="p-4 flex items-center justify-between gap-4 hover:bg-slate-900/60 transition-colors">
                            <div className="flex items-center gap-4 min-w-0">
                              <img
                                src={art.coverImage}
                                alt={art.title}
                                referrerPolicy="no-referrer"
                                className="w-16 h-12 object-cover rounded-lg bg-slate-800 shrink-0"
                              />
                              <div className="min-w-0">
                                <h4 className="text-xs sm:text-sm font-bold text-white truncate">{art.title}</h4>
                                <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1">
                                  <span className="text-emerald-400 font-medium">{art.category}</span>
                                  <span>•</span>
                                  <span>{art.publishedDate}</span>
                                  <span>•</span>
                                  <span className={art.isPublished ? 'text-emerald-400' : 'text-amber-400'}>
                                    {art.isPublished ? 'Published' : 'Draft'}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() => handleOpenArticleEditor(art)}
                                className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700"
                                title="Edit Article"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteArticle(art.id)}
                                className="p-2 rounded-lg bg-slate-800 text-red-400 hover:text-red-300 hover:bg-red-950"
                                title="Delete Article"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : (
                    /* Article Editor Form */
                    <form onSubmit={handleSaveArticle} className="space-y-4 bg-slate-950 p-6 rounded-2xl border border-slate-800 text-xs">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <h4 className="text-sm font-bold text-white">
                          {editingArticle.title ? 'Edit Article' : 'Write New Article'}
                        </h4>
                        <button
                          type="button"
                          onClick={() => setEditingArticle(null)}
                          className="text-slate-400 hover:text-white"
                        >
                          Cancel
                        </button>
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Article Title *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Export Opportunities for Assam Agri-Produces"
                          value={articleForm.title}
                          onChange={(e) => setArticleForm({ ...articleForm, title: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500 text-sm font-semibold"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block font-medium text-slate-300 mb-1">Category</label>
                          <select
                            value={articleForm.category}
                            onChange={(e) => setArticleForm({ ...articleForm, category: e.target.value })}
                            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                          >
                            <option value="Global Trade">Global Trade</option>
                            <option value="Tax & Business">Tax & Business</option>
                            <option value="Digital Solutions">Digital Solutions</option>
                            <option value="Heritage & Geography">Heritage & Geography</option>
                            <option value="Insurance Planning">Insurance Planning</option>
                          </select>
                        </div>

                        <div>
                          <label className="block font-medium text-slate-300 mb-1">Tags (comma separated)</label>
                          <input
                            type="text"
                            placeholder="Export, Assam, Tea"
                            value={articleForm.tags}
                            onChange={(e) => setArticleForm({ ...articleForm, tags: e.target.value })}
                            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>

                        <div>
                          <label className="block font-medium text-slate-300 mb-1">Estimated Read Time</label>
                          <input
                            type="text"
                            placeholder="5 min read"
                            value={articleForm.readTime}
                            onChange={(e) => setArticleForm({ ...articleForm, readTime: e.target.value })}
                            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                          />
                        </div>
                      </div>

                      {/* Image URL or File Upload */}
                      <div className="space-y-2">
                        <label className="block font-medium text-slate-300">Cover Image (URL or Local File)</label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="https://images.unsplash.com/..."
                            value={articleForm.coverImage}
                            onChange={(e) => setArticleForm({ ...articleForm, coverImage: e.target.value })}
                            className="flex-1 px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                          />
                          <label className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer flex items-center gap-1.5 shrink-0">
                            <Upload className="w-3.5 h-3.5" />
                            <span>Upload File</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => handleFileUpload(e, 'article')}
                            />
                          </label>
                        </div>
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Short Excerpt (Summary for Cards)</label>
                        <textarea
                          rows={2}
                          placeholder="Brief 1-2 sentence preview of the article..."
                          value={articleForm.excerpt}
                          onChange={(e) => setArticleForm({ ...articleForm, excerpt: e.target.value })}
                          className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Full Article Content (Markdown format supported)</label>
                        <textarea
                          rows={8}
                          placeholder="Write your article text here. Use ## for section headings, list items with - or 1., and paragraphs separated by blank lines."
                          value={articleForm.content}
                          onChange={(e) => setArticleForm({ ...articleForm, content: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500 font-mono text-xs leading-relaxed"
                        />
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={articleForm.isPublished}
                            onChange={(e) => setArticleForm({ ...articleForm, isPublished: e.target.checked })}
                            className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-0"
                          />
                          <span className="text-slate-300">Publish immediately to live website</span>
                        </label>

                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setEditingArticle(null)}
                            className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="px-5 py-2 rounded-xl font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 shadow-md"
                          >
                            Save & Publish Article
                          </button>
                        </div>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* TAB 3: GALLERY */}
              {activeTab === 'gallery' && (
                <div className="space-y-6">
                  {!editingGalleryItem ? (
                    <>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-xl font-bold text-white">Media Gallery CMS</h3>
                          <p className="text-xs text-slate-400">Upload photos and embed videos to your public gallery.</p>
                        </div>
                        <button
                          onClick={() => handleOpenGalleryEditor()}
                          className="px-4 py-2 rounded-xl text-xs font-bold bg-teal-500 text-slate-950 hover:bg-teal-400 flex items-center gap-1.5 shadow-md"
                        >
                          <Plus className="w-4 h-4" />
                          <span>Add Media</span>
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {appData.gallery.map((item) => (
                          <div key={item.id} className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex flex-col justify-between">
                            <div className="relative aspect-video bg-slate-900">
                              {item.mediaType === 'video' ? (
                                <div className="w-full h-full flex items-center justify-center bg-slate-900 text-emerald-400">
                                  <ImageIcon className="w-8 h-8" />
                                </div>
                              ) : (
                                <img
                                  src={item.url}
                                  alt={item.title}
                                  referrerPolicy="no-referrer"
                                  className="w-full h-full object-cover"
                                />
                              )}
                              <span className="absolute top-2 left-2 text-[10px] px-2 py-0.5 rounded bg-slate-900/90 text-emerald-400">
                                {item.category}
                              </span>
                            </div>

                            <div className="p-3.5 space-y-2">
                              <div className="text-xs font-bold text-white line-clamp-1">{item.title}</div>
                              <p className="text-[11px] text-slate-400 line-clamp-2">{item.caption}</p>

                              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
                                <span className="text-slate-500">{item.date}</span>
                                <div className="flex items-center gap-1.5">
                                  <button
                                    onClick={() => handleOpenGalleryEditor(item)}
                                    className="p-1.5 rounded bg-slate-800 text-slate-300 hover:text-white"
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteGalleryItem(item.id)}
                                    className="p-1.5 rounded bg-slate-800 text-red-400 hover:text-red-300"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  ) : (
                    /* Gallery Editor Form */
                    <form onSubmit={handleSaveGalleryItem} className="space-y-4 bg-slate-950 p-6 rounded-2xl border border-slate-800 text-xs">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <h4 className="text-sm font-bold text-white">
                          {editingGalleryItem.title ? 'Edit Gallery Item' : 'Upload Media to Gallery'}
                        </h4>
                        <button
                          type="button"
                          onClick={() => setEditingGalleryItem(null)}
                          className="text-slate-400 hover:text-white"
                        >
                          Cancel
                        </button>
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Title / Label *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Northeast Hills Field Expedition"
                          value={galleryForm.title}
                          onChange={(e) => setGalleryForm({ ...galleryForm, title: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500 font-medium"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-medium text-slate-300 mb-1">Category</label>
                          <select
                            value={galleryForm.category}
                            onChange={(e) => setGalleryForm({ ...galleryForm, category: e.target.value as any })}
                            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                          >
                            <option value="Northeast Expeditions">Northeast Expeditions</option>
                            <option value="Global Trade & Agrielectro">Global Trade & Agrielectro</option>
                            <option value="Nature & Travels">Nature & Travels</option>
                            <option value="Consultancy & Engagements">Consultancy & Engagements</option>
                            <option value="General">General</option>
                          </select>
                        </div>

                        <div>
                          <label className="block font-medium text-slate-300 mb-1">Media Type</label>
                          <select
                            value={galleryForm.mediaType}
                            onChange={(e) => setGalleryForm({ ...galleryForm, mediaType: e.target.value as any })}
                            className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                          >
                            <option value="image">Image (Photo)</option>
                            <option value="video">Video (MP4 / YouTube / Vimeo link)</option>
                          </select>
                        </div>
                      </div>

                      {/* URL or Upload */}
                      <div className="space-y-2">
                        <label className="block font-medium text-slate-300">
                          {galleryForm.mediaType === 'video' ? 'Video URL (YouTube, Vimeo, MP4 link)' : 'Image URL or File Upload'}
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            required
                            placeholder={galleryForm.mediaType === 'video' ? 'https://youtube.com/... or https://...' : 'https://images.unsplash.com/...'}
                            value={galleryForm.url}
                            onChange={(e) => setGalleryForm({ ...galleryForm, url: e.target.value })}
                            className="flex-1 px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                          />
                          {galleryForm.mediaType === 'image' && (
                            <label className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 cursor-pointer flex items-center gap-1.5 shrink-0">
                              <Upload className="w-3.5 h-3.5" />
                              <span>Upload File</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => handleFileUpload(e, 'gallery')}
                              />
                            </label>
                          )}
                        </div>
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Caption / Story Description</label>
                        <textarea
                          rows={3}
                          placeholder="Add field notes, location, or context for this photo/video..."
                          value={galleryForm.caption}
                          onChange={(e) => setGalleryForm({ ...galleryForm, caption: e.target.value })}
                          className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                        />
                      </div>

                      <div className="flex justify-end gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setEditingGalleryItem(null)}
                          className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-5 py-2 rounded-xl font-bold text-slate-950 bg-teal-400 hover:bg-teal-300 shadow-md"
                        >
                          Save Media Item
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {/* TAB 4: INQUIRIES */}
              {activeTab === 'inquiries' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-white">Client Inquiries & Leads</h3>
                      <p className="text-xs text-slate-400">All submissions received from the website contact forms.</p>
                    </div>
                  </div>

                  {appData.inquiries.length === 0 ? (
                    <div className="p-8 text-center bg-slate-950 rounded-2xl border border-slate-800">
                      <p className="text-slate-400 text-xs">No client inquiries received yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {appData.inquiries.map((inq) => (
                        <div
                          key={inq.id}
                          className={`p-4 rounded-2xl border transition-all ${
                            inq.status === 'new'
                              ? 'bg-slate-950 border-amber-500/50 shadow-md'
                              : 'bg-slate-950/70 border-slate-800'
                          }`}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-sm text-white">{inq.name}</span>
                                {inq.status === 'new' && (
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-bold">
                                    NEW
                                  </span>
                                )}
                                {inq.status === 'replied' && (
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
                                    Replied
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-emerald-400 font-medium mt-0.5">
                                Service: {inq.service}
                              </div>
                            </div>

                            <span className="text-[11px] text-slate-500">
                              {new Date(inq.date).toLocaleString()}
                            </span>
                          </div>

                          <div className="py-3 text-xs text-slate-300 leading-relaxed">
                            {inq.message}
                          </div>

                          <div className="pt-2.5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                            <div className="flex items-center gap-4 text-slate-400">
                              <span className="flex items-center gap-1">
                                <Phone className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-slate-200 font-mono">{inq.phone}</span>
                              </span>
                              {inq.email && (
                                <span className="flex items-center gap-1">
                                  <Mail className="w-3.5 h-3.5 text-teal-400" />
                                  <span className="text-slate-200">{inq.email}</span>
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2">
                              <a
                                href={`https://wa.me/${inq.phone.replace(/[^0-9]/g, '')}?text=Hello%20${encodeURIComponent(inq.name)},%20thank%20you%20for%20reaching%20out%20to%20Solman%20Hussain%20Choudhury.`}
                                target="_blank"
                                rel="noreferrer"
                                onClick={() => handleUpdateInquiryStatus(inq.id, 'replied')}
                                className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-semibold text-[11px] hover:bg-emerald-400 flex items-center gap-1"
                              >
                                <span>WhatsApp Reply</span>
                              </a>

                              {inq.email && (
                                <a
                                  href={`mailto:${inq.email}?subject=Re:%20Inquiry%20from%20Solman%20Hussain%20Choudhury%20Consultancy`}
                                  onClick={() => handleUpdateInquiryStatus(inq.id, 'replied')}
                                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 text-[11px]"
                                >
                                  Email
                                </a>
                              )}

                              <button
                                onClick={() => handleDeleteInquiry(inq.id)}
                                className="p-1.5 rounded-lg bg-slate-800 text-red-400 hover:bg-red-950"
                                title="Delete message"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 5: PROFILE & SETTINGS */}
              {activeTab === 'profile' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <User className="w-5 h-5 text-emerald-400" />
                        <span>Profile & Official Executive Identity</span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Manage your authenticated credentials, official executive portrait, business details, and public contact information.
                      </p>
                    </div>

                    {savingStatus && (
                      <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-950/90 text-emerald-300 border border-emerald-700 text-xs font-semibold animate-in fade-in">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>{savingStatus}</span>
                      </div>
                    )}
                  </div>

                  {/* OFFICIAL EXECUTIVE PHOTO CLOUD STUDIO CARD */}
                  <div className="bg-slate-950 p-6 rounded-2xl border-2 border-emerald-900/60 shadow-xl space-y-5">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-4">
                      <div className="flex items-center gap-2.5">
                        <div className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/10 text-emerald-400 border border-emerald-500/30">
                          <Camera className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-bold text-white tracking-tight">
                              Official Executive Photo Studio
                            </h4>
                            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700 font-bold uppercase tracking-wider">
                              Cloud Storage
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Select an image from device gallery or Google Drive to sync with Firebase Cloud Storage & Firestore database.
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleResetToDefaultPhoto}
                          className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-colors"
                        >
                          Reset Default Portrait
                        </button>
                      </div>
                    </div>

                    {/* Studio Grid: Live Preview & Cloud Upload Controls */}
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                      
                      {/* Left: High-Definition Live Preview */}
                      <div className="md:col-span-4 flex flex-col items-center">
                        <div className="relative group w-full max-w-[240px] aspect-square rounded-2xl overflow-hidden bg-slate-900 border-2 border-emerald-500/40 shadow-2xl ring-4 ring-emerald-500/10">
                          <img
                            key={profileForm.avatarUrl}
                            src={profileForm.avatarUrl || "/images/solman_choudhury.jpg"}
                            alt="Solman Hussain Choudhury Executive Portrait"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "/images/solman_choudhury.jpg";
                            }}
                            className="w-full h-full object-cover object-top transition-all duration-300 group-hover:scale-105"
                          />
                          
                          {/* Live Overlay Badge */}
                          <div className="absolute top-2.5 left-2.5">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-950/85 text-emerald-300 border border-emerald-700/60 backdrop-blur-md shadow">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                              <span>Live on Website</span>
                            </span>
                          </div>

                          {/* Quick Change Overlay on Hover */}
                          <div 
                            onClick={() => photoFileInputRef.current?.click()}
                            className="absolute inset-0 bg-slate-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center cursor-pointer p-4 text-center backdrop-blur-xs"
                          >
                            <Upload className="w-6 h-6 text-emerald-400 mb-1" />
                            <span className="text-xs font-bold text-white">Click to Select New Photo</span>
                            <span className="text-[10px] text-slate-300">Device Gallery / Google Drive</span>
                          </div>
                        </div>

                        {/* Current Photo URL snippet */}
                        <div className="w-full max-w-[240px] mt-2.5 p-2 rounded-xl bg-slate-900/80 border border-slate-800 text-[10px] text-slate-400 font-mono break-all line-clamp-1 flex items-center justify-between">
                          <span className="truncate">{profileForm.avatarUrl || 'Default portrait'}</span>
                          <span className="shrink-0 text-emerald-400 font-bold ml-1">ACTIVE</span>
                        </div>
                      </div>

                      {/* Right: Drag & Drop Zone + File Picker + Direct URL */}
                      <div className="md:col-span-8 space-y-4">
                        
                        {/* Drag and Drop Zone */}
                        <div
                          onDragOver={(e) => { e.preventDefault(); setIsDraggingPhoto(true); }}
                          onDragLeave={() => setIsDraggingPhoto(false)}
                          onDrop={(e) => {
                            e.preventDefault();
                            setIsDraggingPhoto(false);
                            if (e.dataTransfer.files?.[0]) {
                              handleExecutivePhotoFileSelect(e.dataTransfer.files[0]);
                            }
                          }}
                          className={`relative border-2 border-dashed rounded-2xl p-6 text-center transition-all ${
                            isDraggingPhoto 
                              ? 'border-emerald-400 bg-emerald-950/30 ring-2 ring-emerald-500/30' 
                              : 'border-slate-700/80 hover:border-emerald-500/50 bg-slate-900/40 hover:bg-slate-900/70'
                          }`}
                        >
                          <input
                            ref={photoFileInputRef}
                            id="official-executive-photo-input"
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              if (e.target.files?.[0]) {
                                handleExecutivePhotoFileSelect(e.target.files[0]);
                              }
                            }}
                          />

                          <div className="flex flex-col items-center justify-center space-y-3">
                            <div className="w-12 h-12 rounded-2xl bg-emerald-950/80 border border-emerald-700/60 text-emerald-400 flex items-center justify-center shadow-inner">
                              <UploadCloud className="w-6 h-6 animate-bounce" />
                            </div>

                            <div className="space-y-1">
                              <h5 className="text-sm font-bold text-white">
                                Upload New Official Executive Photo
                              </h5>
                              <p className="text-xs text-slate-400 max-w-md mx-auto">
                                Drag and drop your image file here, or browse from your device gallery, local files, or Google Drive.
                              </p>
                            </div>

                            <button
                              id="executive-photo-file-picker-btn"
                              type="button"
                              disabled={isPhotoUploading}
                              onClick={() => photoFileInputRef.current?.click()}
                              className="px-5 py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 transition-all shadow-md active:scale-95 flex items-center gap-2"
                            >
                              <Camera className="w-4 h-4" />
                              <span>Select from Device Gallery / File Picker</span>
                            </button>

                            <p className="text-[11px] text-slate-500">
                              Supported formats: JPG, JPEG, PNG, WEBP (Max 25MB). Auto-converts and saves to Cloud Storage.
                            </p>
                          </div>
                        </div>

                        {/* Upload Progress Bar (when active) */}
                        {isPhotoUploading && (
                          <div className="p-4 rounded-xl bg-slate-900 border border-emerald-800/80 space-y-2 animate-in fade-in">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-semibold text-emerald-300 flex items-center gap-2">
                                <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                                <span>Uploading & Syncing with Cloud Storage...</span>
                              </span>
                              <span className="font-mono font-bold text-emerald-400">{uploadProgress}%</span>
                            </div>
                            <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                              <div 
                                className="bg-gradient-to-r from-emerald-500 to-teal-400 h-2 rounded-full transition-all duration-300 ease-out"
                                style={{ width: `${Math.max(uploadProgress, 10)}%` }}
                              />
                            </div>
                            <p className="text-[10px] text-slate-400">
                              Directly writing to Firebase Storage bucket and updating Firestore database document...
                            </p>
                          </div>
                        )}

                        {/* Success / Error Notification */}
                        {photoUploadMsg && (
                          <div className={`p-3.5 rounded-xl border flex items-start gap-2.5 text-xs animate-in fade-in ${
                            photoUploadMsg.type === 'success' 
                              ? 'bg-emerald-950/80 border-emerald-700 text-emerald-200' 
                              : 'bg-rose-950/80 border-rose-800 text-rose-200'
                          }`}>
                            {photoUploadMsg.type === 'success' ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                            ) : (
                              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                            )}
                            <div className="flex-1">
                              <p className="font-medium">{photoUploadMsg.text}</p>
                              {photoUploadMsg.storageType && (
                                <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded bg-slate-900/80 text-slate-300 font-mono">
                                  Storage destination: {photoUploadMsg.storageType}
                                </span>
                              )}
                            </div>
                            <button
                              type="button"
                              onClick={() => setPhotoUploadMsg(null)}
                              className="text-slate-400 hover:text-white p-1"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}

                        {/* Direct URL or Google Drive Public Link Input */}
                        <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                          <label className="block text-[11px] font-semibold text-slate-300 flex items-center justify-between">
                            <span>Alternative: Direct Image URL / Google Drive Share Link</span>
                            <span className="text-[10px] text-slate-500 font-normal">Optional</span>
                          </label>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={directPhotoUrlInput}
                              onChange={(e) => setDirectPhotoUrlInput(e.target.value)}
                              placeholder="https://... (e.g. drive.google.com link or CDN image URL)"
                              className="flex-1 px-3.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white text-xs font-mono placeholder:text-slate-600 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none"
                            />
                            <button
                              type="button"
                              onClick={handleApplyDirectPhotoUrl}
                              disabled={!directPhotoUrlInput.trim() || isPhotoUploading}
                              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 hover:text-white border border-slate-700 flex items-center gap-1.5 shrink-0 transition-colors"
                            >
                              <Link className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Apply URL</span>
                            </button>
                          </div>
                        </div>

                      </div>

                    </div>
                  </div>

                  <form onSubmit={handleSaveProfile} className="space-y-4 bg-slate-950 p-6 rounded-2xl border border-slate-800 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Full Name</label>
                        <input
                          type="text"
                          value={profileForm.name}
                          onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Professional Title</label>
                        <input
                          type="text"
                          value={profileForm.title}
                          onChange={(e) => setProfileForm({ ...profileForm, title: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                        />
                      </div>
                    </div>

                    {/* Official Permanent Address */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Official Permanent Address</label>
                        <input
                          type="text"
                          value={profileForm.fullAddress || profileForm.location || ''}
                          onChange={(e) => setProfileForm({ 
                            ...profileForm, 
                            fullAddress: e.target.value,
                            address: e.target.value,
                            location: e.target.value 
                          })}
                          placeholder="Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam, PIN 788804"
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Short Location Display</label>
                        <input
                          type="text"
                          value={profileForm.location || ''}
                          onChange={(e) => setProfileForm({ ...profileForm, location: e.target.value })}
                          placeholder="Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam 788804"
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Personal Phone / WhatsApp</label>
                        <input
                          type="text"
                          value={profileForm.personalPhone}
                          onChange={(e) => setProfileForm({ ...profileForm, personalPhone: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Business Phone / WhatsApp (Chaikosh)</label>
                        <input
                          type="text"
                          value={profileForm.businessPhone}
                          onChange={(e) => setProfileForm({ ...profileForm, businessPhone: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Official Personal Email</label>
                        <input
                          type="email"
                          value={profileForm.email}
                          onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Consultancy & Advisory Email</label>
                        <input
                          type="email"
                          value={profileForm.consultancyEmail || ''}
                          onChange={(e) => setProfileForm({ ...profileForm, consultancyEmail: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                          placeholder="contact@solmanchoudhury.in"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-medium text-slate-300 mb-1">Import / Export Business Emails (comma separated)</label>
                      <input
                        type="text"
                        value={Array.isArray(profileForm.exportEmails) ? profileForm.exportEmails.join(', ') : (profileForm.exportEmails || '')}
                        onChange={(e) => {
                          const emails = e.target.value.split(',').map(s => s.trim()).filter(Boolean);
                          setProfileForm({ ...profileForm, exportEmails: emails });
                        }}
                        className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                        placeholder="admin@chaikosh.in, chaikoshagrielectroindustries@gmail.com"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Academic Degree / College</label>
                        <input
                          type="text"
                          value={profileForm.education}
                          onChange={(e) => setProfileForm({ ...profileForm, education: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Company & Designation</label>
                        <input
                          type="text"
                          value={profileForm.companyRole}
                          onChange={(e) => setProfileForm({ ...profileForm, companyRole: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-300 mb-1">LinkedIn Profile URL</label>
                        <input
                          type="text"
                          value={profileForm.linkedinUrl || ''}
                          onChange={(e) => setProfileForm({ ...profileForm, linkedinUrl: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                          placeholder="https://www.linkedin.com/in/..."
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Facebook Profile URL / Name</label>
                        <input
                          type="text"
                          value={profileForm.facebookName}
                          onChange={(e) => setProfileForm({ ...profileForm, facebookName: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div>
                        <label className="block font-medium text-slate-300 mb-1">X / Twitter (Personal)</label>
                        <input
                          type="text"
                          value={profileForm.twitterHandle || ''}
                          onChange={(e) => setProfileForm({ ...profileForm, twitterHandle: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                          placeholder="https://x.com/solysiux"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">X / Twitter (Business)</label>
                        <input
                          type="text"
                          value={profileForm.twitterBusinessHandle || ''}
                          onChange={(e) => setProfileForm({ ...profileForm, twitterBusinessHandle: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                          placeholder="https://x.com/ChaikoshHQ"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-300 mb-1">Instagram (Personal & Brand)</label>
                        <input
                          type="text"
                          value={profileForm.instagramHandle}
                          onChange={(e) => setProfileForm({ ...profileForm, instagramHandle: e.target.value })}
                          className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono"
                          placeholder="@solysiux / @bysolman"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-medium text-slate-300 mb-1">Official Executive Photo (Public URL)</label>
                      <div className="flex items-center gap-3.5">
                        <div className="w-14 h-14 rounded-xl overflow-hidden border border-emerald-400/50 bg-slate-900 shrink-0">
                          <img 
                            key={profileForm.avatarUrl}
                            src={profileForm.avatarUrl || "/images/solman_choudhury.jpg"} 
                            alt="Profile preview" 
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "/images/solman_choudhury.jpg";
                            }}
                            className="w-full h-full object-cover object-top"
                          />
                        </div>
                        <div className="flex-1 space-y-2">
                          <input
                            type="text"
                            value={profileForm.avatarUrl}
                            onChange={(e) => setProfileForm({ ...profileForm, avatarUrl: e.target.value })}
                            placeholder="/images/solman_choudhury.jpg or https://..."
                            className="w-full px-3.5 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono"
                          />
                          <div className="flex items-center gap-2">
                            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 text-[11px] font-semibold cursor-pointer border border-emerald-500/40 transition-colors">
                              <UploadCloud className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Upload to Cloud Storage</span>
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                onChange={(e) => {
                                  if (e.target.files?.[0]) {
                                    handleExecutivePhotoFileSelect(e.target.files[0]);
                                  }
                                }}
                              />
                            </label>
                            <span className="text-[10px] text-slate-500">
                              (Or use the Studio above)
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block font-medium text-slate-300 mb-1">Bio / Story Summary</label>
                      <textarea
                        rows={4}
                        value={profileForm.bio}
                        onChange={(e) => setProfileForm({ ...profileForm, bio: e.target.value })}
                        className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white"
                      />
                    </div>

                    <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                      <button
                        type="submit"
                        className="px-6 py-2.5 rounded-xl font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 shadow-md"
                      >
                        Save Profile Changes
                      </button>
                    </div>
                  </form>

                  {/* Admin User ID & Password Management Sub-Card */}
                  <div className="mt-8 pt-6 border-t border-slate-800 space-y-4">
                    <div className="bg-slate-900/90 rounded-2xl p-5 border border-slate-800 space-y-5">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-800">
                            <ShieldCheck className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-white">Admin Security & Password Management</h4>
                            <p className="text-[11px] text-slate-400">
                              Configured for authorized executive account
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleLogout}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-300 bg-rose-950/60 hover:bg-rose-900 border border-rose-800 flex items-center gap-1.5 transition-colors"
                        >
                          <LogOut className="w-3.5 h-3.5 text-rose-400" />
                          <span>Logout</span>
                        </button>
                      </div>

                      {/* Direct Password Update Form */}
                      <form onSubmit={handleSaveCredentials} className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800/80">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white block">Change Password</span>
                          <span className="text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                            Google Verified (No Old Password Required)
                          </span>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-medium text-slate-300 mb-1">
                              Current Password <span className="text-slate-500">(Optional if Google Auth)</span>
                            </label>
                            <input
                              type="password"
                              value={currentAdminPassword}
                              onChange={(e) => setCurrentAdminPassword(e.target.value)}
                              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono"
                              placeholder="Leave blank or enter current"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-medium text-slate-300 mb-1">
                              New Secret Password <span className="text-emerald-400">*</span>
                            </label>
                            <input
                              type="password"
                              required
                              value={newAdminPassword}
                              onChange={(e) => setNewAdminPassword(e.target.value)}
                              className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white text-xs font-mono"
                              placeholder="Enter new confidential password"
                            />
                          </div>
                        </div>

                        {credSaveMsg && (
                          <div className="text-xs text-emerald-400 bg-emerald-950/60 p-2.5 rounded-xl border border-emerald-800 flex items-center gap-2">
                            <CheckCircle2 className="w-4 h-4 shrink-0" />
                            <span>{credSaveMsg}</span>
                          </div>
                        )}

                        {credErrorMsg && (
                          <div className="text-xs text-amber-400 bg-amber-950/60 p-2.5 rounded-xl border border-amber-800 flex items-center gap-2">
                            <AlertCircle className="w-4 h-4 shrink-0" />
                            <span>{credErrorMsg}</span>
                          </div>
                        )}

                        <div className="flex justify-end pt-1">
                          <button
                            type="submit"
                            className="px-5 py-2 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 shadow-sm"
                          >
                            Update Password
                          </button>
                        </div>
                      </form>

                      {/* Remote Password Reset Actions */}
                      <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="text-xs font-bold text-white block">Firebase Reset Link Dispatcher</span>
                            <span className="text-[11px] text-slate-400">
                              Send an automated password reset verification link to the registered admin email
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleSendPasswordReset()}
                            disabled={isResetLoading}
                            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-teal-400 hover:bg-teal-300 flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <Send className="w-3.5 h-3.5" />
                            <span>{isResetLoading ? 'Sending...' : 'Send Reset Link'}</span>
                          </button>
                        </div>
                        {resetMsg && (
                          <div className="text-xs text-teal-300 bg-teal-950/50 p-2.5 rounded-xl border border-teal-800">
                            {resetMsg}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: GOOGLE DRIVE CLOUD STORAGE */}
              {activeTab === 'drive' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-white">Google Drive Integration</h3>
                      <p className="text-xs text-slate-400">
                        Browse, upload, organize, and manage contracts, documents, and trade records in your Google Drive.
                      </p>
                    </div>
                  </div>

                  <GoogleDriveManager isModal={false} />
                </div>
              )}

              {/* TAB 7: GOOGLE SHEETS CRM */}
              {activeTab === 'sheets' && (
                <div className="space-y-4">
                  <GoogleSheetsManager inquiries={appData.inquiries} />
                </div>
              )}

            </div>

          </div>

      </div>
    </div>
  );
};