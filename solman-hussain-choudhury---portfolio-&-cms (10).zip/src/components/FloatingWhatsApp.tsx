import React, { useState } from 'react';
import { MessageCircle, X, Send, PhoneCall, Sparkles } from 'lucide-react';
import { ProfileData } from '../types';

interface FloatingWhatsAppProps {
  profile: ProfileData;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ profile }) => {
  const [open, setOpen] = useState(false);
  const [selectedChannel, setSelectedChannel] = useState<'personal' | 'business'>('personal');
  const [customText, setCustomText] = useState('');

  const personalNumber = '916001565255';
  const businessNumber = '916003348068';

  const handleLaunch = () => {
    const number = selectedChannel === 'personal' ? personalNumber : businessNumber;
    const defaultMsg = selectedChannel === 'personal'
      ? `Hello Solman Choudhury, I would like to inquire about your consultancy services.`
      : `Hello Chaikosh Agrielectro Industries, I have an inquiry regarding global trade & commodities.`;
    
    const message = encodeURIComponent(customText.trim() || defaultMsg);
    window.open(`https://wa.me/${number}?text=${message}`, '_blank');
    setOpen(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
      
      {/* Expanded Quick Chat Box */}
      {open && (
        <div className="mb-3 w-80 sm:w-88 bg-slate-900 border border-emerald-700/60 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-200">
          
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-700 to-teal-800 p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-xs">
                SC
              </div>
              <div>
                <h4 className="text-xs font-bold">{profile.name}</h4>
                <p className="text-[10px] text-emerald-100 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse" />
                  Available on WhatsApp
                </p>
              </div>
            </div>

            <button
              onClick={() => setOpen(false)}
              className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="p-4 space-y-3 text-xs bg-slate-950/80">
            
            <p className="text-slate-300 text-[11px]">
              Select which department or phone line you would like to connect with:
            </p>

            {/* Channel Options */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => setSelectedChannel('personal')}
                className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                  selectedChannel === 'personal'
                    ? 'bg-emerald-950/80 border-emerald-500 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="font-bold text-xs text-white">Personal / Consultancy</div>
                  <div className="text-[11px] text-emerald-400 font-mono">+91 6001565255</div>
                </div>
                {selectedChannel === 'personal' && (
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                )}
              </button>

              <button
                type="button"
                onClick={() => setSelectedChannel('business')}
                className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between ${
                  selectedChannel === 'business'
                    ? 'bg-teal-950/80 border-teal-500 text-white'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="font-bold text-xs text-white">Chaikosh Agrielectro (Export)</div>
                  <div className="text-[11px] text-teal-400 font-mono">+91 6003348068</div>
                </div>
                {selectedChannel === 'business' && (
                  <span className="w-2 h-2 rounded-full bg-teal-400" />
                )}
              </button>
            </div>

            {/* Custom Message Input */}
            <div>
              <input
                type="text"
                placeholder="Type a quick message or question..."
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleLaunch()}
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Action Trigger */}
            <button
              onClick={handleLaunch}
              className="w-full py-2.5 px-4 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition-all flex items-center justify-center gap-1.5 shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Start WhatsApp Chat</span>
            </button>

          </div>

        </div>
      )}

      {/* Floating Trigger Button */}
      <button
        id="floating-whatsapp-btn"
        onClick={() => setOpen(!open)}
        className="group relative flex items-center gap-2 px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 rounded-full shadow-2xl hover:scale-105 transition-all active:scale-95 border-2 border-emerald-300/40"
        aria-label="Open WhatsApp Chat with Solman Hussain Choudhury"
      >
        <MessageCircle className="w-5 h-5 fill-slate-950" />
        <span className="text-xs font-extrabold hidden sm:inline">WhatsApp Chat</span>
        <span className="w-2 h-2 rounded-full bg-emerald-200 absolute -top-0.5 -right-0.5" />
      </button>

    </div>
  );
};
