import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, ExternalLink, RefreshCw, Plus, 
  Search, Check, AlertCircle, ShieldCheck, UserCheck, 
  LogOut, Upload, Download, Database, Users, Mail, Phone, Calendar
} from 'lucide-react';
import { googleSignIn, logout, initAuth, getAccessToken } from '../services/googleAuth';
import { googleSheetsService } from '../services/googleSheets';
import { User } from 'firebase/auth';

interface Inquiry {
  id: string;
  name: string;
  email: string;
  phone?: string;
  service?: string;
  message: string;
  date: string;
  status?: string;
}

interface GoogleSheetsManagerProps {
  onClose?: () => void;
  inquiries?: Inquiry[];
  onRefreshData?: () => void;
}

export const GoogleSheetsManager: React.FC<GoogleSheetsManagerProps> = ({
  onClose,
  inquiries = [],
  onRefreshData
}) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Spreadsheet state
  const [spreadsheetId, setSpreadsheetId] = useState<string>(() => {
    return localStorage.getItem('chaikosh_crm_spreadsheet_id') || '';
  });
  const [spreadsheetUrl, setSpreadsheetUrl] = useState<string>(() => {
    return localStorage.getItem('chaikosh_crm_spreadsheet_url') || '';
  });
  const [sheetData, setSheetData] = useState<string[][]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    const unsubscribe = initAuth(
      async (user, _token, isAuthorized) => {
        setCurrentUser(user);
        const userEmail = (user.email || '').trim().toLowerCase();
        const isMatch = userEmail === 'solmanchoudhury66@gmail.com';
        
        if (isMatch || isAuthorized) {
          setIsAuthenticated(true);
          setAuthLoading(false);
          if (spreadsheetId) {
            loadSheetValues(spreadsheetId);
          }
        } else {
          setIsAuthenticated(false);
          setAuthLoading(false);
          setError(`Access Denied: You are not authorized for administrator access.`);
        }
      },
      () => {
        setCurrentUser(null);
        setIsAuthenticated(false);
        setAuthLoading(false);
      }
    );

    return () => unsubscribe();
  }, [spreadsheetId]);

  const handleSignIn = async () => {
    try {
      setError(null);
      setAuthLoading(true);
      const res = await googleSignIn();
      if (res) {
        setCurrentUser(res.user);
        const userEmail = (res.user.email || '').trim().toLowerCase();
        const isMatch = userEmail === 'solmanchoudhury66@gmail.com';
        
        if (isMatch || res.isAuthorized) {
          setIsAuthenticated(true);
          setSuccessMsg("Successfully signed in with Google Account & Sheets access!");
          if (spreadsheetId) {
            await loadSheetValues(spreadsheetId);
          }
        } else {
          setIsAuthenticated(false);
          setError(`Access Denied: You are not authorized for administrator access.`);
        }
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Google sign in failed');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await logout();
      setCurrentUser(null);
      setIsAuthenticated(false);
      setSuccessMsg("Signed out successfully.");
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleCreateCRMSpreadsheet = async () => {
    try {
      setLoading(true);
      setError(null);
      setSuccessMsg(null);
      
      const { spreadsheetId: newId, spreadsheetUrl: newUrl } = await googleSheetsService.createCustomerSpreadsheet(
        `Chaikosh Agrielectro Customer CRM - ${new Date().toLocaleDateString()}`
      );

      setSpreadsheetId(newId);
      setSpreadsheetUrl(newUrl);
      localStorage.setItem('chaikosh_crm_spreadsheet_id', newId);
      localStorage.setItem('chaikosh_crm_spreadsheet_url', newUrl);

      // Push existing inquiries into the new sheet
      if (inquiries.length > 0) {
        const rows = inquiries.map(inq => [
          inq.name || 'N/A',
          inq.email || 'N/A',
          inq.phone || 'N/A',
          inq.service || 'General Inquiry',
          inq.message || '',
          inq.date || new Date().toISOString(),
          inq.status || 'New',
          'Website Inquiry'
        ]);
        await googleSheetsService.appendRows(newId, rows);
      }

      setSuccessMsg("New Google CRM Spreadsheet created and synchronized successfully!");
      await loadSheetValues(newId);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to create spreadsheet');
    } finally {
      setLoading(false);
    }
  };

  const loadSheetValues = async (id: string) => {
    try {
      setLoading(true);
      const values = await googleSheetsService.getSpreadsheetValues(id);
      setSheetData(values);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to load spreadsheet records');
    } finally {
      setLoading(false);
    }
  };

  const handleSyncToSheet = async () => {
    if (!spreadsheetId) {
      setError("Please create or link a Google Spreadsheet first.");
      return;
    }

    try {
      setIsSyncing(true);
      setError(null);
      setSuccessMsg(null);

      // Skip header row if sheetData has header
      const existingEmails = new Set(sheetData.slice(1).map(row => row[1]?.trim().toLowerCase()));
      
      const newInquiries = inquiries.filter(inq => !existingEmails.has((inq.email || '').trim().toLowerCase()));

      if (newInquiries.length === 0) {
        setSuccessMsg("All customer inquiries are already synced with your Google Sheet!");
        setIsSyncing(false);
        return;
      }

      const rows = newInquiries.map(inq => [
        inq.name || 'N/A',
        inq.email || 'N/A',
        inq.phone || 'N/A',
        inq.service || 'General Inquiry',
        inq.message || '',
        inq.date || new Date().toISOString(),
        inq.status || 'New',
        'Website Inquiry'
      ]);

      await googleSheetsService.appendRows(spreadsheetId, rows);
      setSuccessMsg(`Successfully synced ${newInquiries.length} new customer inquiries to Google Sheets!`);
      await loadSheetValues(spreadsheetId);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to sync with Google Sheet');
    } finally {
      setIsSyncing(false);
    }
  };

  const filteredInquiries = inquiries.filter(inq => {
    const q = searchQuery.toLowerCase();
    return (
      (inq.name || '').toLowerCase().includes(q) ||
      (inq.email || '').toLowerCase().includes(q) ||
      (inq.phone || '').toLowerCase().includes(q) ||
      (inq.service || '').toLowerCase().includes(q) ||
      (inq.message || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 text-white shadow-2xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2.5 text-white">
            <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
            Google Sheets Customer CRM & Inquiry Management
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage, export, and sync customer leads, export inquiries, and consultancy requests directly with Google Sheets.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {isAuthenticated ? (
            <div className="flex items-center gap-2 bg-slate-800 border border-slate-700 px-3 py-1.5 rounded-xl text-xs">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-300 font-medium truncate max-w-[160px]">{currentUser?.email}</span>
              <button 
                onClick={handleSignOut}
                className="text-slate-400 hover:text-red-400 ml-2 transition-colors"
                title="Sign out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={handleSignIn}
              disabled={authLoading}
              className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs sm:text-sm transition-all shadow-lg"
            >
              {authLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
              Sign In with Google Sheets
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-300 px-4 py-3 rounded-xl text-xs sm:text-sm flex items-start gap-2.5">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && (
        <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 px-4 py-3 rounded-xl text-xs sm:text-sm flex items-start gap-2.5">
          <Check className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <span>{successMsg}</span>
        </div>
      )}

      {isAuthenticated ? (
        <div className="space-y-6">
          {/* Action Toolbar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 flex flex-col justify-between">
              <div>
                <span className="text-xs text-slate-400 uppercase font-semibold tracking-wider">CRM Spreadsheet</span>
                <h3 className="text-sm font-bold text-white mt-1">
                  {spreadsheetId ? "Active Google Sheet Connected" : "No Sheet Connected"}
                </h3>
              </div>
              <div className="mt-4 flex items-center gap-2">
                {!spreadsheetId ? (
                  <button
                    onClick={handleCreateCRMSpreadsheet}
                    disabled={loading}
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" /> Create CRM Sheet
                  </button>
                ) : (
                  <a
                    href={spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all"
                  >
                    <ExternalLink className="w-3.5 h-3.5 text-emerald-400" /> Open in Google Sheets
                  </a>
                )}
              </div>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 flex flex-col justify-between">
              <div>
                <span className="text-xs text-slate-400 uppercase font-semibold tracking-wider">Sync Customer Leads</span>
                <h3 className="text-sm font-bold text-white mt-1">{inquiries.length} Local Inquiries Recorded</h3>
              </div>
              <div className="mt-4">
                <button
                  onClick={handleSyncToSheet}
                  disabled={!spreadsheetId || isSyncing}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all"
                >
                  {isSyncing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                  Sync New Leads to Sheet
                </button>
              </div>
            </div>

            <div className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 flex flex-col justify-between">
              <div>
                <span className="text-xs text-slate-400 uppercase font-semibold tracking-wider">Live CRM Records</span>
                <h3 className="text-sm font-bold text-white mt-1">
                  {sheetData.length > 1 ? `${sheetData.length - 1} Rows in Google Sheet` : "0 Rows in Google Sheet"}
                </h3>
              </div>
              <div className="mt-4">
                <button
                  onClick={() => spreadsheetId && loadSheetValues(spreadsheetId)}
                  disabled={!spreadsheetId || loading}
                  className="w-full bg-slate-700 hover:bg-slate-600 text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh Data
                </button>
              </div>
            </div>
          </div>

          {/* Search & Inquiries Table */}
          <div className="bg-slate-800/60 border border-slate-700/80 rounded-2xl p-4 space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                Customer Leads & Inquiries Database
              </h3>
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search customer name, email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-4 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-900 text-slate-400 uppercase font-semibold tracking-wider border-b border-slate-700">
                  <tr>
                    <th className="py-3 px-4">Customer Name</th>
                    <th className="py-3 px-4">Contact Info</th>
                    <th className="py-3 px-4">Service</th>
                    <th className="py-3 px-4">Message</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredInquiries.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        No customer inquiries found matching your search.
                      </td>
                    </tr>
                  ) : (
                    filteredInquiries.map((inq) => (
                      <tr key={inq.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-4 font-semibold text-white">{inq.name}</td>
                        <td className="py-3 px-4">
                          <div className="flex flex-col gap-0.5">
                            <span className="flex items-center gap-1 text-slate-300">
                              <Mail className="w-3 h-3 text-emerald-400" /> {inq.email}
                            </span>
                            {inq.phone && (
                              <span className="flex items-center gap-1 text-slate-400">
                                <Phone className="w-3 h-3 text-indigo-400" /> {inq.phone}
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span className="bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded-md font-medium text-[11px]">
                            {inq.service || 'General'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-300 max-w-xs truncate" title={inq.message}>
                          {inq.message}
                        </td>
                        <td className="py-3 px-4 text-slate-400 flex items-center gap-1">
                          <Calendar className="w-3 h-3" /> {new Date(inq.date).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            inq.status === 'Resolved' || inq.status === 'Converted' 
                              ? 'bg-emerald-500/20 text-emerald-300' 
                              : 'bg-amber-500/20 text-amber-300'
                          }`}>
                            {inq.status || 'New'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-12 text-center space-y-4">
          <div className="w-16 h-16 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto">
            <FileSpreadsheet className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">Google Sheets Authentication Required</h3>
          <p className="text-sm text-slate-400 max-w-md mx-auto">
            Sign in with your authorized Google Account to manage, create, and synchronize customer CRM spreadsheets.
          </p>
          <button
            onClick={handleSignIn}
            disabled={authLoading}
            className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-6 py-3 rounded-xl text-sm transition-all shadow-lg"
          >
            {authLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
            Sign In with Google Sheets
          </button>
        </div>
      )}
    </div>
  );
};
