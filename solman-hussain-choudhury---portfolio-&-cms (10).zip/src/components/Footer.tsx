import React from 'react';
import { 
  ArrowUp, Mail, Phone, MapPin, 
  Facebook, Instagram, ShieldCheck, Ship, FileCheck,
  Compass, Car, MessageCircle
} from 'lucide-react';
import { ProfileData } from '../types';

interface FooterProps {
  profile: ProfileData;
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ profile }) => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Social & Official Channels - Pure Logo Only
  const socialLogos = [
    {
      id: 'linkedin',
      name: 'LinkedIn (Solman Hussain Choudhury)',
      url: profile.linkedin || "https://www.linkedin.com/in/solman-hussain-choudhury-33749120b?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      icon: <span className="font-black text-xs tracking-tighter">in</span>,
      bg: 'bg-[#0077B5] hover:bg-[#006396]',
      text: 'text-white'
    },
    {
      id: 'facebook',
      name: 'Facebook (Solman Hussain Choudhury)',
      url: profile.facebook || "https://www.facebook.com/share/19NBsL65vz/",
      icon: <Facebook className="w-3.5 h-3.5" />,
      bg: 'bg-[#1877F2] hover:bg-[#0d65d9]',
      text: 'text-white'
    },
    {
      id: 'twitter-personal',
      name: 'X / Twitter (@solysiux)',
      url: profile.twitterPersonal || "https://x.com/solysiux",
      icon: <span className="font-bold text-xs leading-none">𝕏</span>,
      bg: 'bg-black hover:bg-neutral-800 border border-neutral-700',
      text: 'text-white'
    },
    {
      id: 'twitter-chaikosh',
      name: 'X / Twitter (@ChaikoshHQ)',
      url: profile.twitterBusiness || "https://x.com/ChaikoshHQ",
      icon: <span className="font-bold text-xs leading-none">𝕏</span>,
      bg: 'bg-teal-900 hover:bg-teal-800 border border-teal-700',
      text: 'text-teal-200'
    },
    {
      id: 'instagram-personal',
      name: 'Instagram (@solysiux)',
      url: profile.instagram || "https://instagram.com/solysiux",
      icon: <Instagram className="w-3.5 h-3.5" />,
      bg: 'bg-gradient-to-tr from-[#f9ce34] via-[#ee2a7b] to-[#6228d7] hover:opacity-90',
      text: 'text-white'
    },
    {
      id: 'instagram-brand',
      name: 'Instagram (@bysolman)',
      url: profile.instagramBrand || "https://instagram.com/bysolman",
      icon: <Instagram className="w-3.5 h-3.5" />,
      bg: 'bg-gradient-to-tr from-[#f09433] via-[#e6683c] to-[#dc2743] hover:opacity-90',
      text: 'text-white'
    },
    {
      id: 'whatsapp-personal',
      name: 'WhatsApp (+91 6001565255)',
      url: 'https://wa.me/916001565255?text=Hello%20Solman%20Choudhury,%20I%20visited%20your%20portfolio%20and%20would%20like%20to%20connect.',
      icon: <MessageCircle className="w-3.5 h-3.5" />,
      bg: 'bg-[#25D366] hover:bg-[#1eb857]',
      text: 'text-white'
    },
    {
      id: 'whatsapp-chaikosh',
      name: 'WhatsApp Chaikosh (+91 6003348068)',
      url: 'https://wa.me/916003348068?text=Hello%20Chaikosh%20Trade%20Desk,%20I%20have%20an%20export/commodity%20inquiry.',
      icon: <MessageCircle className="w-3.5 h-3.5" />,
      bg: 'bg-[#128C7E] hover:bg-[#075E54]',
      text: 'text-white'
    },
    {
      id: 'email-personal',
      name: 'Email (contact@solmanchoudhury.in)',
      url: 'mailto:contact@solmanchoudhury.in',
      icon: <Mail className="w-3.5 h-3.5" />,
      bg: 'bg-emerald-800 hover:bg-emerald-700 border border-emerald-600/60',
      text: 'text-emerald-100'
    },
    {
      id: 'email-chaikosh',
      name: 'Trade Email (admin@chaikosh.in)',
      url: 'mailto:admin@chaikosh.in',
      icon: <Mail className="w-3.5 h-3.5" />,
      bg: 'bg-cyan-900 hover:bg-cyan-800 border border-cyan-700/60',
      text: 'text-cyan-100'
    }
  ];

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 text-xs relative">
      
      {/* ================= MAIN FOOTER CONTENT ================= */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-14">
        
        {/* Main Columns Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-10">
          
          {/* Brand & Bio Summary */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 via-teal-600 to-emerald-800 flex items-center justify-center text-slate-950 font-black text-sm shadow-lg border border-emerald-400/40">
                SC
              </div>
              <div>
                <span className="text-base font-bold text-white tracking-tight">
                  {profile.name}
                </span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[11px] text-emerald-400 font-semibold">
                    Merchant Exporter & Business Consultant
                  </span>
                </div>
              </div>
            </div>

            <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
              Empowering regional and international trade through agro-commodity exports, certified tax & statutory consultancy, comprehensive vehicle insurance (new & old vehicles), digital solutions, and nature-inspired travel expeditions across Northeast India.
            </p>

            {/* Explorer Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-[11px]">
              <Compass className="w-3.5 h-3.5 text-teal-400 shrink-0" />
              <span>Avid Traveler & Northeast Heritage Explorer</span>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Navigation
            </h4>
            <ul className="space-y-2">
              <li>
                <a href="#about" className="hover:text-emerald-400 transition-colors">About & Profile</a>
              </li>
              <li>
                <a href="#services" className="hover:text-emerald-400 transition-colors">Services & Vehicle Insurance</a>
              </li>
              <li>
                <a href="#global-trade" className="hover:text-emerald-400 transition-colors">Global Trade & Exports</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-emerald-400 transition-colors">Travel & Trade Gallery</a>
              </li>
              <li>
                <a href="#articles" className="hover:text-emerald-400 transition-colors">Articles & Insights</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-emerald-400 transition-colors">Contact Details</a>
              </li>
            </ul>
          </div>

          {/* Services & Vehicle Insurance Highlights */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Practices & Solutions
            </h4>
            <ul className="space-y-2">
              <li className="flex items-center gap-1.5 text-slate-300">
                <Ship className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>GI Agro & Limestone Exports</span>
              </li>
              <li className="flex items-center gap-1.5 text-slate-300">
                <Car className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="font-medium text-amber-300">Vehicle Insurance (New & Old)</span>
              </li>
              <li className="flex items-center gap-1.5 text-slate-300">
                <FileCheck className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <span>ITR, GST & Corporate Setup</span>
              </li>
              <li className="flex items-center gap-1.5 text-slate-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Life & Health Asset Cover</span>
              </li>
              <li className="text-slate-400">
                • 2W, 4W & Commercial Vehicles
              </li>
              <li className="text-slate-400">
                • Digital Websites & DPR Advisory
              </li>
            </ul>
          </div>

          {/* Contact Summary */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Direct Contact
            </h4>
            <div className="space-y-2.5 text-slate-300">
              <div className="flex items-start gap-2">
                <Phone className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div>{profile.personalPhone} <span className="text-[10px] text-slate-500">(Personal)</span></div>
                  <div>{profile.businessPhone} <span className="text-[10px] text-slate-500">(Business)</span></div>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Mail className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <a href="mailto:contact@solmanchoudhury.in" className="hover:text-white block break-all font-mono text-[11px]">
                    contact@solmanchoudhury.in
                  </a>
                  <a href="mailto:admin@chaikosh.in" className="hover:text-cyan-300 block break-all font-mono text-[11px] text-slate-400">
                    admin@chaikosh.in
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                <span className="leading-snug">Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam 788804, India</span>
              </div>
            </div>
          </div>

        </div>

        {/* ================= SOCIAL MEDIA LOGOS ON TOP OF COPYRIGHT SECTION ================= */}
        <div className="mt-12 pt-8 border-t border-slate-800/80">
          
          {/* Compact Social Media Icon Strip */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-6">
            <div className="text-center sm:text-left">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300 block">
                Connect on Official Channels
              </span>
              <span className="text-[10px] text-slate-500">
                Touch any logo to open verified profile or messaging desk
              </span>
            </div>

            {/* Small Official Logos */}
            <div className="flex flex-wrap items-center justify-center gap-2">
              {socialLogos.map((item) => (
                <a
                  key={item.id}
                  href={item.url}
                  target="_blank"
                  rel="noreferrer"
                  className={`w-8 h-8 rounded-full ${item.bg} ${item.text} flex items-center justify-center shadow-md transition-all duration-200 hover:scale-110 active:scale-95`}
                  title={item.name}
                  aria-label={item.name}
                >
                  {item.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Detailed Copyrights & Legal Information Card */}
          <div className="bg-slate-900/80 rounded-xl p-5 border border-slate-800 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span className="font-bold text-white text-xs tracking-wide">
                  Copyright & Intellectual Property Notice
                </span>
              </div>
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                Official Portfolio & Commercial Entity
              </span>
            </div>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              © {currentYear} <strong>Solman Hussain Choudhury</strong>. All Rights Reserved. All proprietary content, trade names, articles, multimedia assets, brand identifiers, and export specifications published on this platform are legally protected under the <strong>Indian Copyright Act, 1957</strong> and relevant international intellectual property conventions.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] text-slate-400 pt-1 border-t border-slate-800/60">
              <div>
                <strong className="text-slate-300">Registered Trade Entity:</strong> {profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"} • Directorate General of Foreign Trade (DGFT) & Import Export Code (IEC) Compliant.
              </div>
              <div>
                <strong className="text-slate-300">Service Disclaimer:</strong> Vehicle insurance (new/old), life/health policies, taxation, and statutory filings are executed in adherence with IRDAI, CBDT, and GST statutory guidelines.
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 pt-4">
            <div>
              Designed & Managed for <strong>Solman Hussain Choudhury</strong> (Badarpur, Cachar, Assam).
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={scrollToTop}
                className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors flex items-center gap-1"
                title="Back to Top"
              >
                <ArrowUp className="w-3.5 h-3.5" />
                <span className="text-[10px] hidden sm:inline">Back to Top</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};
