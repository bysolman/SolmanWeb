import React, { useState, useEffect } from 'react';
import { 
  BookOpen, Clock, Calendar, ArrowRight, Search, 
  Tag, X, Share2, PlusCircle, Check, User, RotateCcw 
} from 'lucide-react';
import { Article, ProfileData } from '../types';
import { useDynamicSEO } from '../utils/seo';

interface ArticlesSectionProps {
  articles: Article[];
  profile: ProfileData;
  onOpenAdminArticle: () => void;
  searchFilter?: string;
  onSearchChange?: (query: string) => void;
  activeSelectedArticle?: Article | null;
  onCloseSelectedArticle?: () => void;
}

export const ArticlesSection: React.FC<ArticlesSectionProps> = ({ 
  articles, 
  profile,
  onOpenAdminArticle,
  searchFilter = '',
  onSearchChange,
  activeSelectedArticle = null,
  onCloseSelectedArticle
}) => {
  const [localSearchQuery, setLocalSearchQuery] = useState(searchFilter);
  const [selectedTag, setSelectedTag] = useState<string>('All');
  const [internalActiveArticle, setInternalActiveArticle] = useState<Article | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Synchronize with external search filter changes
  useEffect(() => {
    setLocalSearchQuery(searchFilter);
  }, [searchFilter]);

  const activeArticle = activeSelectedArticle || internalActiveArticle;
  
  useDynamicSEO({
    title: activeArticle ? activeArticle.title : "Articles & Insights on Assam Consultant & Export Trading",
    description: activeArticle ? activeArticle.excerpt : "Explore expert articles and insights on Assam consultancy, GST, tax advisory, and global export trading by Solman Hussain Choudhury.",
    keywords: activeArticle ? [...(activeArticle.tags || []), 'Assam Consultant', 'Export Trading'] : ['Assam Consultant', 'Export Trading']
  });

  const setActiveArticle = (art: Article | null) => {
    if (!art && onCloseSelectedArticle) {
      onCloseSelectedArticle();
    }
    setInternalActiveArticle(art);
  };

  const handleQueryChange = (val: string) => {
    setLocalSearchQuery(val);
    if (onSearchChange) {
      onSearchChange(val);
    }
  };

  // Filter published articles
  const publishedArticles = articles.filter(a => a.isPublished);

  // Gather unique tags
  const allTags = ['All', ...Array.from(new Set(publishedArticles.flatMap(a => a.tags || [])))];

  const cleanQuery = localSearchQuery.trim().toLowerCase();

  const filteredArticles = publishedArticles.filter(article => {
    const matchesSearch = !cleanQuery || (
      article.title.toLowerCase().includes(cleanQuery) ||
      article.excerpt.toLowerCase().includes(cleanQuery) ||
      article.category.toLowerCase().includes(cleanQuery) ||
      (article.tags && article.tags.some(t => t.toLowerCase().includes(cleanQuery)))
    );

    const matchesTag = selectedTag === 'All' || (article.tags && article.tags.includes(selectedTag));

    return matchesSearch && matchesTag;
  });

  const highlightMatch = (text: string, query: string) => {
    if (!query) return text;
    const parts = text.split(new RegExp(`(${query})`, 'gi'));
    return parts.map((part, i) =>
      part.toLowerCase() === query.toLowerCase() ? (
        <span key={i} className="bg-teal-500/30 text-teal-200 font-semibold px-0.5 rounded">
          {part}
        </span>
      ) : (
        part
      )
    );
  };

  const handleShare = (article: Article) => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  return (
    <section id="articles" className="py-14 md:py-16 bg-slate-900 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header & Publisher Trigger */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800/60">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Insights & Writings</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Articles & <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">Perspectives</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Quick insights spanning export trade, taxation, vehicle advisory, and Northeast regional geography.
            </p>
          </div>

          <div>
            <button
              onClick={onOpenAdminArticle}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-emerald-400 border border-slate-700 transition-all shadow-sm"
            >
              <PlusCircle className="w-3.5 h-3.5 text-emerald-400" />
              <span>Write in CMS</span>
            </button>
          </div>
        </div>

        {/* Search & Tag Filter Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
          <div className="relative w-full sm:w-72 flex items-center">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              id="articles-inpage-search"
              aria-label="Search articles by keyword or category"
              placeholder="Filter articles by keyword..."
              value={localSearchQuery}
              onChange={(e) => handleQueryChange(e.target.value)}
              className="w-full pl-8 pr-8 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
            />
            {localSearchQuery && (
              <button
                type="button"
                onClick={() => handleQueryChange('')}
                aria-label="Clear article search query"
                className="absolute right-2 text-slate-400 hover:text-white p-1"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium whitespace-nowrap transition-all ${
                  selectedTag === tag
                    ? 'bg-teal-500 text-slate-950 font-bold'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Active Filter Note Banner */}
        {cleanQuery && (
          <div className="mb-6 p-3 rounded-xl bg-teal-950/30 border border-teal-800/50 flex items-center justify-between gap-3 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-teal-400 shrink-0" />
              <span>
                Filtered by: &ldquo;<strong className="text-teal-300">{localSearchQuery}</strong>&rdquo; ({filteredArticles.length} matching)
              </span>
            </div>
            <button
              onClick={() => handleQueryChange('')}
              className="text-[11px] font-semibold text-slate-300 hover:text-white flex items-center gap-1 bg-slate-900 px-2.5 py-1 rounded border border-slate-700 hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="w-3 h-3 text-teal-400" />
              <span>Reset</span>
            </button>
          </div>
        )}

        {/* Article Cards Grid - At least 4 articles in one row on desktop */}
        {filteredArticles.length === 0 ? (
          <div className="text-center py-12 px-4 bg-slate-950/40 rounded-2xl border border-slate-800 space-y-3">
            <Search className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-slate-300 text-xs font-semibold">No articles match &ldquo;{localSearchQuery}&rdquo;.</p>
            <p className="text-slate-500 text-[11px]">Try searching by category or adjusting your search keywords.</p>
            <button
              onClick={() => {
                handleQueryChange('');
                setSelectedTag('All');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-950 bg-teal-400 hover:bg-teal-300 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>View All Articles</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredArticles.map((article) => (
              <article
                key={article.id}
                id={`article-card-${article.id}`}
                onClick={() => setActiveArticle(article)}
                className="group bg-slate-950/90 rounded-xl overflow-hidden border border-slate-800 hover:border-teal-500/60 shadow-lg transition-all duration-200 flex flex-col justify-between cursor-pointer hover:-translate-y-1 hover:shadow-teal-950/30"
              >
                <div>
                  {/* Article Thumbnail */}
                  <div className="relative aspect-[16/9] overflow-hidden bg-slate-900">
                    <img
                      src={article.coverImage}
                      alt={article.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 left-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-950/85 text-teal-300 backdrop-blur-md border border-slate-700/60">
                        {highlightMatch(article.category, cleanQuery)}
                      </span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-3.5 space-y-2">
                    <div className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-emerald-400 shrink-0" />
                        <span>{article.publishedDate}</span>
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-teal-400 shrink-0" />
                        <span>{article.readTime}</span>
                      </span>
                    </div>

                    <h3 className="text-xs sm:text-sm font-bold text-white group-hover:text-teal-300 transition-colors leading-snug line-clamp-2">
                      {highlightMatch(article.title, cleanQuery)}
                    </h3>

                    <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                      {highlightMatch(article.excerpt, cleanQuery)}
                    </p>

                    {/* Tags preview */}
                    {article.tags && article.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 pt-1">
                        {article.tags.slice(0, 2).map((tag, idx) => (
                          <span key={idx} className="text-[9px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                            #{highlightMatch(tag, cleanQuery)}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Read Trigger Footer */}
                <div className="px-3.5 py-2 bg-slate-900/60 border-t border-slate-800/80 flex items-center justify-between mt-1">
                  <span className="text-[11px] font-semibold text-teal-400 group-hover:text-teal-300 flex items-center gap-1">
                    <span>Read</span>
                    <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                  </span>
                  <span className="text-[10px] text-slate-500">{article.readTime}</span>
                </div>

              </article>
            ))}
          </div>
        )}

      </div>

      {/* Full Article Reader Modal */}
      {activeArticle && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative max-w-3xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl max-h-[90vh] flex flex-col">
            
            {/* Modal Top Bar */}
            <div className="p-4 sm:px-6 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                {activeArticle.category}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleShare(activeArticle)}
                  className="p-2 rounded-lg text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 transition-colors text-xs flex items-center gap-1.5"
                  title="Share Article"
                >
                  {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                  <span className="hidden sm:inline">{copiedLink ? 'Link Copied' : 'Share'}</span>
                </button>

                <button
                  onClick={() => setActiveArticle(null)}
                  className="p-2 rounded-lg text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Scrollable Article Body */}
            <div className="overflow-y-auto p-6 sm:p-8 space-y-6">
              
              {/* Cover Image */}
              <div className="rounded-xl overflow-hidden aspect-[16/9] bg-slate-950">
                <img
                  src={activeArticle.coverImage}
                  alt={activeArticle.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Title & Metadata */}
              <div className="space-y-3">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
                  {activeArticle.title}
                </h1>
                
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1 pb-3 border-b border-slate-800">
                  <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{profile.name}</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{activeArticle.publishedDate}</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-teal-400" />
                    <span>{activeArticle.readTime}</span>
                  </span>
                </div>
              </div>

              {/* Article Content Display with Markdown-like Paragraph rendering */}
              <div className="prose prose-invert max-w-none text-slate-200 text-sm sm:text-base leading-relaxed space-y-4">
                {activeArticle.content.split('\n\n').map((block, idx) => {
                  if (block.startsWith('### ')) {
                    return <h3 key={idx} className="text-lg font-bold text-white mt-6 mb-2">{block.replace('### ', '')}</h3>;
                  }
                  if (block.startsWith('## ')) {
                    return <h2 key={idx} className="text-xl font-bold text-emerald-300 mt-6 mb-2">{block.replace('## ', '')}</h2>;
                  }
                  if (block.startsWith('1. ') || block.startsWith('2. ') || block.startsWith('3. ') || block.startsWith('4. ')) {
                    return (
                      <div key={idx} className="pl-4 border-l-2 border-emerald-500/50 py-1 text-slate-300">
                        {block}
                      </div>
                    );
                  }
                  if (block.startsWith('- ')) {
                    return (
                      <ul key={idx} className="list-disc list-inside text-slate-300 space-y-1">
                        {block.split('\n').map((line, liIdx) => (
                          <li key={liIdx}>{line.replace('- ', '')}</li>
                        ))}
                      </ul>
                    );
                  }
                  return <p key={idx} className="text-slate-300 leading-relaxed">{block}</p>;
                })}
              </div>

              {/* Tags at bottom */}
              {activeArticle.tags && (
                <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center gap-2">
                  <span className="text-xs text-slate-500 font-medium">Tagged:</span>
                  {activeArticle.tags.map((t, idx) => (
                    <span key={idx} className="text-xs px-2.5 py-1 rounded bg-slate-800 text-emerald-400 border border-slate-700">
                      #{t}
                    </span>
                  ))}
                </div>
              )}

              {/* Author Footnote */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-4">
                <img
                  src={profile.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80"}
                  alt={profile.name}
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full object-cover border border-emerald-500/40 shrink-0"
                />
                <div className="text-xs">
                  <div className="font-bold text-white">{profile.name}</div>
                  <div className="text-emerald-400">{profile.companyRole}</div>
                  <div className="text-slate-400 mt-0.5">Based in {profile.location}</div>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

    </section>
  );
};

