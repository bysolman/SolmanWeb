import React from 'react';
import { Star, Quote, Award, Globe, CheckCircle2 } from 'lucide-react';
import { ProfileData } from '../types';

interface ReviewsSectionProps {
  profile: ProfileData;
}

interface Testimonial {
  id: string;
  clientName: string;
  company: string;
  country: string;
  role: string;
  content: string;
  rating: number;
  service: string;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ profile }) => {
  const testimonials: Testimonial[] = [
    {
      id: "rev-1",
      clientName: "Rashid Al-Maktoum",
      company: "Emirates Agro & Spice Import LLC",
      country: "United Arab Emirates",
      role: "Managing Director",
      content: "Solman Hussain Choudhury and M/S. Chaikosh Agrielectro Industries delivered exceptional quality organic ginger and high-curcumin turmeric. Their export documentation, APEDA compliance, and container dispatch precision are world-class.",
      rating: 5,
      service: "Global Agricultural Export (UAE)"
    },
    {
      id: "rev-2",
      clientName: "Liam Henderson",
      company: "Australasia Botanical & Tea Traders",
      country: "Australia",
      role: "Procurement Head",
      content: "Sourcing authentic Assam orthodox teas directly through Solman's enterprise has been seamless. Outstanding transparency, moisture-barrier packaging, and reliable maritime freight logistics.",
      rating: 5,
      service: "Assam Tea Export (Australia & UK)"
    },
    {
      id: "rev-3",
      clientName: "Ananya Sen Gupta",
      company: "North East Industrial Ventures",
      country: "India",
      role: "Founder & CEO",
      content: "Solman's expertise in Income Tax, GST statutory filings, MSME setup, and project report preparation for bank loans is remarkable. He saved our startup months of regulatory delays.",
      rating: 5,
      service: "Taxation & DPR Consultancy"
    },
    {
      id: "rev-4",
      clientName: "Kenji Takahashi",
      company: "Tokyo Organic & Mineral Imports",
      country: "Japan",
      role: "Senior Partner",
      content: "Professional, prompt, and rigorous in quality standards. We partnered with Chaikosh Industries for specialized mineral and spice logistics, and every shipment arrived ahead of schedule.",
      rating: 5,
      service: "International Trade & Compliance"
    }
  ];

  return (
    <section id="reviews" className="py-24 bg-slate-950 relative overflow-hidden">
      {/* Background Accent Gradients */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/80 border border-emerald-800/60 text-emerald-300 text-xs font-semibold">
            <Award className="w-4 h-4 text-emerald-400" />
            <span>Global Client Testimonials & Reviews</span>
          </div>
          
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Trusted by International Buyers & Enterprises
          </h2>
          
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Read verified feedback from global trade partners in the UAE, Australia, UK, and Japan, alongside regional corporate consultancy clients.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((item) => (
            <div 
              key={item.id}
              className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-7 sm:p-8 relative flex flex-col justify-between hover:border-emerald-500/50 transition-all duration-300 shadow-xl group"
            >
              <div className="absolute top-6 right-6 text-emerald-500/20 group-hover:text-emerald-500/30 transition-colors">
                <Quote className="w-12 h-12" />
              </div>

              <div className="space-y-4 relative z-10">
                {/* Rating Stars */}
                <div className="flex items-center gap-1">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                  <span className="ml-2 text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/80">
                    {item.service}
                  </span>
                </div>

                {/* Content */}
                <p className="text-slate-300 text-sm sm:text-base leading-relaxed italic">
                  "{item.content}"
                </p>
              </div>

              {/* Client Info */}
              <div className="mt-8 pt-6 border-t border-slate-800/80 flex items-center justify-between relative z-10">
                <div className="space-y-1">
                  <h4 className="text-white font-bold text-base flex items-center gap-2">
                    <span>{item.clientName}</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  </h4>
                  <p className="text-xs text-emerald-300 font-medium">{item.company}</p>
                </div>

                <div className="text-right">
                  <span className="inline-flex items-center gap-1 text-xs text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                    <Globe className="w-3.5 h-3.5 text-teal-400" />
                    <span>{item.country}</span>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Trust Badge */}
        <div className="mt-16 text-center bg-slate-900/60 border border-slate-800 rounded-2xl p-6 max-w-2xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-4 text-slate-300 text-xs sm:text-sm">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-semibold text-white">100% Export Compliance & Quality Assured</span>
          </div>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="text-slate-400">IEC, APEDA, FSSAI & Certified Tax Advisory</span>
        </div>

      </div>
    </section>
  );
};
