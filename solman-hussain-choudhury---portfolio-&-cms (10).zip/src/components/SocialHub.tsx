import React, { useState } from 'react';
import { 
  Linkedin, Facebook, Instagram, Mail, Phone, MessageSquare, 
  Globe, ExternalLink, Copy, Check, Share2, Sparkles, 
  MapPin, ShieldCheck, ArrowUpRight, Building2, Send
} from 'lucide-react';
import { ProfileData } from '../types';

interface SocialHubProps {
  profile: ProfileData;
}

export const SocialHub: React.FC<SocialHubProps> = ({ profile }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const socialChannels = [
    {
      id: 'linkedin',
      category: 'Professional & Advisory',
      name: 'LinkedIn Profile',
      handle: 'Solman Hussain Choudhury',
      url: profile.linkedin || "https://www.linkedin.com/in/solman-hussain-choudhury-33749120b?utm_source=share_via&utm_content=profile&utm_medium=member_android",
      description: 'Merchant Exporter, Certified Consultant, Trade & Statutory Advisory Network',
      badge: 'Verified Professional',
      icon: Linkedin,
      color: 'from-blue-600 to-cyan-600',
      badgeBg: 'bg-blue-950 text-blue-300 border-blue-800/60',
      actionText: 'Connect on LinkedIn',
      isPrimary: true
    },
    {
      id: 'facebook',
      category: 'Social & Community',
      name: 'Facebook Profile',
      handle: profile.facebookName || 'Solman Hussain Choudhury',
      url: profile.facebook || "https://www.facebook.com/share/19NBsL65vz/",
      description: 'Personal updates, Northeast travel logs, cultural reflections & community outreach',
      badge: 'Official Account',
      icon: Facebook,
      color: 'from-blue-500 to-indigo-600',
      badgeBg: 'bg-indigo-950 text-indigo-300 border-indigo-800/60',
      actionText: 'Follow on Facebook'
    },
    {
      id: 'twitter-personal',
      category: 'Microblogging & Thoughts',
      name: 'X / Twitter (Personal)',
      handle: '@solysiux',
      url: profile.twitterPersonal || "https://x.com/solysiux",
      description: 'Traveler observations, market insights, history & Northeast regional economic perspectives',
      badge: 'Personal Handle',
      icon: Share2,
      color: 'from-slate-700 to-slate-900',
      badgeBg: 'bg-slate-800 text-slate-300 border-slate-700',
      actionText: 'Follow @solysiux'
    },
    {
      id: 'twitter-business',
      category: 'Enterprise & Trade',
      name: 'X / Twitter (Chaikosh HQ)',
      handle: '@ChaikoshHQ',
      url: profile.twitterBusiness || "https://x.com/ChaikoshHQ",
      description: 'Official corporate announcements for M/S. CHAIKOSH AGRIELECTRO INDUSTRIES & export trade',
      badge: 'Company Handle',
      icon: Building2,
      color: 'from-teal-600 to-emerald-700',
      badgeBg: 'bg-teal-950 text-teal-300 border-teal-800/60',
      actionText: 'Follow @ChaikoshHQ'
    },
    {
      id: 'instagram-personal',
      category: 'Visual Journey & Expeditions',
      name: 'Instagram (Personal)',
      handle: profile.instagramHandle || '@solysiux',
      url: profile.instagram || "https://instagram.com/solysiux",
      description: 'Scenic expeditions, Northeast Assam landscapes, tea gardens & lifestyle photography',
      badge: 'Explorer Grid',
      icon: Instagram,
      color: 'from-pink-600 via-purple-600 to-orange-500',
      badgeBg: 'bg-pink-950 text-pink-300 border-pink-800/60',
      actionText: 'View Photos & Reels'
    },
    {
      id: 'instagram-brand',
      category: 'Curated Brand & Ventures',
      name: 'Instagram (By Solman)',
      handle: '@bysolman',
      url: profile.instagramBrand || "https://instagram.com/bysolman",
      description: 'Curated business initiatives, brand aesthetics, export highlights & creative ventures',
      badge: 'Brand Channel',
      icon: Instagram,
      color: 'from-amber-600 to-rose-600',
      badgeBg: 'bg-amber-950 text-amber-300 border-amber-800/60',
      actionText: 'Follow @bysolman'
    },
    {
      id: 'whatsapp-personal',
      category: 'Instant Messaging',
      name: 'WhatsApp Direct (Personal & Advisory)',
      handle: profile.personalPhone,
      url: `https://wa.me/916001565255?text=Hello%20Solman%20Choudhury,%20I%20am%20connecting%20from%20your%20portfolio%20website.`,
      description: 'Quick consultations for Income Tax, GST, Vehicle Insurance (New/Old) & entity filings',
      badge: 'Instant Response',
      icon: MessageSquare,
      color: 'from-emerald-600 to-teal-700',
      badgeBg: 'bg-emerald-950 text-emerald-300 border-emerald-800/60',
      actionText: 'Chat on WhatsApp',
      isPhone: true,
      copyValue: '+916001565255'
    },
    {
      id: 'whatsapp-business',
      category: 'Export Inquiries',
      name: 'WhatsApp (M/S. CHAIKOSH AGRIELECTRO INDUSTRIES)',
      handle: profile.businessPhone,
      url: `https://wa.me/916003348068?text=Hello%20M/S.%20CHAIKOSH%20AGRIELECTRO%20INDUSTRIES,%20I%20have%20an%20export/business%20inquiry.`,
      description: 'Dedicated trade desk for global agro-commodities, tea bulk orders & electronics sourcing',
      badge: 'B2B Trade Desk',
      icon: MessageSquare,
      color: 'from-teal-600 to-cyan-700',
      badgeBg: 'bg-teal-950 text-teal-300 border-teal-800/60',
      actionText: 'Chat with Trade Desk',
      isPhone: true,
      copyValue: '+916003348068'
    },
    {
      id: 'email-consultancy',
      category: 'Personal & Tax Consultancy',
      name: 'Personal & Tax Advisory Email',
      handle: 'contact@solmanchoudhury.in',
      url: 'mailto:contact@solmanchoudhury.in',
      description: 'Personal briefs, Income Tax planning, GST compliance, vehicle insurance & advisory',
      badge: 'Personal & Tax Desk',
      icon: Mail,
      color: 'from-emerald-700 to-slate-800',
      badgeBg: 'bg-emerald-950 text-emerald-300 border-emerald-800/60',
      actionText: 'Email Personal / Tax Desk',
      copyValue: 'contact@solmanchoudhury.in'
    },
    {
      id: 'email-export-primary',
      category: 'Import/Export & International Business',
      name: 'Chaikosh Merchant Export Desk (Primary)',
      handle: 'admin@chaikosh.in',
      url: 'mailto:admin@chaikosh.in',
      description: 'Global trade inquiries, GI agro exports (ginger, turmeric, tea) & limestone orders',
      badge: 'DGFT / IEC Verified',
      icon: Mail,
      color: 'from-cyan-700 to-slate-800',
      badgeBg: 'bg-cyan-950 text-cyan-300 border-cyan-800/60',
      actionText: 'Email Primary Trade Desk',
      copyValue: 'admin@chaikosh.in'
    },
    {
      id: 'email-export-secondary',
      category: 'Import/Export & International Business',
      name: 'M/S. CHAIKOSH AGRIELECTRO INDUSTRIES (Official)',
      handle: 'chaikoshagrielectroindustries@gmail.com',
      url: 'mailto:chaikoshagrielectroindustries@gmail.com',
      description: 'Official commerce communications, consignments, contracts & logistics inquiries',
      badge: 'Official Export Mail',
      icon: Mail,
      color: 'from-teal-700 to-slate-800',
      badgeBg: 'bg-teal-950 text-teal-300 border-teal-800/60',
      actionText: 'Email Export Official',
      copyValue: 'chaikoshagrielectroindustries@gmail.com'
    }
  ];

  return (
    <section id="social-hub" className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-emerald-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 shadow-sm">
            <Share2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Unified Social & Connect Hub</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Connect Across All <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-300">
              Official Media & Business Channels
            </span>
          </h2>
          <p className="text-sm text-slate-400">
            All authentic profiles, direct messaging channels, professional networks, and export desks consolidated in one verified directory.
          </p>
        </div>

        {/* Real Address & Identity Banner */}
        <div className="mb-12 bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800/80 shrink-0">
              <MapPin className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  Official Permanent Address & Headquarters
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  Cachar District • Assam
                </span>
              </div>
              <p className="text-sm sm:text-base font-semibold text-white">
                Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam, PIN 788804
              </p>
              <p className="text-xs text-slate-400">
                Barak Valley Region, Northeast India • Base for {profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"} & Professional Consultancy Practice
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto shrink-0">
            <button
              onClick={() => handleCopy("Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam, PIN 788804", 'official-address')}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 transition-all flex items-center justify-center gap-1.5 w-full md:w-auto"
            >
              {copiedId === 'official-address' ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Address Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Full Address</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Social Cards Grid - Compact 4 to 6 in one line */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {socialChannels.map((item) => {
            const Icon = item.icon;
            const isCopied = copiedId === item.id;

            return (
              <div 
                key={item.id}
                className="bg-slate-900/80 rounded-xl p-3 border border-slate-800 hover:border-emerald-600/50 shadow-md flex flex-col justify-between group transition-all duration-200 hover:-translate-y-0.5"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center text-white shadow-sm shrink-0`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    {item.copyValue && (
                      <button
                        onClick={() => handleCopy(item.copyValue!, item.id)}
                        className="p-1 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors shrink-0"
                        title={`Copy ${item.handle}`}
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    )}
                  </div>

                  <div className="min-w-0">
                    <h3 className="text-xs font-bold text-white group-hover:text-emerald-400 transition-colors truncate">
                      {item.name}
                    </h3>
                    <div className="text-[11px] font-mono text-slate-400 truncate">
                      {item.handle}
                    </div>
                  </div>
                </div>

                <div className="pt-2 mt-2 border-t border-slate-800/80">
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-1.5 px-2 rounded-lg text-[11px] font-semibold bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white flex items-center justify-center gap-1 transition-all"
                  >
                    <span>Connect</span>
                    <ArrowUpRight className="w-3 h-3 shrink-0" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
