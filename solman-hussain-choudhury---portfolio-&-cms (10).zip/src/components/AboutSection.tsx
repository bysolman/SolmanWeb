import React from 'react';
import { 
  GraduationCap, Compass, Trees, Mountain, 
  Landmark, Globe, BookOpen, Award, CheckCircle, 
  MapPin, Building2, ShieldCheck, Car, Sparkles, 
  Phone, Mail, ArrowRight, ExternalLink 
} from 'lucide-react';
import { ProfileData } from '../types';

interface AboutSectionProps {
  profile: ProfileData;
  onOpenConsultation: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ profile, onOpenConsultation }) => {
  return (
    <section id="about" className="py-24 bg-slate-900 text-slate-100 relative overflow-hidden border-t border-slate-800">
      
      {/* Decorative ambient background */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-700/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-teal-700/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 shadow-sm">
            <Landmark className="w-3.5 h-3.5 text-emerald-400" />
            <span>Profile & Professional Journey</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            Rooted in Northeast Heritage, <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300">
              Driven by Entrepreneurial Vision
            </span>
          </h2>
          <p className="text-sm sm:text-base text-slate-400">
            A split overview uniting real-world identity, academic depth in history, and multi-sector commercial leadership.
          </p>
        </div>

        {/* Split Layout: Side 1 (Photo + Name + Designation) | Side 2 (Biographical & Professional Details) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          
          {/* ================= SIDE 1: Profile Identity Group (Photo, Full Name & Designation) ================= */}
          <div className="lg:col-span-5 sticky top-28 space-y-6">
            <div className="bg-gradient-to-b from-slate-800/90 to-slate-900/90 rounded-3xl p-6 sm:p-7 border border-slate-700/80 shadow-2xl backdrop-blur-xl relative overflow-hidden group">
              
              {/* Subtle top ambient glow inside card */}
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
              
              {/* Photo Card with Verified Badge */}
              <div className="relative rounded-2xl overflow-hidden aspect-[4/4] sm:aspect-[4/4] bg-slate-950 border border-emerald-500/30 shadow-inner mb-6">
                <img 
                  src={profile.avatarUrl || "/images/solman_choudhury.jpg"}
                  alt={profile.name}
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "/images/solman_profile_portrait_1787221729849.jpg";
                  }}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700"
                />
                
                {/* Overlay Badges */}
                <div className="absolute top-3 left-3">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-slate-950/80 text-emerald-300 border border-emerald-700/60 backdrop-blur-md shadow-md">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    Verified Profile
                  </span>
                </div>

                <div className="absolute bottom-3 right-3">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-slate-950/80 text-amber-300 border border-amber-700/60 backdrop-blur-md shadow-md">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    Assam • India
                  </span>
                </div>
              </div>

              {/* Grouped Name & Designation Header */}
              <div className="space-y-3 text-left border-b border-slate-700/70 pb-5">
                <div className="space-y-1">
                  <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-400">
                    Official Executive Profile
                  </span>
                  <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                    {profile.name}
                  </h3>
                </div>

                {/* Primary Designations */}
                <div className="space-y-1.5 pt-1">
                  <p className="text-sm font-semibold text-emerald-300 flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Managing Partner, {profile.company}</span>
                  </p>
                  <p className="text-xs text-slate-300 flex items-center gap-2">
                    <Globe className="w-4 h-4 text-teal-400 shrink-0" />
                    <span>Merchant Exporter & Global Commerce Practitioner</span>
                  </p>
                  <p className="text-xs text-slate-300 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Certified Tax, Business & Vehicle Insurance Advisor</span>
                  </p>
                  <p className="text-xs text-slate-300 flex items-center gap-2">
                    <Compass className="w-4 h-4 text-teal-300 shrink-0" />
                    <span>Avid Traveler & Heritage Geography Explorer</span>
                  </p>
                </div>
              </div>

              {/* Essential Contact & Location Quick Attributes */}
              <div className="py-4 space-y-2.5 text-xs text-slate-300">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/70 border border-slate-700/50">
                  <span className="text-slate-400 flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    Base Location:
                  </span>
                  <span className="font-semibold text-white">{profile.location}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/70 border border-slate-700/50">
                  <span className="text-slate-400 flex items-center gap-2">
                    <GraduationCap className="w-3.5 h-3.5 text-teal-400" />
                    Education:
                  </span>
                  <span className="font-semibold text-white">BA in History (Assam Univ)</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/70 border border-slate-700/50">
                  <span className="text-slate-400 flex items-center gap-2">
                    <Globe className="w-3.5 h-3.5 text-emerald-400" />
                    Official Website:
                  </span>
                  <a href="https://chaikosh.in" target="_blank" rel="noopener noreferrer" className="font-semibold text-emerald-300 font-mono text-[11px] hover:underline flex items-center gap-1">
                    Chaikosh.in <ExternalLink className="w-3 h-3 text-emerald-400" />
                  </a>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/70 border border-slate-700/50">
                  <span className="text-slate-400 flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-emerald-400" />
                    Direct Inquiries:
                  </span>
                  <span className="font-semibold text-emerald-300 font-mono text-[11px]">contact@solmanchoudhury.in</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-col gap-2.5">
                <button
                  id="about-schedule-consultation-btn"
                  onClick={onOpenConsultation}
                  className="w-full py-3 px-4 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md active:scale-95 flex items-center justify-center gap-2"
                >
                  <span>Book Consultation with Solman</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href={`https://wa.me/916001565255?text=Hello%20Solman%20Choudhury,%20I%20am%20reaching%20out%20from%20your%20portfolio%20website.`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:text-white transition-all flex items-center justify-center gap-2"
                >
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp +91 6001565255</span>
                </a>
              </div>

            </div>
          </div>


          {/* ================= SIDE 2: Comprehensive Biographical & Professional Details ================= */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Executive Bio Card */}
            <div className="bg-slate-800/60 rounded-3xl p-6 sm:p-8 border border-slate-700/70 shadow-xl space-y-6 backdrop-blur-sm">
              <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-950/80 text-emerald-400 flex items-center justify-center border border-emerald-800/60">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Biographical Narrative</h3>
                    <p className="text-xs text-slate-400">Origins, academic depth & professional evolution</p>
                  </div>
                </div>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-900 text-emerald-400 border border-slate-700">
                  Cachar District, Assam
                </span>
              </div>

              <div className="prose prose-invert max-w-none text-slate-300 text-sm sm:text-base leading-relaxed space-y-4">
                <p>
                  <strong>Solman Hussain Choudhury</strong> is an agile entrepreneur, certified business consultant, merchant exporter, and passionate explorer based out of <strong>Vill Mohanpur Pt II, PO Katirail, PS Katigorah, District Cachar, Assam (PIN 788804)</strong>. Grounded in a strong academic foundation with a <strong>BA in History, Assam University</strong>, he draws upon the historic commercial trade routes, geographical diversity, and cultural richness of Northeast India to build enduring enterprises.
                </p>
                
                <p>
                  As an <strong>avid traveler and heritage explorer</strong>, Solman regularly traverses the hills, riverine valleys, and cultural crossroads of Assam and Northeast India. He actively studies regional history and physical geography—ranging from the Barak River basin to the misty highlands of Upper Assam—deriving strategic business foresight from the historic interconnectedness of regional trade corridors.
                </p>

                <p>
                  At <strong>{profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"}</strong>, where he serves as Managing Partner, his primary focus is <strong>exporting Northeast India's GI-tagged and non-GI agricultural products</strong> (such as organic ginger, turmeric, and high-altitude Assam teas), along with cross-border mineral logistics including the <strong>export of Limestone to Bangladesh</strong>, and industrial component sourcing.
                </p>

                <p>
                  Parallel to his export ventures, Solman leads a dedicated consultancy practice offering end-to-end solutions in <strong>Income Tax (ITR)</strong>, <strong>GST compliance</strong>, business entity incorporation (Pvt Ltd, LLP, Partnership, Trust & NGO), <strong>Vehicle Insurance</strong> (complete protection for both new and pre-owned 2-wheelers, 4-wheelers, and commercial fleets), life/health insurance advisory, and digital web development.
                </p>
              </div>

              {/* Education & Core Focus Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/60">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400">
                      <GraduationCap className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-emerald-400 uppercase tracking-wide">Academic Degree</div>
                      <div className="text-sm font-bold text-white">BA in History, Assam University</div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Assam University — specialized study of historic trade routes, administrative systems, and regional socioeconomic geography.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-700/60">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="p-2 rounded-lg bg-teal-950 text-teal-400">
                      <Compass className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-teal-400 uppercase tracking-wide">Travel & Exploration</div>
                      <div className="text-sm font-bold text-white">Northeast Corridors</div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Extensive field expeditions across the Barak Valley, Assam tea estates, and Northeast frontier corridors studying local geography & trade.
                  </p>
                </div>
              </div>
            </div>

            {/* Core Professional Pillars Grid */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                <span>Core Professional Pillars & Practice Areas</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-1.5">
                    <Globe className="w-4 h-4 shrink-0" />
                    <span>Merchant Export & Trade</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Managing Partner at {profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"}. Primary focus on exporting Northeast GI-tagged & non-GI agro products (ginger, turmeric, tea) and Limestone to Bangladesh with complete IEC/APEDA compliance.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-2 text-teal-400 font-bold text-sm mb-1.5">
                    <Landmark className="w-4 h-4 shrink-0" />
                    <span>Taxation & Statutory Filings</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Complete Income Tax Returns (ITR-1 to ITR-6), GST registration & periodic filings, Professional Tax assessments, and MSME/Trade licenses.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-sm mb-1.5">
                    <Car className="w-4 h-4 shrink-0" />
                    <span>Comprehensive Vehicle Insurance</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Certified advisory for brand-new and old/pre-owned 2-wheelers, private cars, commercial trucks, and fleet transit policies with instant quote issuance.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-700/60 hover:border-emerald-500/40 transition-colors">
                  <div className="flex items-center gap-2 text-blue-400 font-bold text-sm mb-1.5">
                    <ShieldCheck className="w-4 h-4 shrink-0" />
                    <span>Corporate Formation & Loans</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Private Limited, LLP, Partnership, 12A/80G Trust/NGO formations, along with Detailed Project Reports (DPR) and CMA data for bank loan approvals.
                  </p>
                </div>

              </div>
            </div>

            {/* Guiding Philosophy Banner */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-950/40 via-slate-900 to-teal-950/40 border border-emerald-800/50">
              <div className="flex items-start gap-3">
                <Award className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                    The Guiding Philosophy
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-300 italic leading-relaxed">
                    "True enterprise flourishes when modern business strategy is anchored in a deep respect for regional heritage, transparent compliance, and meaningful human relationships."
                  </p>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
