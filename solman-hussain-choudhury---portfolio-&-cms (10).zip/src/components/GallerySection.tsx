import React, { useState } from 'react';
import { 
  Image as ImageIcon, Video, Play, Maximize2, 
  X, Calendar, Tag, Filter, PlusCircle 
} from 'lucide-react';
import { GalleryItem } from '../types';

interface GallerySectionProps {
  gallery: GalleryItem[];
  onOpenAdminUpload: () => void;
}

export const GallerySection: React.FC<GallerySectionProps> = ({ 
  gallery, 
  onOpenAdminUpload 
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeMedia, setActiveMedia] = useState<GalleryItem | null>(null);

  const categories = [
    'All',
    'Northeast Expeditions',
    'Global Trade & Agrielectro',
    'Nature & Travels',
    'Consultancy & Engagements',
    'Videos'
  ];

  const filteredItems = gallery.filter((item) => {
    if (selectedCategory === 'All') return true;
    if (selectedCategory === 'Videos') return item.mediaType === 'video';
    return item.category === selectedCategory;
  });

  const isEmbedVideo = (url: string) => {
    return url.includes('youtube.com') || url.includes('youtu.be') || url.includes('vimeo.com');
  };

  const getEmbedUrl = (url: string) => {
    if (url.includes('youtube.com/watch?v=')) {
      return url.replace('watch?v=', 'embed/');
    }
    if (url.includes('youtu.be/')) {
      const id = url.split('youtu.be/')[1]?.split('?')[0];
      return `https://www.youtube.com/embed/${id}`;
    }
    return url;
  };

  return (
    <section id="gallery" className="py-24 bg-slate-950 text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950 text-emerald-400 border border-emerald-800/60">
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Media & Field Visuals</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
              Moments, Expeditions & <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-300">
                Commercial Engagements
              </span>
            </h2>
            <p className="text-sm text-slate-400">
              A curated photographic and video chronicle of Northeast landscape studies, trade operations, and field journeys.
            </p>
          </div>

          {/* Add Media Quick Trigger */}
          <div>
            <button
              onClick={onOpenAdminUpload}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-300 bg-slate-900 hover:bg-slate-800 hover:text-emerald-400 border border-slate-700 transition-all shadow-sm"
            >
              <PlusCircle className="w-4 h-4 text-emerald-400" />
              <span>Upload via CMS</span>
            </button>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Media Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-slate-900/40 rounded-2xl border border-slate-800">
            <p className="text-slate-400 text-sm">No media items found in this category.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                id={`gallery-item-${item.id}`}
                onClick={() => setActiveMedia(item)}
                className="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 hover:border-emerald-600/50 shadow-xl cursor-pointer transition-all duration-300 flex flex-col justify-between"
              >
                {/* Media Thumbnail Container */}
                <div className="relative aspect-[16/10] overflow-hidden bg-slate-950">
                  {item.mediaType === 'video' ? (
                    <div className="relative w-full h-full">
                      {isEmbedVideo(item.url) ? (
                        <div className="w-full h-full flex items-center justify-center bg-slate-950">
                          <Video className="w-10 h-10 text-emerald-400 opacity-60" />
                        </div>
                      ) : (
                        <video
                          src={item.url}
                          className="w-full h-full object-cover"
                          muted
                          playsInline
                        />
                      )}
                      {/* Play Button Overlay */}
                      <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center group-hover:bg-slate-950/20 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-emerald-500/90 text-slate-950 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                          <Play className="w-5 h-5 fill-slate-950 ml-0.5" />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <img
                      src={item.url}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                  )}

                  {/* Top Badge Overlay */}
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-slate-950/80 text-emerald-300 backdrop-blur-md border border-slate-700/60">
                      {item.category}
                    </span>
                  </div>

                  <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="p-1.5 rounded-md bg-slate-900/80 text-white backdrop-blur-md">
                      <Maximize2 className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>

                {/* Details Footer */}
                <div className="p-4 bg-slate-900/90 flex flex-col justify-between flex-1">
                  <div>
                    <h3 className="font-bold text-sm text-white group-hover:text-emerald-400 transition-colors line-clamp-1">
                      {item.title}
                    </h3>
                    {item.caption && (
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                        {item.caption}
                      </p>
                    )}
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3 text-emerald-400" />
                      <span>{item.date}</span>
                    </span>
                    <span className="capitalize font-medium text-slate-400 flex items-center gap-1">
                      {item.mediaType === 'video' ? <Video className="w-3 h-3" /> : <ImageIcon className="w-3 h-3" />}
                      <span>{item.mediaType}</span>
                    </span>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}

      </div>

      {/* Lightbox / Video Modal */}
      {activeMedia && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md animate-in fade-in duration-200">
          <div className="relative max-w-4xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl">
            
            <button
              onClick={() => setActiveMedia(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-slate-950/80 text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Media Canvas */}
            <div className="relative aspect-video bg-black flex items-center justify-center">
              {activeMedia.mediaType === 'video' ? (
                isEmbedVideo(activeMedia.url) ? (
                  <iframe
                    src={getEmbedUrl(activeMedia.url)}
                    className="w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    title={activeMedia.title}
                  />
                ) : (
                  <video
                    src={activeMedia.url}
                    controls
                    autoPlay
                    className="w-full h-full object-contain"
                  />
                )
              ) : (
                <img
                  src={activeMedia.url}
                  alt={activeMedia.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
              )}
            </div>

            {/* Modal Info Bar */}
            <div className="p-6 bg-slate-900 border-t border-slate-800">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                  {activeMedia.category} • {activeMedia.mediaType}
                </span>
                <span className="text-xs text-slate-400">Date: {activeMedia.date}</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{activeMedia.title}</h3>
              {activeMedia.caption && (
                <p className="text-sm text-slate-300 leading-relaxed">{activeMedia.caption}</p>
              )}
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
