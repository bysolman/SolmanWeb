import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, X, Send, User, Bot, PhoneCall, MessageSquare, ExternalLink, ShieldCheck } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export const GeminiChatWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-1',
      role: 'assistant',
      text: "Hello! I am Hamza, the official AI assistant for Solman Hussain Choudhury's enterprise and consultancy. May I know why you visited us today and what help you require? I am here to assist you with global exports, tax advisory, and services, or connect you with a human agent if needed.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [isOpen, messages]);

  const handleSendMessage = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSend = customText || inputValue.trim();
    if (!textToSend || isTyping) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customText) setInputValue('');
    setIsTyping(true);

    try {
      // Build history
      const historyPayload = messages.map(m => ({ role: m.role, text: m.text }));
      const response = await fetch('/api/gemini-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: textToSend, history: historyPayload })
      });
      const data = await response.json();

      const botReply: Message = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        text: data.reply || "Please wait sometime agent will connect and he or she will give you answers shortly.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botReply]);
    } catch (err) {
      const errorReply: Message = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        text: "Please wait sometime agent will connect and he or she will give you answers shortly. You can also reach Solman directly at +91 6001565255.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorReply]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleRequestHumanAgent = () => {
    const handoffMsg: Message = {
      id: `usr-${Date.now()}`,
      role: 'user',
      text: "I would like to talk with a human agent.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    const agentReply: Message = {
      id: `bot-${Date.now() + 1}`,
      role: 'assistant',
      text: "Please wait sometime agent will connect and he or she will give you answers shortly. In the meantime, you can connect instantly via Google Chat or WhatsApp (+91 6001565255).",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages((prev) => [...prev, handoffMsg, agentReply]);
  };

  return (
    <div className="fixed bottom-6 left-6 z-50">
      {/* Floating Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white px-4 py-3.5 rounded-full shadow-2xl border border-emerald-400/30 transition-all duration-300 hover:scale-105 group"
          title="Chat with Gemini AI Assistant"
        >
          <div className="relative">
            <Sparkles className="w-5 h-5 text-emerald-200 animate-pulse" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-300 rounded-full animate-ping" />
          </div>
          <span className="text-xs sm:text-sm font-bold tracking-tight">Hamza AI Assistant</span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl w-[92vw] sm:w-[400px] h-[540px] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300">
          
          {/* Header */}
          <div className="bg-slate-950 px-4 py-3.5 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-white text-xs sm:text-sm font-bold flex items-center gap-1.5">
                  <span>Hamza AI Assistant</span>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                </h3>
                <p className="text-[10px] text-emerald-300 font-medium flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Powered by Google Gemini</span>
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-900 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-950/60 text-xs sm:text-sm">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.role === 'assistant' && (
                  <div className="w-7 h-7 rounded-lg bg-emerald-900/80 border border-emerald-700 flex items-center justify-center text-emerald-300 shrink-0 mt-0.5">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                
                <div
                  className={`max-w-[80%] px-3.5 py-2.5 rounded-2xl leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-emerald-600 text-white rounded-br-xs'
                      : 'bg-slate-900 text-slate-200 border border-slate-800 rounded-bl-xs'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                  <span className={`block text-[9px] mt-1 text-right ${msg.role === 'user' ? 'text-emerald-200' : 'text-slate-500'}`}>
                    {msg.timestamp}
                  </span>
                </div>

                {msg.role === 'user' && (
                  <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300 shrink-0 mt-0.5">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {isTyping && (
              <div className="flex gap-2.5 items-center">
                <div className="w-7 h-7 rounded-lg bg-emerald-900/80 border border-emerald-700 flex items-center justify-center text-emerald-300">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="bg-slate-900 border border-slate-800 px-3.5 py-2.5 rounded-2xl text-slate-400 text-xs flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce" />
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.2s]" />
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce [animation-delay:0.4s]" />
                  <span className="ml-1 text-[11px]">Gemini is thinking...</span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick Suggestion Pills & Human Agent Handoff Bar */}
          <div className="px-3 py-2 bg-slate-950 border-t border-slate-800/80 flex flex-wrap gap-1.5 items-center">
            <button
              onClick={() => handleSendMessage(undefined, "Tell me about Chaikosh export commodities")}
              className="text-[10px] bg-slate-900 hover:bg-slate-800 text-emerald-300 px-2.5 py-1 rounded-full border border-slate-800 transition-colors"
            >
              🌿 Export Spices & Tea
            </button>
            <button
              onClick={() => handleSendMessage(undefined, "How to file ITR or GST with Solman?")}
              className="text-[10px] bg-slate-900 hover:bg-slate-800 text-teal-300 px-2.5 py-1 rounded-full border border-slate-800 transition-colors"
            >
              📊 Tax & GST Filing
            </button>
            <button
              onClick={handleRequestHumanAgent}
              className="text-[10px] bg-amber-950/80 hover:bg-amber-900/80 text-amber-300 px-2.5 py-1 rounded-full border border-amber-800/80 transition-colors flex items-center gap-1 font-semibold"
            >
              <PhoneCall className="w-3 h-3" />
              <span>Talk with Human Agent</span>
            </button>
          </div>

          {/* Direct External Chat Options (Google Chat / WhatsApp) */}
          <div className="px-3 py-1.5 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <a
              href="https://chat.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-medium"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Open Google Chat</span>
              <ExternalLink className="w-3 h-3" />
            </a>

            <a
              href="https://wa.me/916001565255?text=Hello%20Solman,%20I%20would%20like%20to%20discuss%20export%20or%20consultancy."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-teal-400 hover:text-teal-300 font-medium"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>WhatsApp Direct</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {/* Input Form */}
          <form onSubmit={(e) => handleSendMessage(e)} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask Gemini AI or request agent..."
              className="flex-1 bg-slate-900 border border-slate-700/80 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isTyping}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white p-2 rounded-xl transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

        </div>
      )}
    </div>
  );
};
