import React from 'react';
import { 
  Ship, PackageCheck, ShieldCheck, Globe2, 
  Leaf, Cpu, ArrowUpRight, CheckCircle2, FileText 
} from 'lucide-react';
import { ProfileData } from '../types';

interface TradeSpotlightProps {
  profile: ProfileData;
  onOpenConsultation: () => void;
}

export const TradeSpotlight: React.FC<TradeSpotlightProps> = ({ 
  profile, 
  onOpenConsultation 
}) => {
  return (
    <section id="global-trade" className="py-20 bg-slate-900 border-y border-slate-800 text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950/40 rounded-3xl p-8 sm:p-12 border border-emerald-800/40 shadow-2xl relative overflow-hidden">
          
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">
            
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-emerald-900/60 text-emerald-300 border border-emerald-700/50">
                <Ship className="w-3.5 h-3.5" />
                <span>Featured Venture & Merchant Export</span>
              </div>

              <div className="space-y-2">
                <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-extrabold text-white leading-tight tracking-tight break-words">
                  {profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"}
                </h3>
                <div className="text-xs sm:text-sm font-semibold text-emerald-400">
                  Managing Partner: Solman Hussain Choudhury (Merchant Exporter)
                </div>
              </div>

              <p className="text-xs sm:text-sm md:text-base text-slate-300 leading-relaxed">
                <strong className="text-white">{profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"}</strong> is a premier merchant export enterprise founded on reliability, regional sourcing excellence, and international cross-border integrity. Our <strong>primary focus is exporting Northeast India's GI-tagged and non-GI agricultural products</strong> (such as premium organic ginger, turmeric, and high-altitude Assam teas), along with cross-border mineral commerce including the <strong>export of Limestone to Bangladesh</strong> and precision sourcing of electronic components.
              </p>

              {/* Trade Pillars */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400 shrink-0">
                    <Leaf className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">GI & Non-GI Agro Exports</h4>
                    <p className="text-xs text-slate-400 mt-0.5">Northeast GI-tagged ginger, high-curcumin turmeric, and orthodox/CTC Assam teas.</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-cyan-950 text-cyan-400 shrink-0">
                    <Globe2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Limestone Export to Bangladesh</h4>
                    <p className="text-xs text-slate-400 mt-0.5">High-grade mineral logistics, bulk cross-border freight & customs clearance.</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-blue-950 text-blue-400 shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Export Documentation</h4>
                    <p className="text-xs text-slate-400 mt-0.5">IEC, APEDA, FSSAI, Spices Board, Certificate of Origin & border trade filings.</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-teal-950 text-teal-400 shrink-0">
                    <Cpu className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-200">Agrielectro & Components</h4>
                    <p className="text-xs text-slate-400 mt-0.5">Industrial electronics, components, and farm-tech hardware sourcing.</p>
                  </div>
                </div>
              </div>

              {/* CTAs */}
              <div className="pt-2 flex flex-wrap items-center gap-3">
                <a
                  href="mailto:admin@chaikosh.in?subject=International%20Trade%20Inquiry%20-%20Chaikosh%20Agrielectro%20Industries"
                  className="inline-flex items-center gap-2 px-4 sm:px-5 py-2.5 sm:py-3 rounded-xl text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition-all shadow-md shadow-emerald-500/20"
                >
                  <span>Inquire Trade Desk: admin@chaikosh.in</span>
                  <ArrowUpRight className="w-4 h-4 shrink-0" />
                </a>

                <a
                  href="mailto:chaikoshagrielectroindustries@gmail.com?subject=Export%20Inquiry%20-%20GI%20Agro%20%26%20Limestone"
                  className="inline-flex items-center gap-2 px-3.5 sm:px-4 py-2.5 sm:py-3 rounded-xl text-xs font-semibold text-slate-300 bg-slate-800 hover:text-white border border-slate-700 transition-colors font-mono max-w-full break-all"
                >
                  <span className="break-all">chaikoshagrielectroindustries@gmail.com</span>
                </a>
              </div>

            </div>

            {/* Right Visual Badge Card */}
            <div className="lg:col-span-5">
              <div className="bg-slate-900/90 rounded-2xl p-5 sm:p-6 border border-emerald-700/40 shadow-xl space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">Trade Profile</span>
                  <span className="text-xs text-slate-400">IEC Compliant</span>
                </div>

                <div className="space-y-3 text-xs sm:text-sm">
                  <div className="flex flex-col sm:flex-row sm:justify-between py-2 border-b border-slate-800/60 gap-1">
                    <span className="text-slate-400 shrink-0">Full Registered Entity Name</span>
                    <span className="font-bold text-white sm:text-right break-words text-xs sm:text-sm text-emerald-300">
                      {profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                    <span className="text-slate-400">Designation</span>
                    <span className="font-semibold text-emerald-300">Managing Partner</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                    <span className="text-slate-400">Official Website</span>
                    <a href="https://chaikosh.in" target="_blank" rel="noopener noreferrer" className="font-semibold text-emerald-300 hover:underline font-mono">
                      Chaikosh.in
                    </a>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                    <span className="text-slate-400">Operation Base</span>
                    <span className="font-semibold text-white">Badarpur, Assam (India)</span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                    <span className="text-slate-400">Business WhatsApp</span>
                    <a href="https://wa.me/916003348068" className="font-semibold text-emerald-400 hover:underline">
                      +91 6003348068
                    </a>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-slate-400">Specialization</span>
                    <span className="font-semibold text-white text-right">Agri Commodities & Electronics</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/50 text-xs text-emerald-300 flex items-center gap-2.5">
                  <Globe2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>Actively welcoming international B2B buyer inquiries & joint distribution partnerships.</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
