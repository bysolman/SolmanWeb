import React, { useState } from 'react';
import { X, Calendar, Send, CheckCircle2, PhoneCall, Sparkles } from 'lucide-react';
import { api } from '../services/api';
import { ProfileData } from '../types';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: ProfileData;
  preselectedService?: string;
  onSuccess?: () => void;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
  profile,
  preselectedService = 'General Consultation',
  onSuccess
}) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: preselectedService,
    preferredTime: 'Morning (10 AM - 1 PM)',
    message: ''
  });

  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  React.useEffect(() => {
    if (preselectedService) {
      setFormData(prev => ({ ...prev, service: preselectedService }));
    }
  }, [preselectedService]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) return;

    setLoading(true);
    try {
      await api.submitInquiry({
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        service: `[Consultation Booking: ${formData.service} | Preferred: ${formData.preferredTime}]`,
        message: formData.message || 'Consultation request scheduled from website modal.'
      });
      setSubmitted(true);
      if (onSuccess) onSuccess();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl overflow-y-auto max-h-[90vh]">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-lg text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800/60">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Book a Consultation</h3>
            <p className="text-xs text-slate-400">Direct Advisory with {profile.name}</p>
          </div>
        </div>

        {submitted ? (
          <div className="my-6 p-6 rounded-2xl bg-emerald-950/60 border border-emerald-800 text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h4 className="text-lg font-bold text-white">Consultation Requested!</h4>
            <p className="text-xs text-slate-300">
              Solman Hussain Choudhury has received your schedule request and will contact you via WhatsApp or phone to confirm the exact time slot.
            </p>
            <div className="pt-2 flex justify-center gap-3">
              <a
                href={`https://wa.me/916001565255?text=Hello%20Solman,%20I%20just%20scheduled%20a%20consultation%20for%20${encodeURIComponent(formData.service)}.`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-400 text-slate-950 hover:bg-emerald-300"
              >
                Send Instant WhatsApp Notice
              </a>
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5 mt-4 text-xs">
            <div>
              <label className="block font-medium text-slate-300 mb-1">
                Your Name <span className="text-emerald-400">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="Full Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-300 mb-1">
                  Phone / WhatsApp <span className="text-emerald-400">*</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+91 9876543210"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="name@example.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-300 mb-1">
                  Service Domain
                </label>
                <select
                  value={formData.service}
                  onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="Global Trade & Export">Global Trade & Export</option>
                  <option value="Vehicle Insurance (New & Old Vehicles)">Vehicle Insurance (New & Old Vehicles)</option>
                  <option value="Tax & Business Consultancy">Tax, GST & Registrations</option>
                  <option value="Certified Insurance Planning">Life & General Insurance Planning</option>
                  <option value="Digital Solutions">Digital Solutions & Websites</option>
                  <option value="Northeast Travel & Geography Advisory">Northeast Travel & Expeditions</option>
                  <option value="General Consultation">General Discussion</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1">
                  Preferred Time Slot
                </label>
                <select
                  value={formData.preferredTime}
                  onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="Morning (10 AM - 1 PM)">Morning (10 AM - 1 PM)</option>
                  <option value="Afternoon (2 PM - 5 PM)">Afternoon (2 PM - 5 PM)</option>
                  <option value="Evening (6 PM - 9 PM)">Evening (6 PM - 9 PM)</option>
                  <option value="Flexible / As soon as possible">Flexible / Urgent</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-medium text-slate-300 mb-1">
                Brief Context / Requirement
              </label>
              <textarea
                rows={3}
                placeholder="Briefly state your requirements or questions..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 resize-none"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl font-medium text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2.5 rounded-xl font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition-all shadow-md flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{loading ? 'Submitting...' : 'Confirm Schedule Request'}</span>
              </button>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
