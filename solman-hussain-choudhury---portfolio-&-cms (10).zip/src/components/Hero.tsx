import React from 'react';
import { 
  Compass, MapPin, GraduationCap, Mail, Phone, 
  ArrowDownRight, Building2, UserCheck, Sparkles, Briefcase,
  Ship, Car, FileCheck
} from 'lucide-react';
import { ProfileData } from '../types';

interface HeroProps {
  profile: ProfileData;
  onOpenConsultation?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ profile, onOpenConsultation }) => {
  return (
    <section 
      id="about" 
      className="relative pt-28 pb-16 md:pt-36 md:pb-20 overflow-hidden bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800/80"
    >
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[380px] bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-80 h-80 bg-teal-500/5 rounded-full blur-3xl pointer-events-none" />
      
      {/* Subtle grid pattern */}
      <div 
        className="absolute inset-0 opacity-[0.025] pointer-events-none" 
        style={{
          backgroundImage: `radial-gradient(#10b981 1px, transparent 1px)`,
          backgroundSize: '32px 32px'
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Main Unified Grid: Left (Concise About Me) | Right (Executive Portrait Card) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* ================= COLUMN 1: Short & Concise About Me ================= */}
          <div className="lg:col-span-7 space-y-6 text-left">
            
            {/* Top Identity Eyebrows */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>Executive Profile</span>
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-800/80 text-slate-300 border border-slate-700">
                <MapPin className="w-3 h-3 text-emerald-400" />
                <span>Cachar, Assam (Barak Valley)</span>
              </span>
            </div>

            {/* Headline & Title */}
            <div className="space-y-2.5">
              <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
                Solman Hussain Choudhury
              </h1>
              <p className="text-base sm:text-lg font-semibold text-emerald-400 flex items-center gap-2 flex-wrap">
                <span>Managing Partner</span>
                <span className="text-slate-500">•</span>
                <span>{profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"}</span>
              </p>
            </div>

            {/* Short & Elegant "About Me" Narrative in First Person */}
            <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-800/90 shadow-xl space-y-3.5 text-slate-300 text-sm sm:text-base leading-relaxed">
              <p>
                I am based in <strong className="text-white">Cachar, Assam</strong> and hold a <strong className="text-white">BA in History from Assam University</strong>. I am an entrepreneur, certified business consultant, merchant exporter, and heritage traveler.
              </p>

              <p>
                I combine a deep appreciation for Northeast India&apos;s geographical trade corridors with rigorous commercial compliance—championing regional organic commodities on the global stage while guiding regional clients through taxation, vehicle insurance, and sustainable business development.
              </p>
            </div>

            {/* Academic & Geographic Credentials */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-3">
                <div className="p-2 rounded-lg bg-emerald-950 text-emerald-400 shrink-0">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">Academic Background</div>
                  <div className="text-xs sm:text-sm font-bold text-white mt-0.5">BA in History</div>
                  <div className="text-xs text-slate-400">Assam University</div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-3">
                <div className="p-2 rounded-lg bg-teal-950 text-teal-400 shrink-0">
                  <Compass className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-teal-400">Heritage Explorer</div>
                  <div className="text-xs sm:text-sm font-bold text-white mt-0.5">Northeast Trade Corridors</div>
                  <div className="text-xs text-slate-400">Cultural & Nature Expeditions</div>
                </div>
              </div>
            </div>

            {/* Short Core Business Details Section (Matching Screenshot Layout) */}
            <div className="space-y-3 pt-2">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Core Business & Advisory Activities</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                
                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-emerald-700/60 transition-colors">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs mb-1">
                    <Ship className="w-4 h-4 shrink-0" />
                    <span>Global Agro Exports & Limestone</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Exporting organic ginger, turmeric & tea worldwide (UAE, Australia, UK, France, Japan, USA) & Limestone to Bangladesh.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-amber-700/60 transition-colors">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs mb-1">
                    <Car className="w-4 h-4 shrink-0" />
                    <span>Insurance Advisory & Policies</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Comprehensive insurance consultancy, renewals & claims assistance for vehicles, health, life, and commercial assets.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-teal-700/60 transition-colors">
                  <div className="flex items-center gap-2 text-teal-400 font-bold text-xs mb-1">
                    <FileCheck className="w-4 h-4 shrink-0" />
                    <span>Taxation & GST Filings</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Income Tax (ITR), GST monthly/annual returns, audits, and business entity incorporations.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 hover:border-cyan-700/60 transition-colors">
                  <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs mb-1">
                    <Compass className="w-4 h-4 shrink-0" />
                    <span>Travel & Nature Expeditions</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Documenting scenic landscapes, biodiversity, and cultural crossroads across Northeast India.
                  </p>
                </div>

              </div>
            </div>

            {/* Direct Action Buttons removed from here per user request */}

          </div>

          {/* ================= COLUMN 2: Official Photo & Credentials Two-Column Card ================= */}
          <div className="lg:col-span-5 lg:sticky lg:top-24">
            <div className="bg-gradient-to-b from-slate-800/90 to-slate-900/90 rounded-3xl p-5 sm:p-6 border border-slate-700/80 shadow-2xl backdrop-blur-xl relative overflow-hidden group">
              
              {/* Top Accent Ribbon */}
              <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    Official Executive Profile
                  </span>
                </div>
                <span className="text-xs text-slate-400 font-medium">Assam • India</span>
              </div>

              {/* Two-Column Internal Layout: Photo on Left | Details on Right */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-5 items-center">
                
                {/* Left Column: Reduced Size Executive Photo */}
                <div className="sm:col-span-5 relative">
                  <div className="relative rounded-2xl overflow-hidden aspect-[3/4] sm:aspect-[4/5] bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-emerald-500/40 shadow-2xl ring-2 ring-emerald-500/20">
                    <img 
                      key={profile.avatarUrl || 'default-avatar'}
                      src={profile.avatarUrl || "/images/solman_choudhury.jpg"}
                      alt={profile.name}
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "/images/solman_choudhury.jpg";
                      }}
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                    />
                    
                    {/* Top Floating Badge */}
                    <div className="absolute top-2 left-2">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-950/85 text-emerald-300 border border-emerald-700/60 backdrop-blur-md shadow-md">
                        <UserCheck className="w-3 h-3 text-emerald-400" />
                        <span>Verified</span>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right Column: All Profile Details & Professional Action Buttons */}
                <div className="sm:col-span-7 space-y-3">
                  
                  {/* Name & Title */}
                  <div>
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                      <h3 className="text-white font-bold text-base sm:text-lg tracking-tight">{profile.name}</h3>
                    </div>
                    <p className="text-xs text-emerald-300 font-medium leading-snug">
                      {profile.companyRole || "Managing Partner (Merchant Exporter)"}
                    </p>
                  </div>

                  {/* Quick Official Details Box */}
                  <div className="space-y-1.5 text-xs text-slate-300">
                    <div className="p-2 rounded-xl bg-slate-950/60 border border-slate-800 space-y-0.5">
                      <span className="text-slate-400 flex items-center gap-1 text-[11px] font-semibold">
                        <Building2 className="w-3 h-3 text-emerald-400" />
                        Enterprise:
                      </span>
                      <div className="font-bold text-emerald-300 text-xs">
                        {profile.company || "M/S. CHAIKOSH AGRIELECTRO INDUSTRIES"}
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                      <span className="text-slate-400 flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-amber-400" />
                        Location:
                      </span>
                      <span className="font-semibold text-slate-200 text-right">Cachar, Assam</span>
                    </div>

                    <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                      <span className="text-slate-400 flex items-center gap-1">
                        <Mail className="w-3 h-3 text-cyan-400" />
                        Trade Desk:
                      </span>
                      <a href="mailto:admin@chaikosh.in" className="font-mono text-cyan-300 hover:underline text-[11px]">
                        admin@chaikosh.in
                      </a>
                    </div>
                  </div>

                  {/* Professional Action Buttons (Moved from Bottom to Inside Executive Card) */}
                  <div className="space-y-2 pt-1">
                    <a
                      href="#core-business"
                      className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl font-bold text-[11px] text-slate-950 bg-gradient-to-r from-emerald-400 to-teal-300 hover:from-emerald-300 hover:to-teal-200 transition-all shadow-md active:scale-95 cursor-pointer text-center"
                    >
                      <Briefcase className="w-3.5 h-3.5" />
                      <span>Explore Core Business & Advisory</span>
                      <ArrowDownRight className="w-3.5 h-3.5" />
                    </a>

                    <div className="grid grid-cols-2 gap-2">
                      <a
                        href="https://wa.me/916001565255?text=Hello%20Solman%20Choudhury,%20I%20visited%20your%20portfolio%20and%20would%20like%20to%20connect."
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center justify-center gap-1 px-2.5 py-2 rounded-xl font-medium text-[11px] text-emerald-300 hover:text-white bg-slate-950 hover:bg-slate-900 border border-emerald-800/60 transition-all text-center"
                      >
                        <Phone className="w-3 h-3 text-emerald-400 shrink-0" />
                        <span className="truncate">WhatsApp</span>
                      </a>

                      <a
                        href="mailto:contact@solmanchoudhury.in"
                        className="inline-flex items-center justify-center gap-1 px-2.5 py-2 rounded-xl font-mono text-[11px] text-slate-300 hover:text-white bg-slate-950 hover:bg-slate-900 border border-slate-700 transition-all text-center"
                      >
                        <Mail className="w-3 h-3 text-teal-400 shrink-0" />
                        <span className="truncate">Email Me</span>
                      </a>
                    </div>
                  </div>

                  {/* Philosophy Quote */}
                  <div className="p-2 rounded-xl bg-slate-950/40 border border-slate-800 text-left">
                    <p className="text-[10px] text-slate-400 italic leading-snug">
                      &ldquo;Anchored in Northeast heritage, driven by transparent compliance and global trade vision.&rdquo;
                    </p>
                  </div>

                </div>

              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
